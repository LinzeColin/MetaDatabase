# Codex 原样落库指令

## 唯一目标

把本包 `repo_payload/CodexSkills/registry/codex/global-equity-lead-lag-atlas/` 原样落到目标仓 `CodexSkills/registry/codex/global-equity-lead-lag-atlas/`，运行固定验证，创建一个普通 commit，fast-forward-safe push 到 `main`，完成备份并返回事实。

## 严格禁止

- 不重新研究、设计、重写、格式化或修复文件；
- 不扫描无关全仓；
- 不创建分支、PR，不 merge、reset、rebase、force-push；
- 不手工编辑自动生成的 `CodexSkills/README.md`、`CodexSkills/index.json`、`registry/codex/_catalog`；
- 不接入真实行情、Secret、数据库或服务；
- 不运行真实时间 soak、等待窗口或后台任务。

## 0. 解压包并设定路径

从已解压任务包顶层执行。下面会优先复用当前目录、`/work/AgentDatabase` 或 `$HOME/AgentDatabase` 的正确 checkout；均不存在时只克隆目标代码仓，不接触 Private-Database：

```bash
export GELA_PACK_ROOT="$PWD"
export AGENTDATABASE_REPO=""
for CANDIDATE in "$PWD" "$PWD/AgentDatabase" /work/AgentDatabase "$HOME/AgentDatabase"; do
  [ -d "$CANDIDATE/.git" ] || continue
  ORIGIN="$(git -C "$CANDIDATE" remote get-url origin 2>/dev/null || true)"
  case "$ORIGIN" in
    *github.com/LinzeColin/AgentDatabase.git|*github.com:LinzeColin/AgentDatabase.git|*github.com/LinzeColin/AgentDatabase)
      export AGENTDATABASE_REPO="$(cd "$CANDIDATE" && pwd)"
      break
      ;;
  esac
done
if [ -z "$AGENTDATABASE_REPO" ]; then
  export AGENTDATABASE_REPO="$HOME/AgentDatabase"
  test ! -e "$AGENTDATABASE_REPO"
  git clone --filter=blob:none --branch main https://github.com/LinzeColin/AgentDatabase.git "$AGENTDATABASE_REPO"
fi
```

## 1. 验证任务包

```bash
python3 -B "$GELA_PACK_ROOT/taskpack/tools/verify_delivery.py" "$GELA_PACK_ROOT"
```

必须输出 `PASS`。

## 2. 仓库预检

```bash
python3 -B "$GELA_PACK_ROOT/taskpack/tools/preflight_repo.py" "$AGENTDATABASE_REPO"
```

允许仓库 HEAD 晚于观察基线，但 `AGENTS.md` 的关键约束、`main`、干净工作树和目标路径不存在必须通过。失败即停止，只回报输出。

## 3. 原样复制并验证字节

```bash
SRC="$GELA_PACK_ROOT/repo_payload/CodexSkills/registry/codex/global-equity-lead-lag-atlas"
DST="$AGENTDATABASE_REPO/CodexSkills/registry/codex/global-equity-lead-lag-atlas"
cp -R "$SRC" "$DST"
python3 -B "$GELA_PACK_ROOT/taskpack/tools/compare_tree.py" "$SRC" "$DST"
```

## 4. 仓库内固定测试

```bash
cd "$DST"
python3 -B scripts/check_syntax.py
PYTHONPATH=src python3 -B -m unittest discover -s tests -v
PYTHONPATH=src python3 -B -m gela doctor
PYTHONPATH=src python3 -B -m gela selftest
```

任何命令失败：删除新增 `DST`，不要自行修复，返回命令、退出码和完整日志。

## 5. 只提交目标目录

```bash
cd "$AGENTDATABASE_REPO"
git add -- CodexSkills/registry/codex/global-equity-lead-lag-atlas
git diff --cached --check

test -z "$(git diff --cached --name-only | grep -v '^CodexSkills/registry/codex/global-equity-lead-lag-atlas/')"
git commit -m "feat(codex-skill): add global equity lead-lag atlas v0.0.0.1"
```

## 6. Fast-forward-safe push

```bash
git fetch origin main
LOCAL_PARENT="$(git rev-parse HEAD^)"
REMOTE_MAIN="$(git rev-parse origin/main)"
test "$LOCAL_PARENT" = "$REMOTE_MAIN"
git push origin HEAD:main
```

若远端已前进，停止并回报；不得 pull、merge、rebase 或 force-push。

## 7. 备份与回报

```bash
BACKUP_DIR="$HOME/AgentDatabase-Backups"
mkdir -p "$BACKUP_DIR"
git bundle create "$BACKUP_DIR/AgentDatabase-GELA-v0.0.0.1.bundle" main
git rev-parse HEAD
```

只返回：commit SHA、push 结果、四条验证命令结果、bundle 路径、任何真实警告。不要声称正式外部 2×6 独立复审已完成。

## 回滚

push 前失败：删除新增目录并清理暂存区。

push 后由 Owner 要求回滚时：创建普通 `git revert` commit 并普通 push；禁止改写历史。
