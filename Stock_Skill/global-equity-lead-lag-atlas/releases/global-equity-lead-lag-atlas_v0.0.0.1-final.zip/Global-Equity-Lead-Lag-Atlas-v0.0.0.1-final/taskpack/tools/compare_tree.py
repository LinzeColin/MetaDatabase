#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path


def digest_tree(root: Path) -> dict[str, str]:
    result = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"禁止符号链接: {path}")
        if path.is_file():
            result[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

if len(sys.argv) != 3:
    raise SystemExit("usage: compare_tree.py SOURCE DESTINATION")
source, destination = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
left, right = digest_tree(source), digest_tree(destination)
status = "PASS" if left == right else "FAIL"
print(json.dumps({"status": status, "source_files": len(left), "destination_files": len(right), "missing": sorted(set(left)-set(right)), "extra": sorted(set(right)-set(left)), "changed": sorted(k for k in set(left)&set(right) if left[k]!=right[k])}, ensure_ascii=False, indent=2))
raise SystemExit(0 if status == "PASS" else 2)
