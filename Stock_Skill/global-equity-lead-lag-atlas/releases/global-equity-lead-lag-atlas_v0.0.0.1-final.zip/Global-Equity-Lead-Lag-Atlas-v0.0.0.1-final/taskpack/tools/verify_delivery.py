#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
import re
import subprocess
import sys

try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None  # type: ignore[assignment]
from collections import defaultdict, deque
from pathlib import Path

EXCLUDED_FROM_MANIFEST = {"MANIFEST.json", "SHA256SUMS"}
FORBIDDEN_TEXT = ("TO"+"DO", "T"+"BD", "FIX"+"ME", "<<"+"<<<<<", ">>"+">>>>>", "example"+".com", "change"+"me")
SECRET_PATTERNS = (
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(r"ghp_[A-Za-z0-9]{20,}"),
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
)


def check_toml(text: str) -> None:
    if tomllib is not None:
        tomllib.loads(text)
        return
    section=re.compile(r"^\[[A-Za-z0-9_.-]+\]$")
    assignment=re.compile(r"^[A-Za-z0-9_.-]+\s*=\s*.+$")
    for number,raw in enumerate(text.splitlines(),start=1):
        line=raw.strip()
        if not line or line.startswith('#'): continue
        if section.fullmatch(line) or assignment.fullmatch(line): continue
        raise ValueError(f"Python 3.10 TOML fallback 无法识别第 {number} 行")
    for required in ('[build-system]','[project]','name =','version ='):
        if required not in text: raise ValueError(f"TOML 缺少关键片段: {required}")


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()


def tree_files(root: Path) -> dict[str, Path]:
    result={}
    for p in sorted(root.rglob('*')):
        if p.is_symlink(): raise ValueError(f"禁止符号链接: {p}")
        if p.is_file():
            rel=p.relative_to(root).as_posix()
            if rel.startswith('/') or '..' in Path(rel).parts: raise ValueError(f"非法路径: {rel}")
            result[rel]=p
    return result


def check_dag(path: Path) -> tuple[list[str], set[str], dict[str, int]]:
    errors=[]; data=json.loads(path.read_text(encoding='utf-8')); nodes=data['nodes']
    required={'id','category','stage','phase','title','dependencies','input','output','acceptance','oracle','test','evidence','risk','rollback','stop_condition'}
    ids=[n.get('id') for n in nodes]
    if any(not isinstance(i,str) or not i for i in ids): errors.append('DAG 节点 ID 无效')
    if len(ids)!=len(set(ids)): errors.append('DAG 节点 ID 重复')
    idset={i for i in ids if isinstance(i,str)}
    allowed_categories={'implementation','test','remediation','review','research','release'}
    category_counts=defaultdict(int)
    graph=defaultdict(list); reverse=defaultdict(list); indegree={i:0 for i in idset}
    for n in nodes:
        missing=sorted(required-set(n))
        if missing: errors.append(f"DAG 节点 {n.get('id')} 缺字段: {missing}")
        if n.get('category') not in allowed_categories: errors.append(f"DAG 类别无效: {n.get('id')}={n.get('category')}")
        else: category_counts[n['category']]+=1
        if not n.get('acceptance') or not n.get('oracle') or not n.get('rollback') or not n.get('stop_condition'):
            errors.append(f"DAG 节点关键合同为空: {n.get('id')}")
        for dep in n.get('dependencies',[]):
            if dep not in idset: errors.append(f"DAG 缺失依赖 {n.get('id')} -> {dep}")
            else:
                graph[dep].append(n['id']); reverse[n['id']].append(dep); indegree[n['id']]+=1
    q=deque(i for i,d in indegree.items() if d==0); roots=set(q); seen=[]
    while q:
        cur=q.popleft(); seen.append(cur)
        for nxt in graph[cur]:
            indegree[nxt]-=1
            if indegree[nxt]==0:q.append(nxt)
    if len(seen)!=len(idset): errors.append('DAG 存在循环')
    terminals={i for i in idset if not graph[i]}
    if not roots or not terminals: errors.append('DAG 缺少根或终点')
    reachable=set(); q=deque(roots)
    while q:
        cur=q.popleft()
        if cur in reachable: continue
        reachable.add(cur); q.extend(graph[cur])
    if reachable!=idset: errors.append(f"DAG 存在孤立节点: {sorted(idset-reachable)}")
    can_reach_terminal=set(); q=deque(terminals)
    while q:
        cur=q.popleft()
        if cur in can_reach_terminal: continue
        can_reach_terminal.add(cur); q.extend(reverse[cur])
    if can_reach_terminal!=idset: errors.append(f"DAG 存在无法到达终点节点: {sorted(idset-can_reach_terminal)}")
    if data.get('has_real_time_wait_nodes') is not False: errors.append('DAG 实时等待标记不正确')
    if data.get('frozen') is not True: errors.append('DAG 未冻结')
    return errors,idset,dict(category_counts)


def main(root: Path) -> int:
    errors=[]
    try: files=tree_files(root)
    except ValueError as exc: errors.append(str(exc)); files={}
    try:
        manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
        expected={item['path']:item for item in manifest['files']}
        actual={k:v for k,v in files.items() if k not in EXCLUDED_FROM_MANIFEST}
        if set(expected)!=set(actual): errors.append(f"Manifest 路径集合不一致 missing={sorted(set(expected)-set(actual))} extra={sorted(set(actual)-set(expected))}")
        for rel,item in expected.items():
            p=actual.get(rel)
            if p and (p.stat().st_size!=item['size'] or sha(p)!=item['sha256']): errors.append(f"Manifest 文件不匹配: {rel}")
    except Exception as exc: errors.append(f"Manifest 验证失败: {exc}")
    try:
        sums={}
        for line in (root/'SHA256SUMS').read_text(encoding='utf-8').splitlines():
            digest,rel=line.split('  ',1); sums[rel]=digest
        expected_sum_files={k for k in files if k!='SHA256SUMS'}
        if set(sums)!=expected_sum_files: errors.append('SHA256SUMS 路径集合不一致')
        for rel,digest in sums.items():
            if rel in files and sha(files[rel])!=digest: errors.append(f"SHA256SUMS 不匹配: {rel}")
    except Exception as exc: errors.append(f"SHA256SUMS 验证失败: {exc}")
    forbidden_parts={"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "build", "dist"}
    for rel,p in files.items():
        suffix=p.suffix.lower()
        if suffix in {'.pyc', '.pyo'} or forbidden_parts.intersection(Path(rel).parts):
            errors.append(f"禁止缓存或构建垃圾: {rel}")
        try:
            if suffix=='.json': json.loads(p.read_text(encoding='utf-8'))
            elif suffix=='.py': ast.parse(p.read_text(encoding='utf-8'),filename=rel)
            elif suffix=='.toml': check_toml(p.read_text(encoding='utf-8'))
        except Exception as exc: errors.append(f"语法失败 {rel}: {exc}")
        if suffix in {'.md','.txt','.py','.json','.toml','.csv','.html'}:
            try: text=p.read_text(encoding='utf-8')
            except UnicodeError as exc: errors.append(f"UTF-8 失败 {rel}: {exc}"); continue
            for token in FORBIDDEN_TEXT:
                if token in text: errors.append(f"禁用占位/冲突词 {token}: {rel}")
            for pattern in SECRET_PATTERNS:
                if pattern.search(text): errors.append(f"疑似 Secret: {rel}")
    try:
        dag_errors,dag_ids,category_counts=check_dag(root/'taskpack/machine/TASK_DAG.json'); errors.extend(dag_errors)
    except Exception as exc:
        errors.append(f"DAG 验证失败: {exc}"); dag_ids=set(); category_counts={}
    try:
        acceptance=json.loads((root/'taskpack/machine/ACCEPTANCE_CONTRACT.json').read_text(encoding='utf-8'))
        trace=json.loads((root/'taskpack/machine/TRACEABILITY_MATRIX.json').read_text(encoding='utf-8'))
        req={r['id'] for r in acceptance['requirements']}; mapped={r['requirement_id'] for r in trace['rows']}
        if req!=mapped: errors.append('需求追踪不闭合')
        if acceptance.get('frozen') is not True: errors.append('Acceptance Contract 未冻结')
        for row in trace['rows']:
            if not all(row.get(k) for k in ('task_ids','test_ids','oracle','evidence_ids','artifacts')): errors.append(f"追踪字段为空: {row['requirement_id']}")
            unknown_tasks=set(row.get('task_ids',[]))-dag_ids
            if unknown_tasks: errors.append(f"追踪引用未知任务 {row['requirement_id']}: {sorted(unknown_tasks)}")
    except Exception as exc: errors.append(f"追踪验证失败: {exc}")
    try:
        cost=json.loads((root/'taskpack/machine/COST_ESTIMATE.json').read_text(encoding='utf-8'))
        declared={k:int(v.get('tasks',-1)) for k,v in cost['task_classes'].items()}
        if declared!=category_counts: errors.append(f"成本任务分类计数不一致 declared={declared} actual={category_counts}")
        if cost.get('frozen_acceptance') is not True: errors.append('成本估算未声明冻结验收')
        if cost.get('scenarios',{}).get('pursuing_goal',{}).get('status')!='OPEN_ENDED': errors.append('Pursuing Goal 开放上界标记缺失')
    except Exception as exc: errors.append(f"成本估算验证失败: {exc}")
    expected_prefix='repo_payload/CodexSkills/registry/codex/global-equity-lead-lag-atlas/'
    payload_files=[rel for rel in files if rel.startswith('repo_payload/')]
    if not payload_files or any(not rel.startswith(expected_prefix) for rel in payload_files): errors.append('repo_payload 超出单一 Skill 目录')
    if any('/examples/out/' in '/'+rel for rel in files): errors.append('代码载荷包含运行输出 examples/out')
    try:
        final_report=json.loads((root/'taskpack/review/FINAL_VALIDATION_REPORT.json').read_text(encoding='utf-8'))
        if final_report.get('status') not in {'PASS','PASS_WITH_LIMITATIONS'}: errors.append('最终验证报告状态不是 PASS')
        for check in final_report.get('checks',[]):
            if check.get('blocking') is True and check.get('status')!='PASS': errors.append(f"阻塞验证未通过: {check.get('id')}")
    except Exception as exc: errors.append(f"最终验证报告验证失败: {exc}")
    skill=root/'repo_payload/CodexSkills/registry/codex/global-equity-lead-lag-atlas'
    commands=[
        [sys.executable,'-B','scripts/check_syntax.py'],
        [sys.executable,'-B','-m','unittest','discover','-s','tests','-v'],
        [sys.executable,'-B','-m','gela','doctor'],
        [sys.executable,'-B','-m','gela','selftest'],
    ]
    commands.append([sys.executable,'-B','-m','gela','verify-output',str(root/'taskpack/demo/synthetic-demo')])
    for cmd in commands:
        e=dict(__import__('os').environ); e['PYTHONPATH']=str(skill/'src')
        cp=subprocess.run(cmd,cwd=skill,env=e,text=True,capture_output=True)
        if cp.returncode: errors.append(f"命令失败 {' '.join(cmd)}\n{cp.stdout}\n{cp.stderr}")
    result={"status":"PASS" if not errors else "FAIL","root":str(root),"files":len(files),"errors":errors}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if not errors else 2

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: verify_delivery.py ROOT')
    raise SystemExit(main(Path(sys.argv[1]).resolve()))
