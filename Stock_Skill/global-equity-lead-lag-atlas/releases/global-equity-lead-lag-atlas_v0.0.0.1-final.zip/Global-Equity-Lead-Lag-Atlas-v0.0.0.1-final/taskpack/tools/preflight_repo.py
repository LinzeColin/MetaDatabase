#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

TARGET = Path("CodexSkills/registry/codex/global-equity-lead-lag-atlas")
REQUIRED_SNIPPETS = (
    "The canonical branch is `main`",
    "Do not create a temporary remote",
    "fast-forward-safe",
    "长期/业务/运行时数据一律写私有仓",
)
EXPECTED_REMOTE = re.compile(r"(?:github\.com[:/])LinzeColin/AgentDatabase(?:\.git)?$")


def run(repo: Path, *args: str) -> str:
    completed = subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True)
    if completed.returncode:
        raise RuntimeError(completed.stderr.strip() or completed.stdout.strip())
    return completed.stdout.strip()


if len(sys.argv) != 2:
    raise SystemExit("usage: preflight_repo.py AGENTDATABASE_REPO")
repo = Path(sys.argv[1]).expanduser().resolve()
errors: list[str] = []
origin = None
head = None
try:
    if run(repo, "rev-parse", "--show-toplevel") != str(repo):
        errors.append("路径不是仓库根")
    if run(repo, "branch", "--show-current") != "main":
        errors.append("当前分支不是 main")
    if run(repo, "status", "--porcelain"):
        errors.append("工作树不干净")
    origin = run(repo, "remote", "get-url", "origin")
    if not EXPECTED_REMOTE.search(origin):
        errors.append(f"origin 不是 LinzeColin/AgentDatabase: {origin}")
    head = run(repo, "rev-parse", "HEAD")
except (RuntimeError, FileNotFoundError) as exc:
    errors.append(str(exc))
agents = repo / "AGENTS.md"
if not agents.is_file():
    errors.append("缺少 AGENTS.md")
else:
    text = agents.read_text(encoding="utf-8")
    for snippet in REQUIRED_SNIPPETS:
        if snippet not in text:
            errors.append(f"仓库规则关键语义缺失: {snippet}")
if (repo / TARGET).exists():
    errors.append("目标路径已存在，禁止覆盖")
print(json.dumps({
    "status": "PASS" if not errors else "FAIL",
    "repository": str(repo),
    "origin": origin,
    "head": head,
    "target": str(TARGET),
    "errors": errors,
}, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 2)
