# GELA v0.0.0.1 Roadmap

## 当前版本：纵向最短闭环

| Stage | Phase | 目标 | 主要任务 | 完成定义 |
|---|---|---|---|---|
| S0 | P0 冻结 | 冻结 Skill 身份、范围和宿主边界 | 核验 AgentDatabase 规则；冻结输入、输出、证据门和冲突顺序 | Canonical Facts 与 Acceptance Contract 不再动态扩张 |
| S1 | P1 内核 | 建立可验证分析链 | CSV 校验、同会话日期相关、UTC 信息集对齐、收益构造、分族全局 FDR、区块 Bootstrap、滚动稳定性、样本外确认 | 合成 A↔B 与 A→B 被识别、B→A 不误报 |
| S2 | P2 制品 | 生成宿主可消费结果 | 同期相关矩阵、时延矩阵、JSON、CSV、中文摘要、自包含双视图 HTML、provenance、quality report | 十一类输出全部 PASS，无网络依赖 |
| S3 | P3 Skill 化 | 形成可直接运行功能板块 | SKILL.md、CLI、Python 包、接口与解释护栏 | Python 3.10+ 可零安装运行；宿主已有 setuptools 时可选 editable 安装 |
| S4 | P4 落库 | Codex 原样落库 | 预检、精确复制、测试、单提交、fast-forward-safe push、备份 | 仅新增一个 Skill 目录；可单提交回滚 |

## 当前非目标

- 不建立前端应用、API 服务、登录、数据库、队列、调度器、常驻进程或独立部署。
- 不接入或重新分发真实行情数据。
- 不输出交易指令、收益承诺或现实因果结论。
- 不手工修改自动生成的 `CodexSkills/README.md`、`CodexSkills/index.json` 或 `_catalog`；宿主既有同步机制负责派生视图。

## Future Roadmap（与 v0.0.0.1 隔离）

- 宿主交易日历 Adapter：可选 `exchange_calendars`，支持特殊会话和官方差异覆盖。
- 币种与全球因子控制：本地货币、美元、FX residual 三层结果。
- Regime 与动态连接度：风险偏好、高波动、行业周期分层。
- 研究扩展：HAC、stationary bootstrap、VAR/FEVD、预注册非线性方法。
- 宿主 UI 深度嵌入：消费稳定 JSON，不改变证据语义。

未来项不得自动进入当前 DAG 或阻塞 v0.0.0.1 落库。
