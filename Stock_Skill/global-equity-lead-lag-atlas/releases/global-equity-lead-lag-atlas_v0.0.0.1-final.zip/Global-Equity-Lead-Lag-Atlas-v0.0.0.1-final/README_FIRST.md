# 先做什么

本 ZIP 是 **全球股市时序联动图谱 Global Equity Lead–Lag Atlas v0.0.0.1** 的唯一最终任务包。

它交付的是一个可接入现有系统的 Skill 功能板块，不是独立软件系统。`repo_payload/` 已包含完整可直接运行实现、合成 Fixture、同期相关与时延分析内核、测试、方法护栏和宿主接口；宿主已有 `setuptools>=61` 时还可选择 editable 安装；`taskpack/demo/synthetic-demo/atlas.html` 是不落库的双视图离线演示。Codex 不需要重新研究、设计或写代码。

## 你只需要做三步

1. 将本 ZIP 原样上传给 Codex。
2. 给 Codex 发送：

```text
严格读取并执行压缩包内 taskpack/handoff/CODEX_DROP_IN.md。只允许原样落库、运行指定验证、commit、fast-forward-safe push 和备份；不得修改、重构、开分支、开 PR、merge 或自行修复。失败只返回事实、日志和链接。
```

3. Codex 返回 commit 和 push 结果后，保留本 ZIP 作为版本事实。

## 验收状态

- ZIP 完整性、代码语法、单元测试、合成端到端、同期相关对称性、前视防护、离线 HTML、DAG 和追踪闭包：由本包验证器即时复验。
- 正式外部 `2×6` 独立 SubAgent 审查：当前生成环境没有可验证的独立 Agent/context receipt，因此保持 `NOT_PROVEN`，未伪装为已执行；本包提供两轮六视角同模型隔离审查记录和未来可选的独立复审合同。该限制不影响任务包落库，但不得据此声称已完成独立多模型认证。
