# 许可与归因说明

## 本任务包

本任务包中的文档、模板和 Python 脚本为本次任务独立生成，供用户创建和维护个人 Codex Skill 使用。未复制任何第三方项目源码。

用户若公开发布本 Skill，可自行选择许可证。发布前应再次检查引用项目的最新许可证和商标要求。

## 外部项目使用方式

只采用高层架构和工作流启发，例如：研究先行、问题分解、来源跟踪、多视角、质量门禁、趋势雷达、渐进披露。没有将第三方代码、提示词正文、模板正文或独特表达纳入本任务包。

## 重点许可证（调研日：2026-07-18）

| 项目 | 当时显示许可证 | 本任务包使用方式 |
|---|---|---|
| TubeFlow | MIT | 仅参考研究先行与角色拆分 |
| TrendRadar | GPL-3.0 | 仅参考趋势聚合、时效过滤；不复制代码 |
| STORM | MIT | 仅参考多视角问题生成与先大纲后写作 |
| Open Deep Research | MIT | 仅参考可配置研究与评估思想 |
| GPT Researcher | Apache-2.0 | 仅参考 planner/execution/publisher 分层 |
| Autonomous Product Strategy Agent | MIT | 仅参考 human review、QA、置信度 |
| AI Research SKILLs | MIT | 仅参考 Skill 模块化和渐进披露 |
| AiCMO Marketing Prompt Collection | Apache-2.0 | 作为“巨型提示词库”对照案例 |

许可证和仓库状态可能变化；公开分发前必须重新核验。
