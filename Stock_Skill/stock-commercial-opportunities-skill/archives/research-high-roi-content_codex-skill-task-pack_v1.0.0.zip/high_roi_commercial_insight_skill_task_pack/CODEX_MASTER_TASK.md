# Codex Master Task：创建高 ROI 商业洞察内容 Skill

## 0. 任务状态表

| 项目 | 状态 | Codex 动作 |
|---|---|---|
| 需求抽象 | 已完成 | 核验，不重做 |
| 外部项目调研 | 已完成 | 检查是否出现规范变化 |
| 目标架构 | 已完成 | 最小差异实现 |
| Skill 草案 | 已完成 | 审计、修正、安装 |
| 本地脚本测试 | 任务包已提供 | 重跑并记录 |
| 触发前向测试 | 待执行 | 新鲜线程/子代理验证 |
| 安装与回滚 | 待执行 | 备份后原子安装 |

## 1. 任务目标

创建或升级一个 Codex Skill：`research-high-roi-content`。该 Skill 将宽泛领域、实时趋势、用户资料或现有稿件，转化为证据充分、商业机制清晰、原创且可行动的高经济价值内容机会与解说结构。

必须同时优化：

- 质量：证据完整、机制深、反证充分、输出可验收。
- 性能：宽进窄出、来源去重、按档位控制研究预算。
- 速率：FAST/STANDARD/DEEP 分层；可并行的只读任务才使用子代理。
- 效率：只在确定性计算和验证上使用脚本；不引入平台级依赖。
- 安全：不模仿现实创作者、不保证收益、不输出高风险个性化建议。

## 2. 只读阶段

### 2.1 仅允许读取

- 本任务包根目录文档。
- `skill_draft/research-high-roi-content/**`。
- 拟安装目标目录（若存在）。
- 当前官方 Codex Skill 文档和当前 `$skill-creator` 实现。

不要扫描其他项目、其他 Skill 或用户主目录。

### 2.2 核验事项

1. 当前 `SKILL.md` frontmatter 允许字段。
2. 当前用户级与仓库级 Skill 路径。
3. `agents/openai.yaml` 当前字段。
4. 官方验证器真实位置与调用方式。
5. Skill 发现与刷新方式。
6. 当前是否推荐 Skill 或 skill-only plugin；本任务默认仍为本地个人 Skill，除非官方规范要求改变。

### 2.3 只读阶段输出

在写入前，列出：

- 将读取的文件。
- 将新建/修改的文件。
- 测试命令。
- 备份与回滚方案。
- 发现的规范差异，以及是否需要调整草案。

## 3. 实现范围

### 3.1 允许修改

仅允许：

```text
<install-root>/research-high-roi-content/**
```

以任务包中的以下目录为基线：

```text
skill_draft/research-high-roi-content/**
```

### 3.2 禁止修改

- 其他 Skill。
- 仓库业务代码。
- 全局 Codex 配置，除非仅为启用此 Skill 且用户已明确授权。
- 任何外部项目源码。
- 用户内容库或平台账户。

## 4. 实施步骤与颗粒度

### P0：目标检查

- [ ] 确认目标安装路径。
- [ ] 检查同名目录和同名 Skill 冲突。
- [ ] 若存在旧版，生成时间戳备份，不原地无备份覆盖。
- [ ] 记录当前文件清单和哈希，以支持回滚。

### P1：规范对齐

- [ ] 检查 `SKILL.md` frontmatter 只含 `name`、`description`。
- [ ] 名称与目录一致，字符合法，长度符合当前规范。
- [ ] 描述前置核心触发词，同时写清边界和不触发场景。
- [ ] 检查 `agents/openai.yaml` 只使用当前支持字段。
- [ ] 确认所有 `SKILL.md` 链接均为一层直达引用。

### P2：工作流质量

- [ ] 保留 FAST/STANDARD/DEEP 三档。
- [ ] 保留四类 ROI 拆分。
- [ ] 保留事实/推断/估计/观点标签。
- [ ] 保留反证查询、冲突处理、盲点与 surprise pass。
- [ ] 保留商业机制九段式原创叙事。
- [ ] 保留受监管领域、高时效事实、平台访问和版权边界。
- [ ] 保留无自动发布和无结果保证。

### P3：确定性工具

- [ ] `score_topics.py`：校验输入、计算价值分/风险扣分/置信度/决策等级。
- [ ] `validate_deliverable.py`：阻止无来源事实、高风险缺少官方来源、收益保证、结构缺失。
- [ ] `validate_skill.py`：检查基本 Skill 结构。
- [ ] 所有脚本仅用 Python 标准库。
- [ ] 错误输出明确，非零退出码可用于 CI。

### P4：测试

- [ ] 运行本任务包全部单元测试。
- [ ] 用示例 JSON 运行打分器。
- [ ] 严格模式验证示例交付物。
- [ ] 运行官方 `quick_validate.py`（若当前系统提供）。
- [ ] 检查无 `__pycache__`、`.pyc`、临时文件进入最终目录。

### P5：触发前向测试

使用 `evals/trigger_cases.jsonl`：

- [ ] 10 个正向样例至少 9 个正确触发。
- [ ] 10 个负向样例至少 9 个不触发。
- [ ] “模仿某现实创作者”必须转化为结构抽象，而非照搬。
- [ ] 高风险个性化建议必须拒绝或安全改写，而不是以本 Skill 执行。

### P6：质量 A/B 测试

使用 `evals/quality_cases.jsonl` 中至少 3 个案例：

1. A 组：不加载 Skill 的原始提示。
2. B 组：显式加载 Skill。
3. 独立评估者按 `references/evaluation.md` 评分。
4. 记录来源数量、关键主张覆盖率、机制层数、行动项、明显 token/时间成本。

验收：B 组在证据完整性、机制深度、行动性三项中至少两项明显优于 A 组；不得出现关键安全退化；STANDARD 档位成本不应无理由超过 A 组的 2.5 倍。

### P7：安装

- [ ] 复制到目标目录的临时路径。
- [ ] 在临时路径运行全部验证。
- [ ] 原子重命名为最终目录。
- [ ] 让 Codex 刷新 Skill；若未发现，按当前官方文档重启/刷新。
- [ ] 显式调用 `$research-high-roi-content` 做一个最小 smoke test。

## 5. 测试命令

```bash
python3 <skill>/scripts/validate_skill.py <skill>
python3 -m unittest discover -s <skill>/tests -v
python3 <skill>/scripts/score_topics.py \
  --input <skill>/assets/topic-score-input.example.json \
  --format markdown
python3 <skill>/scripts/validate_deliverable.py \
  --input <skill>/assets/deliverable.example.json \
  --strict
```

官方验证器命令应基于当前 `$skill-creator` 的真实路径，不使用过期硬编码。

## 6. 回滚方案

若目标目录原已存在：

```bash
rm -rf <install-root>/research-high-roi-content
mv <backup-path> <install-root>/research-high-roi-content
```

若为全新安装：

```bash
rm -rf <install-root>/research-high-roi-content
```

不要删除任务包或其他 Skill。

## 7. 最终交付格式

最终报告只包含：

1. 安装位置。
2. Diff summary。
3. 测试与前向评估结果。
4. 触发方式和一个最小示例。
5. 回滚命令。
6. 真实剩余风险。

不要写泛泛的“已优化很多”。每个结论要对应文件或测试证据。
