---
name: research-high-roi-content
description: Research, rank, and script evidence-backed high-ROI commercial insight content for a domain. Use for 高经济价值/高 ROI 选题、商业机制拆解、反常识商业解说、行业机会雷达、内容系列、研究转脚本、变现桥或稿件证据审计. Do not use for generic rewriting or translation, entertainment gossip, exact imitation of a living creator, automated publishing, or personalized financial, medical, legal, tax, or regulatory advice.
---

# Research High-ROI Content

Turn a broad domain, trend, source pack, or draft into evidence-backed commercial insight opportunities and original explanatory content.

## Preserve these invariants

- Research before narrative. Do not invent facts, figures, cases, dates, quotes, sources, or causal claims.
- Separate attention ROI, cognitive ROI, commercial ROI, and execution ROI. Never equate heat or market size with personal opportunity.
- Keep value score, risk deduction, and evidence confidence separate.
- Abstract only high-level rhetoric from style references. Do not reproduce a living creator's distinctive voice, signature phrases, persona, or close paraphrases.
- Prefer official, primary, first-party, and original sources for current or high-stakes claims. Label facts, inferences, estimates, opinions, and unverified items.
- Do not guarantee revenue, returns, traffic, virality, conversion, rankings, or outcomes.
- Do not scrape login-gated, paywalled, private, or terms-restricted sources; do not publish automatically.

## Choose one operating lane

- **FAST** — one narrow question; 1–3 candidate outputs; 3–6 authoritative sources; no subagents by default.
- **STANDARD** — default; 12 candidates, 8–15 deduplicated sources, two research passes, one contradiction pass, Top 3 deep dives.
- **DEEP** — a decision-grade dossier or series; 15–30 candidates and sources; multiple perspectives; at most four independent read-only subagents.

Read [workflow.md](references/workflow.md) before STANDARD or DEEP work.

## Execute this sequence

1. **Normalize the request.** Identify domain, audience, goal, geography, time horizon, output mode, and constraints. Use documented defaults when noncritical inputs are absent. Ask at most three numbered questions only when the answer materially changes scope, jurisdiction, safety, or acceptance.
2. **Define the value pool.** Map payer, user, economic pain, budget owner, bottleneck, value capture, switching cost, constraints, and why now. Include “boring but expensive” surfaces such as compliance, QA, maintenance, procurement, migration, integration, standards, liability, delivery, and lifecycle cost.
3. **Research current facts.** Build a source and claim ledger. Use a source hierarchy, freshness rules, and contradiction queries from [research-protocol.md](references/research-protocol.md). When web access is unavailable, stop at a research plan or label the result low-confidence; do not present current facts as verified.
4. **Generate falsifiable candidates.** Each candidate must name a concrete actor, mechanism, loser/winner, timing condition, and evidence needed to disprove it. Reject generic “industry is growing” topics.
5. **Score and rank.** Apply [scoring-rubric.md](references/scoring-rubric.md). Use `scripts/score_topics.py` for structured candidate sets. Cap low-confidence topics at Watch or below.
6. **Deepen only the winners.** For Top N, add unit economics or cost logic, distribution, incentives, constraints, countercases, personal entry conditions, and a reversible next experiment.
7. **Write original commercial-mechanism content.** Follow [style-framework.md](references/style-framework.md): falsifiable hook → phenomenon → wrong model → mechanism → value capture → why now → action → risk → original compressed close.
8. **Produce the requested contract.** Use Radar, Dossier, Script, Series, Business Bridge, or Audit from [output-contracts.md](references/output-contracts.md).
9. **Run the final gates.** Check claim support, contradictions, freshness, guarantees, imitation risk, role-specific actionability, and surprise/adjacent opportunity. For structured deliverables, run `scripts/validate_deliverable.py`.

## Route unsafe or out-of-scope requests

- Convert “write exactly like [living creator]” into an original structure using requested high-level traits such as concise, contrastive, mechanism-first, or case-led.
- Refuse personalized regulated advice; offer educational research, decision criteria, official-source verification, and questions for a licensed professional.
- For generic rewriting, translation, entertainment gossip, or unrelated creative writing, do not invoke this workflow.

## Use resources selectively

| Need | Read or run |
|---|---|
| Lane budgets, stage gates, defaults | [workflow.md](references/workflow.md) |
| Search, evidence ledger, contradiction and saturation | [research-protocol.md](references/research-protocol.md) |
| ROI, risk, confidence and decision status | [scoring-rubric.md](references/scoring-rubric.md) |
| Original commercial-explainer argument | [style-framework.md](references/style-framework.md) |
| Exact deliverable shapes | [output-contracts.md](references/output-contracts.md) |
| Freshness, high-stakes, access and safety | [evidence-and-safety.md](references/evidence-and-safety.md) |
| Trigger, quality and cost evaluation | [evaluation.md](references/evaluation.md) |
| Deterministic ranking | `python3 scripts/score_topics.py --help` |
| Structured-output validation | `python3 scripts/validate_deliverable.py --help` |
| Skill package validation | `python3 scripts/validate_skill.py .` |

End with a compact decision: what is Actionable now, what remains Watch/Observe, what evidence could change the ranking, and the single highest-ROI next step.
