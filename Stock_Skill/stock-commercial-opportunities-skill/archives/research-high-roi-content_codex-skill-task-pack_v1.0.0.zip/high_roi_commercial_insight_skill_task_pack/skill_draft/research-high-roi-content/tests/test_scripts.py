from __future__ import annotations

import importlib.util
import json
import subprocess
import sys
import tempfile
import shutil
import unittest
from pathlib import Path

sys.dont_write_bytecode = True

SKILL_DIR = Path(__file__).resolve().parents[1]
SCRIPTS = SKILL_DIR / "scripts"
ASSETS = SKILL_DIR / "assets"


def remove_caches() -> None:
    for cache in SKILL_DIR.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    for compiled in SKILL_DIR.rglob("*.py[co]"):
        try:
            compiled.unlink()
        except FileNotFoundError:
            pass


def setUpModule() -> None:
    remove_caches()


def tearDownModule() -> None:
    remove_caches()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


score_topics = load_module("score_topics", SCRIPTS / "score_topics.py")
validate_deliverable = load_module("validate_deliverable", SCRIPTS / "validate_deliverable.py")
validate_skill = load_module("validate_skill", SCRIPTS / "validate_skill.py")


class ScoreTopicsTests(unittest.TestCase):
    def setUp(self):
        self.payload = json.loads((ASSETS / "topic-score-input.example.json").read_text(encoding="utf-8"))

    def test_example_ranks_boring_expensive_topics_above_hype(self):
        rows = score_topics.score_payload(self.payload)
        self.assertEqual(len(rows), 3)
        self.assertEqual(rows[-1]["id"], "T003")
        self.assertIn(rows[0]["id"], {"T001", "T002"})
        self.assertEqual(rows[0]["status"], "Actionable")
        self.assertIn(rows[-1]["status"], {"Observe", "Reject", "Watch"})

    def test_invalid_score_is_rejected(self):
        self.payload["topics"][0]["dimensions"]["economic_pain_wtp"] = 11
        with self.assertRaises(score_topics.InputError):
            score_topics.score_payload(self.payload)

    def test_missing_dimension_is_rejected(self):
        del self.payload["topics"][0]["dimensions"]["platform_fit"]
        with self.assertRaises(score_topics.InputError):
            score_topics.score_payload(self.payload)

    def test_markdown_contains_separated_scores(self):
        rendered = score_topics.format_markdown(score_topics.score_payload(self.payload))
        self.assertIn("基础分", rendered)
        self.assertIn("风险扣分", rendered)
        self.assertIn("置信度", rendered)
        self.assertIn("R1", rendered)


class DeliverableValidatorTests(unittest.TestCase):
    def setUp(self):
        self.payload = json.loads((ASSETS / "deliverable.example.json").read_text(encoding="utf-8"))

    def test_example_passes_without_findings(self):
        findings = validate_deliverable.validate(self.payload)
        self.assertEqual(findings, [])

    def test_unsupported_fact_fails(self):
        self.payload["claims"][0]["sources"] = []
        findings = validate_deliverable.validate(self.payload)
        self.assertTrue(any(f.code == "UNSUPPORTED_CLAIM" and f.severity == "error" for f in findings))

    def test_guarantee_language_fails(self):
        self.payload["script"]["closing"] = "照做就能稳赚并保证收入。"
        findings = validate_deliverable.validate(self.payload)
        self.assertTrue(any(f.code == "GUARANTEE_LANGUAGE" for f in findings))

    def test_legitimate_100_percent_fact_is_not_automatically_blocked(self):
        self.payload["claims"][3]["statement"] = "这个合成示例的字段覆盖率是 100%，但不代表商业结果。"
        findings = validate_deliverable.validate(self.payload)
        self.assertFalse(any(f.code == "GUARANTEE_LANGUAGE" for f in findings))

    def test_exact_style_imitation_fails(self):
        self.payload["meta"]["style_reference"]["exact_creator_imitation"] = True
        findings = validate_deliverable.validate(self.payload)
        self.assertTrue(any(f.code == "EXACT_IMITATION" for f in findings))

    def test_low_confidence_actionable_fails(self):
        self.payload["topics"][0]["confidence"] = 40
        findings = validate_deliverable.validate(self.payload)
        self.assertTrue(any(f.code == "ACTIONABLE_CONFIDENCE" for f in findings))

    def test_high_stakes_requires_official_source_and_disclaimer(self):
        self.payload["meta"]["high_stakes"] = True
        for claim in self.payload["claims"]:
            for source in claim.get("sources", []):
                source["source_type"] = "media"
        findings = validate_deliverable.validate(self.payload)
        codes = {f.code for f in findings}
        self.assertIn("HIGH_STAKES_DISCLAIMER", codes)
        self.assertIn("HIGH_STAKES_SOURCE", codes)


class SkillValidatorTests(unittest.TestCase):
    def test_current_skill_passes(self):
        remove_caches()
        findings = validate_skill.validate_skill(SKILL_DIR)
        errors = [f for f in findings if f.severity == "error"]
        self.assertEqual(errors, [], msg="\n".join(f.message for f in errors))

    def test_extra_frontmatter_field_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            temp_skill = Path(tmp) / "demo-skill"
            temp_skill.mkdir()
            (temp_skill / "SKILL.md").write_text(
                "---\nname: demo-skill\ndescription: Use for testing. Do not use elsewhere.\nversion: 1\n---\n# Demo\n",
                encoding="utf-8",
            )
            findings = validate_skill.validate_skill(temp_skill)
            self.assertTrue(any("Unsupported frontmatter" in f.message for f in findings))


class CliSmokeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, *args],
            cwd=SKILL_DIR,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_score_cli(self):
        result = self.run_cli(
            str(SCRIPTS / "score_topics.py"),
            "--input", str(ASSETS / "topic-score-input.example.json"),
            "--format", "markdown",
        )
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertIn("Actionable", result.stdout)

    def test_deliverable_cli_strict(self):
        result = self.run_cli(
            str(SCRIPTS / "validate_deliverable.py"),
            "--input", str(ASSETS / "deliverable.example.json"),
            "--strict",
        )
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("PASS", result.stdout)

    def test_skill_cli(self):
        remove_caches()
        result = self.run_cli(str(SCRIPTS / "validate_skill.py"), str(SKILL_DIR))
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("PASS", result.stdout)


if __name__ == "__main__":
    unittest.main()
