# 研究协议：来源、检索、证据台账与反证

## 1. 研究问题框架

不要从“什么最火”开始。按以下顺序提问：

1. **谁在付钱？** 预算属于谁，决策链多长，购买触发是什么？
2. **什么代价足够痛？** 收入损失、成本、时间、停机、错误、合规、责任、风险或机会成本。
3. **价值在哪里捕获？** 产品、服务、渠道、数据、标准、牌照、集成、运维、品牌或网络效应。
4. **为什么现在？** 技术成本、政策、人口、供应链、组织流程、平台规则或竞争变化。
5. **个人/小团队如何进入？** 研究、内容、咨询、实施、审计、培训、模板、数据、软件或合作。
6. **什么会证明我们错了？** 反例、替代解释、周期、样本偏差、既得利益和数据缺口。

## 2. 来源层级

| 层级 | 来源 | 适合证明 | 限制 |
|---|---|---|---|
| A | 法规、监管、政府数据、标准、原始论文、公司法定披露、官方技术文档 | 定义、规则、数字、时间、能力边界 | 仍需核对版本/日期/法域 |
| B | 行业协会、审计/咨询研究、原始调查、数据库说明、可信机构报告 | 市场结构、行为、趋势、比较 | 方法与利益关系需检查 |
| C | 一线企业案例、客户访谈、招聘/采购信号、公开产品页 | 实际痛点、语言、流程、买方线索 | 选择偏差与营销倾向 |
| D | 专业媒体、分析师、专家评论、二手综述 | 上下文、争议、候选解释 | 不独立支撑高影响事实 |
| E | 论坛、评论区、社交平台、搜索趋势 | 问题语言、情绪、注意力、早期信号 | 不能单独证明事实或因果 |

高时效或高风险主张优先 A；社区信号只能用于发现问题和措辞。

## 3. 检索矩阵

为每个候选至少选择 4 类查询：

### 3.1 定义与规则

- `[domain] official definition standard regulation`
- `[product/process] official documentation limitations`
- `[jurisdiction] policy effective date guidance`

### 3.2 买方与经济痛点

- `[buyer role] cost of [problem]`
- `[problem] downtime error compliance cost case study`
- `[solution] procurement RFP implementation requirements`

### 3.3 价值链与竞争

- `[domain] value chain margins bottleneck`
- `[solution category] pricing implementation partner`
- `[incumbent/alternative] switching cost integration`

### 3.4 时点与趋势

- `[domain] adoption survey current year`
- `[technology] cost curve deployment constraints`
- `[policy/platform] change effective current year`

### 3.5 反证与失败

- `[thesis] criticism limitations failure`
- `[solution] failed implementation postmortem`
- `[trend] plateau decline overhype`
- `[claim] methodology data limitation`

### 3.6 邻接 surprise

- `[domain] certification testing maintenance insurance`
- `[domain] data migration interoperability training`
- `[domain] procurement aftersales lifecycle recycling`

## 4. 两轮研究法

### Round 1：宽搜与地图

目标：发现 actor、术语、价值链、主要争议和原始来源。

输出：

- 来源家族；
- 价值池；
- 12 个候选；
- 缺失证据清单。

不要在此阶段写完整脚本。

### Round 2：主张驱动补证

只围绕入围候选的核心主张搜索：

- 哪个事实必须成立？
- 哪个因果只是推断？
- 证据是否足以支持叙事强度？
- 买方、预算和进入路径是否真实？

随后执行独立的 contradiction query。

## 5. 证据台账字段

至少记录：

| 字段 | 含义 |
|---|---|
| claim_id | 唯一主张 ID |
| statement | 可独立判断真假的原子主张 |
| claim_type | Fact / Inference / Estimate / Opinion / Unverified |
| importance | Core / Supporting / Context |
| source_title | 来源名称 |
| url | 公开链接或用户材料定位 |
| source_type | official / primary / research / first_party / media / community / user_material |
| published_at | 发布/生效时间（若可得） |
| retrieved_at | 本次检索日期 |
| jurisdiction | 法域（若相关） |
| freshness | Fresh / Delayed / Stale / Missing / Conflicting |
| supports_or_challenges | supports / challenges / context |
| quote_or_note | 最小必要摘录或释义；避免长引用 |
| confidence | 0–100 |
| affected_topic_ids | 支持哪些候选 |

使用 `assets/evidence-ledger.csv` 作为起始模板。

## 6. 主张原子化

错误：

> 企业都愿意为 AI Agent 支付高价，因为 AI 市场高速增长。

拆成：

1. 某类企业存在某个可测量的流程成本（Fact/Estimate）。
2. 某类工具能够影响该成本（Fact/Inference）。
3. 预算由某角色控制且有采购触发（Fact/Inference）。
4. 内容/服务提供者有现实进入路径（Inference）。
5. 市场热度提升了注意力或时点（Fact/Context）。

每个原子主张独立找证据，避免用一个宏观数字支撑整条因果链。

## 7. 冲突处理

遇到来源冲突：

1. 检查定义、样本、时间、地区、计量单位和利益关系。
2. 优先原始/官方来源，但不自动忽略方法更好的独立研究。
3. 记录双方主张和差异原因。
4. 无法化解时标记 Conflicting，降低 confidence 和决策等级。
5. 不在叙事中静默挑选更“好听”的数字。

## 8. 新鲜度规则

按事实类型设半衰期，而不是统一“最近一年”：

| 类型 | 默认复核窗口 |
|---|---|
| 价格、产品功能、软件版本、在任角色、平台政策 | 同次检索；优先官方当前页 |
| 法律、监管、税务、政策 | 同次检索；确认生效日、法域和修订状态 |
| 市场份额、采用率、宏观数据 | 优先 12–18 个月内且有方法说明 |
| 公司战略/产品路线 | 同次官方披露 + 独立交叉验证 |
| 技术原理、经典理论 | 可使用稳定来源，但检查是否已被更新/推翻 |
| 案例与社区问题 | 标注发生时间，不能外推为普遍事实 |

## 9. 搜索与引用纪律

- 当前事实必须联网；用户材料不足时不要猜。
- 一次搜索结果页面不是证据，打开并检查原文。
- 相同新闻稿的转载不算来源多样性。
- 直接引用保持最小必要长度；以准确释义为主。
- 记录来源如何支持主张，而不是只列“参考链接”。
- 找不到答案时说明已搜索什么、缺什么、下一步如何验证。
- 不通过 OCR 反复处理可直接阅读的材料；图表/表格需查看原页或截图。

## 10. 研究完成定义

STANDARD 至少满足：

- 关键主张覆盖率 ≥80%；
- 至少 3 类来源；
- 完成一轮反证；
- 明确买方、痛点、价值捕获和个人进入方式；
- 对 Missing/Conflicting/Stale 做了降级；
- 新增来源已接近饱和。

DEEP 目标为关键主张覆盖率 ≥90%，并增加失败案例、相邻机会和多法域/多角色比较。
