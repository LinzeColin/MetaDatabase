#!/usr/bin/env python3
"""Validate a structured high-ROI commercial insight deliverable.

Uses only the Python standard library. The validator checks structure,
claim-source integrity, decision gates, guarantees, exact-style imitation,
and high-stakes official-source requirements.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set, Tuple
from urllib.parse import urlparse

CLAIM_TYPES = {"fact", "inference", "estimate", "opinion", "unverified"}
IMPORTANCE = {"core", "supporting", "context"}
FRESHNESS = {"Fresh", "Delayed", "Stale", "Missing", "Conflicting"}
STATUSES = {"Actionable", "Watch", "Observe", "Reject"}
SOURCE_TYPES = {"official", "primary", "research", "first_party", "media", "community", "user_material"}
SCRIPT_FIELDS = (
    "hook", "phenomenon", "wrong_model", "mechanism", "value_capture",
    "why_now", "action", "risk", "closing",
)
GUARANTEE_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"稳赚", r"保本", r"无风险", r"必爆", r"保证(?:收益|收入|转化|排名|播放)",
        r"100\s*%\s*(?:成功|收益|转化|准确|保证|guarantee|success|return|conversion)", r"guaranteed?\s+(?:return|revenue|conversion|ranking)",
        r"risk[- ]?free", r"cannot\s+lose",
    )
]


@dataclass
class Finding:
    severity: str
    code: str
    path: str
    message: str

    def as_dict(self) -> Dict[str, str]:
        return {"severity": self.severity, "code": self.code, "path": self.path, "message": self.message}


class ContractError(ValueError):
    pass


def is_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def add(findings: List[Finding], severity: str, code: str, path: str, message: str) -> None:
    findings.append(Finding(severity, code, path, message))


def nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def valid_url(value: Any) -> bool:
    if not nonempty_string(value):
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def walk_strings(value: Any) -> Iterable[Tuple[str, str]]:
    stack: List[Tuple[str, Any]] = [("$", value)]
    while stack:
        path, item = stack.pop()
        if isinstance(item, str):
            yield path, item
        elif isinstance(item, Mapping):
            for key, child in item.items():
                stack.append((f"{path}.{key}", child))
        elif isinstance(item, list):
            for index, child in enumerate(item):
                stack.append((f"{path}[{index}]", child))


def validate(payload: Any) -> List[Finding]:
    findings: List[Finding] = []
    if not is_mapping(payload):
        return [Finding("error", "ROOT_TYPE", "$", "Root must be an object")]

    for key in ("meta", "topics", "claims", "selected_topic_id", "script"):
        if key not in payload:
            add(findings, "error", "MISSING_TOP_LEVEL", f"$.{key}", "Required top-level field is missing")

    meta = payload.get("meta")
    topics = payload.get("topics")
    claims = payload.get("claims")
    selected_id = payload.get("selected_topic_id")
    script = payload.get("script")

    # Meta
    if not is_mapping(meta):
        add(findings, "error", "META_TYPE", "$.meta", "meta must be an object")
        meta = {}
    else:
        for key in ("domain", "audience", "goal", "lane", "as_of", "high_stakes", "assumptions"):
            if key not in meta:
                add(findings, "error", "META_FIELD", f"$.meta.{key}", "Required meta field is missing")
        for key in ("domain", "audience", "goal", "lane", "as_of"):
            if key in meta and not nonempty_string(meta[key]):
                add(findings, "error", "META_STRING", f"$.meta.{key}", "Must be a non-empty string")
        if "lane" in meta and meta.get("lane") not in {"FAST", "STANDARD", "DEEP"}:
            add(findings, "error", "LANE", "$.meta.lane", "lane must be FAST, STANDARD, or DEEP")
        if "high_stakes" in meta and not isinstance(meta.get("high_stakes"), bool):
            add(findings, "error", "HIGH_STAKES_TYPE", "$.meta.high_stakes", "high_stakes must be boolean")
        if "assumptions" in meta and not isinstance(meta.get("assumptions"), list):
            add(findings, "error", "ASSUMPTIONS_TYPE", "$.meta.assumptions", "assumptions must be an array")
        style = meta.get("style_reference")
        if style is not None:
            if not is_mapping(style):
                add(findings, "error", "STYLE_TYPE", "$.meta.style_reference", "style_reference must be an object")
            elif style.get("exact_creator_imitation") is True:
                add(findings, "error", "EXACT_IMITATION", "$.meta.style_reference.exact_creator_imitation", "Exact imitation of a living/real creator is prohibited")
        if meta.get("high_stakes") is True and not nonempty_string(meta.get("disclaimer")):
            add(findings, "error", "HIGH_STAKES_DISCLAIMER", "$.meta.disclaimer", "High-stakes output requires an educational-boundary disclaimer")

    # Claims
    claim_by_id: Dict[str, Mapping[str, Any]] = {}
    if not isinstance(claims, list) or not claims:
        add(findings, "error", "CLAIMS_TYPE", "$.claims", "claims must be a non-empty array")
        claims = []
    for index, raw_claim in enumerate(claims):
        path = f"$.claims[{index}]"
        if not is_mapping(raw_claim):
            add(findings, "error", "CLAIM_TYPE", path, "claim must be an object")
            continue
        claim = raw_claim
        claim_id = claim.get("id")
        if not nonempty_string(claim_id):
            add(findings, "error", "CLAIM_ID", f"{path}.id", "id must be a non-empty string")
            continue
        if claim_id in claim_by_id:
            add(findings, "error", "DUPLICATE_CLAIM", f"{path}.id", f"Duplicate claim id: {claim_id}")
        claim_by_id[claim_id] = claim
        if not nonempty_string(claim.get("statement")):
            add(findings, "error", "CLAIM_STATEMENT", f"{path}.statement", "statement must be non-empty")
        claim_type = claim.get("type")
        if claim_type not in CLAIM_TYPES:
            add(findings, "error", "CLAIM_LABEL", f"{path}.type", f"type must be one of {sorted(CLAIM_TYPES)}")
        importance = claim.get("importance")
        if importance not in IMPORTANCE:
            add(findings, "error", "IMPORTANCE", f"{path}.importance", f"importance must be one of {sorted(IMPORTANCE)}")
        freshness = claim.get("freshness_status")
        if freshness not in FRESHNESS:
            add(findings, "error", "FRESHNESS", f"{path}.freshness_status", f"freshness_status must be one of {sorted(FRESHNESS)}")
        confidence = claim.get("confidence")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 100:
            add(findings, "error", "CLAIM_CONFIDENCE", f"{path}.confidence", "confidence must be 0–100")
        sources = claim.get("sources")
        if not isinstance(sources, list):
            add(findings, "error", "SOURCES_TYPE", f"{path}.sources", "sources must be an array")
            sources = []
        if claim_type in {"fact", "inference", "estimate"} and not sources:
            add(findings, "error", "UNSUPPORTED_CLAIM", f"{path}.sources", f"{claim_type} claims require at least one source")
        for source_index, raw_source in enumerate(sources):
            source_path = f"{path}.sources[{source_index}]"
            if not is_mapping(raw_source):
                add(findings, "error", "SOURCE_TYPE", source_path, "source must be an object")
                continue
            source = raw_source
            for key in ("title", "url", "source_type", "retrieved_at"):
                if key not in source:
                    add(findings, "error", "SOURCE_FIELD", f"{source_path}.{key}", "Required source field is missing")
            if not nonempty_string(source.get("title")):
                add(findings, "error", "SOURCE_TITLE", f"{source_path}.title", "title must be non-empty")
            if not valid_url(source.get("url")):
                add(findings, "error", "SOURCE_URL", f"{source_path}.url", "url must be an http(s) URL")
            if source.get("source_type") not in SOURCE_TYPES:
                add(findings, "error", "SOURCE_KIND", f"{source_path}.source_type", f"source_type must be one of {sorted(SOURCE_TYPES)}")
            if not nonempty_string(source.get("retrieved_at")):
                add(findings, "error", "RETRIEVED_AT", f"{source_path}.retrieved_at", "retrieved_at must be non-empty")

    # Topics
    topic_by_id: Dict[str, Mapping[str, Any]] = {}
    if not isinstance(topics, list) or not topics:
        add(findings, "error", "TOPICS_TYPE", "$.topics", "topics must be a non-empty array")
        topics = []
    for index, raw_topic in enumerate(topics):
        path = f"$.topics[{index}]"
        if not is_mapping(raw_topic):
            add(findings, "error", "TOPIC_TYPE", path, "topic must be an object")
            continue
        topic = raw_topic
        topic_id = topic.get("id")
        if not nonempty_string(topic_id):
            add(findings, "error", "TOPIC_ID", f"{path}.id", "id must be non-empty")
            continue
        if topic_id in topic_by_id:
            add(findings, "error", "DUPLICATE_TOPIC", f"{path}.id", f"Duplicate topic id: {topic_id}")
        topic_by_id[topic_id] = topic
        for key in ("title", "thesis"):
            if not nonempty_string(topic.get(key)):
                add(findings, "error", "TOPIC_TEXT", f"{path}.{key}", f"{key} must be non-empty")
        score = topic.get("decision_score")
        confidence = topic.get("confidence")
        if isinstance(score, bool) or not isinstance(score, (int, float)) or not 0 <= score <= 100:
            add(findings, "error", "TOPIC_SCORE", f"{path}.decision_score", "decision_score must be 0–100")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 100:
            add(findings, "error", "TOPIC_CONFIDENCE", f"{path}.confidence", "confidence must be 0–100")
        status = topic.get("status")
        if status not in STATUSES:
            add(findings, "error", "TOPIC_STATUS", f"{path}.status", f"status must be one of {sorted(STATUSES)}")
        evidence_ids = topic.get("evidence_claim_ids")
        if not isinstance(evidence_ids, list) or not evidence_ids:
            add(findings, "error", "TOPIC_EVIDENCE", f"{path}.evidence_claim_ids", "evidence_claim_ids must be a non-empty array")
            evidence_ids = []
        for evidence_id in evidence_ids:
            if evidence_id not in claim_by_id:
                add(findings, "error", "UNKNOWN_CLAIM_REF", f"{path}.evidence_claim_ids", f"Unknown claim id: {evidence_id}")
        if status == "Actionable" and isinstance(confidence, (int, float)) and confidence < 65:
            add(findings, "error", "ACTIONABLE_CONFIDENCE", f"{path}.confidence", "Actionable topics require confidence >= 65")

    # Selection and selected-topic gates
    selected_topic: Mapping[str, Any] | None = None
    if not nonempty_string(selected_id):
        add(findings, "error", "SELECTED_ID", "$.selected_topic_id", "selected_topic_id must be non-empty")
    elif selected_id not in topic_by_id:
        add(findings, "error", "SELECTED_UNKNOWN", "$.selected_topic_id", "selected_topic_id does not match a topic")
    else:
        selected_topic = topic_by_id[selected_id]
        selected_claim_ids = selected_topic.get("evidence_claim_ids", [])
        selected_claims = [claim_by_id[cid] for cid in selected_claim_ids if cid in claim_by_id]
        for claim in selected_claims:
            if claim.get("importance") == "core":
                if claim.get("type") == "unverified":
                    add(findings, "error", "CORE_UNVERIFIED", f"$.claims[{claim.get('id')}]", "Selected-topic core claims cannot be unverified")
                if claim.get("freshness_status") in {"Missing", "Conflicting"}:
                    add(findings, "error", "CORE_EVIDENCE_STATE", f"$.claims[{claim.get('id')}].freshness_status", "Selected-topic core claims cannot be Missing or Conflicting")
                if selected_topic.get("status") == "Actionable" and claim.get("freshness_status") == "Stale":
                    add(findings, "error", "ACTIONABLE_STALE", f"$.claims[{claim.get('id')}].freshness_status", "Actionable selected-topic core claims cannot be Stale")
        if meta.get("high_stakes") is True:
            has_official = any(
                source.get("source_type") in {"official", "primary"}
                for claim in selected_claims
                for source in claim.get("sources", [])
                if is_mapping(source)
            )
            if not has_official:
                add(findings, "error", "HIGH_STAKES_SOURCE", "$.claims", "High-stakes selected topic requires at least one official or primary source")

    # Script
    if not is_mapping(script):
        add(findings, "error", "SCRIPT_TYPE", "$.script", "script must be an object")
    else:
        for field in SCRIPT_FIELDS:
            if not nonempty_string(script.get(field)):
                add(findings, "error", "SCRIPT_FIELD", f"$.script.{field}", "Required script section must be non-empty")
        if nonempty_string(script.get("risk")) and len(script["risk"].strip()) < 20:
            add(findings, "warning", "THIN_RISK", "$.script.risk", "Risk/countercase section is unusually short")

    # Global guarantee scan
    for path, text in walk_strings(payload):
        for pattern in GUARANTEE_PATTERNS:
            if pattern.search(text):
                add(findings, "error", "GUARANTEE_LANGUAGE", path, f"Prohibited guarantee/risk-free language matched: {pattern.pattern}")
                break

    return findings


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ContractError(f"input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError(f"invalid JSON: line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Structured deliverable JSON")
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failures")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable findings")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = load_json(args.input)
    except ContractError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    findings = validate(payload)
    errors = [f for f in findings if f.severity == "error"]
    warnings = [f for f in findings if f.severity == "warning"]
    failed = bool(errors) or (args.strict and bool(warnings))

    if args.json:
        print(json.dumps({
            "status": "FAIL" if failed else "PASS",
            "errors": len(errors),
            "warnings": len(warnings),
            "findings": [f.as_dict() for f in findings],
        }, ensure_ascii=False, indent=2))
    else:
        for finding in findings:
            print(f"{finding.severity.upper()} {finding.code} {finding.path}: {finding.message}")
        print(f"{'FAIL' if failed else 'PASS'}: {len(errors)} error(s), {len(warnings)} warning(s)")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
