#!/usr/bin/env python3
"""Score and rank high-ROI commercial insight topics.

The script is deterministic and uses only the Python standard library.
It separates value, risk, and evidence confidence, then assigns a decision state.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

VALUE_WEIGHTS: Dict[str, float] = {
    "economic_pain_wtp": 18.0,
    "monetization_adjacency": 14.0,
    "audience_relevance": 12.0,
    "structural_tailwind": 12.0,
    "evidence_density": 10.0,
    "actionability": 10.0,
    "insight_gap": 8.0,
    "personal_fit": 8.0,
    "shelf_life": 5.0,
    "platform_fit": 3.0,
}

RISK_MAX_DEDUCTIONS: Dict[str, float] = {
    "hype": 8.0,
    "evidence_conflict": 8.0,
    "regulatory_sensitivity": 6.0,
    "capital_or_access_barrier": 6.0,
    "market_saturation": 5.0,
    "creator_fit_gap": 4.0,
    "freshness_decay": 3.0,
}

CONFIDENCE_WEIGHTS: Dict[str, float] = {
    "evidence_quality": 35.0,
    "source_diversity": 25.0,
    "freshness": 20.0,
    "claim_support_coverage": 20.0,
}

ROI_FIELDS = ("attention", "cognitive", "commercial", "execution")


class InputError(ValueError):
    """Raised when an input file violates the scoring contract."""


def _number(value: Any, path: str, minimum: float = 0.0, maximum: float = 10.0) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InputError(f"{path} must be a number between {minimum} and {maximum}")
    number = float(value)
    if not math.isfinite(number) or number < minimum or number > maximum:
        raise InputError(f"{path} must be between {minimum} and {maximum}; got {value!r}")
    return number


def _mapping(value: Any, path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise InputError(f"{path} must be an object")
    return value


def _required_scores(
    container: Mapping[str, Any],
    required: Mapping[str, float],
    path: str,
) -> Dict[str, float]:
    unknown = sorted(set(container) - set(required))
    missing = sorted(set(required) - set(container))
    if missing:
        raise InputError(f"{path} missing fields: {', '.join(missing)}")
    if unknown:
        raise InputError(f"{path} has unknown fields: {', '.join(unknown)}")
    return {key: _number(container[key], f"{path}.{key}") for key in required}


def validate_payload(payload: Any) -> List[Mapping[str, Any]]:
    root = _mapping(payload, "root")
    topics = root.get("topics")
    if not isinstance(topics, list) or not topics:
        raise InputError("root.topics must be a non-empty array")

    seen_ids = set()
    validated: List[Mapping[str, Any]] = []
    for index, item in enumerate(topics):
        path = f"root.topics[{index}]"
        topic = _mapping(item, path)
        topic_id = topic.get("id")
        title = topic.get("title")
        if not isinstance(topic_id, str) or not topic_id.strip():
            raise InputError(f"{path}.id must be a non-empty string")
        if topic_id in seen_ids:
            raise InputError(f"duplicate topic id: {topic_id}")
        seen_ids.add(topic_id)
        if not isinstance(title, str) or not title.strip():
            raise InputError(f"{path}.title must be a non-empty string")
        if "thesis" in topic and not isinstance(topic["thesis"], str):
            raise InputError(f"{path}.thesis must be a string")
        _required_scores(_mapping(topic.get("dimensions"), f"{path}.dimensions"), VALUE_WEIGHTS, f"{path}.dimensions")
        _required_scores(_mapping(topic.get("risks"), f"{path}.risks"), RISK_MAX_DEDUCTIONS, f"{path}.risks")
        _required_scores(_mapping(topic.get("confidence"), f"{path}.confidence"), CONFIDENCE_WEIGHTS, f"{path}.confidence")
        roi = _mapping(topic.get("roi"), f"{path}.roi")
        missing_roi = sorted(set(ROI_FIELDS) - set(roi))
        unknown_roi = sorted(set(roi) - set(ROI_FIELDS))
        if missing_roi:
            raise InputError(f"{path}.roi missing fields: {', '.join(missing_roi)}")
        if unknown_roi:
            raise InputError(f"{path}.roi has unknown fields: {', '.join(unknown_roi)}")
        for key in ROI_FIELDS:
            _number(roi[key], f"{path}.roi.{key}")
        validated.append(topic)
    return validated


def decision_status(score: float, confidence: float) -> str:
    if confidence < 50.0:
        return "Watch" if score >= 60.0 else ("Observe" if score >= 45.0 else "Reject")
    if score >= 75.0 and confidence >= 65.0:
        return "Actionable"
    if score >= 60.0:
        return "Watch"
    if score >= 45.0:
        return "Observe"
    return "Reject"


def score_topic(topic: Mapping[str, Any]) -> Dict[str, Any]:
    dimensions = topic["dimensions"]
    risks = topic["risks"]
    confidence_parts = topic["confidence"]
    roi = topic["roi"]

    base_score = sum(float(dimensions[key]) / 10.0 * weight for key, weight in VALUE_WEIGHTS.items())
    risk_deduction = sum(float(risks[key]) / 10.0 * maximum for key, maximum in RISK_MAX_DEDUCTIONS.items())
    confidence = sum(float(confidence_parts[key]) / 10.0 * weight for key, weight in CONFIDENCE_WEIGHTS.items())
    uncertainty_penalty = (100.0 - confidence) * 0.15
    final_score = max(0.0, min(100.0, base_score - risk_deduction - uncertainty_penalty))

    return {
        "id": topic["id"],
        "title": topic["title"],
        "thesis": topic.get("thesis", ""),
        "attention_roi": round(float(roi["attention"]), 1),
        "cognitive_roi": round(float(roi["cognitive"]), 1),
        "commercial_roi": round(float(roi["commercial"]), 1),
        "execution_roi": round(float(roi["execution"]), 1),
        "base_score": round(base_score, 2),
        "risk_deduction": round(risk_deduction, 2),
        "confidence": round(confidence, 2),
        "uncertainty_penalty": round(uncertainty_penalty, 2),
        "decision_score": round(final_score, 2),
        "status": decision_status(final_score, confidence),
    }


def score_payload(payload: Any) -> List[Dict[str, Any]]:
    topics = validate_payload(payload)
    rows = [score_topic(topic) for topic in topics]
    rows.sort(key=lambda row: (-row["decision_score"], -row["confidence"], row["id"]))
    for rank, row in enumerate(rows, start=1):
        row["rank"] = rank
    return rows


def format_markdown(rows: Sequence[Mapping[str, Any]]) -> str:
    headers = [
        "排名", "ID", "题目", "R1", "R2", "R3", "R4",
        "基础分", "风险扣分", "置信度", "不确定性", "决策分", "状态",
    ]
    keys = [
        "rank", "id", "title", "attention_roi", "cognitive_roi",
        "commercial_roi", "execution_roi", "base_score", "risk_deduction",
        "confidence", "uncertainty_penalty", "decision_score", "status",
    ]
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in rows:
        values = [str(row[key]).replace("|", "\\|").replace("\n", " ") for key in keys]
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def format_csv(rows: Sequence[Mapping[str, Any]]) -> str:
    output = io.StringIO()
    fields = [
        "rank", "id", "title", "thesis", "attention_roi", "cognitive_roi",
        "commercial_roi", "execution_roi", "base_score", "risk_deduction",
        "confidence", "uncertainty_penalty", "decision_score", "status",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().rstrip("\r\n")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise InputError(f"input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise InputError(f"invalid JSON in {path}: line {exc.lineno}, column {exc.colno}: {exc.msg}") from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Input JSON file")
    parser.add_argument("--format", choices=("markdown", "json", "csv"), default="markdown")
    parser.add_argument("--output", type=Path, help="Optional output path; stdout when omitted")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        rows = score_payload(load_json(args.input))
    except InputError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if args.format == "json":
        rendered = json.dumps({"topics": rows}, ensure_ascii=False, indent=2)
    elif args.format == "csv":
        rendered = format_csv(rows)
    else:
        rendered = format_markdown(rows)

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
