# 目标架构

## 1. 架构结论

采用 **单一聚焦 Skill + 渐进式引用 + 3 个零依赖确定性脚本 + 可执行评估集**。不构建完整 SaaS、爬虫、数据库、MCP 或自动发布系统。

原因：当前目标是让 Codex 在不同项目中稳定执行一套研究—评分—叙事流程；平台化会显著增加依赖、权限、维护和 token 成本，并偏离“创建 Skill”的单一任务。

## 2. 目录结构

```text
research-high-roi-content/
├── SKILL.md
├── agents/
│   └── openai.yaml
├── references/
│   ├── workflow.md
│   ├── research-protocol.md
│   ├── scoring-rubric.md
│   ├── style-framework.md
│   ├── output-contracts.md
│   ├── evidence-and-safety.md
│   └── evaluation.md
├── scripts/
│   ├── score_topics.py
│   ├── validate_deliverable.py
│   └── validate_skill.py
├── assets/
│   ├── intake-template.md
│   ├── topic-card-template.md
│   ├── script-template.md
│   ├── evidence-ledger.csv
│   ├── topic-score-input.example.json
│   └── deliverable.example.json
├── evals/
│   ├── trigger_cases.jsonl
│   ├── quality_cases.jsonl
│   └── benchmark-template.csv
└── tests/
    └── test_scripts.py
```

## 3. 运行时数据流

```text
用户输入
  │
  ├─► 范围与默认值解析
  │      └─ FAST / STANDARD / DEEP
  │
  ├─► 价值链与付费痛点地图
  │
  ├─► 候选选题宽搜
  │      ├─ 官方/第一方证据
  │      ├─ 市场与竞争证据
  │      └─ 社区问题信号（只证明痛点，不证明事实）
  │
  ├─► 来源去重 + 证据台账
  │
  ├─► 反证与冲突查询
  │
  ├─► 四类 ROI + 风险 + 置信度评分
  │
  ├─► Top N 深研
  │
  ├─► 商业机制原创叙事
  │
  ├─► 盲点 / surprise / 合规检查
  │
  └─► Radar / Dossier / Script / Series / Business Bridge / Audit
```

## 4. 宽进窄出性能策略

| 阶段 | 宽度 | 深度 | 目的 |
|---|---:|---:|---|
| 领域扫描 | 高 | 低 | 找价值池，不做长文 |
| 粗筛 | 中 | 低 | 排除无买方、无证据、重资产、纯炒作 |
| 评分 | 中 | 中 | 分离价值、风险、置信度 |
| Top N 深研 | 低 | 高 | 集中研究预算 |
| 成稿 | 1–3 个 | 高 | 单写者保证一致性 |

## 5. Agent 角色边界

### 主代理

- 负责需求、假设、评分、最终选择、写作和质量门禁。
- 保持完整证据台账和决策链。

### 可选子代理

只在 DEEP 档位使用，最多 4 个，且为只读任务：

1. 价值链/付费痛点扫描。
2. 竞争与既有内容空白。
3. 官方/监管/技术事实核验。
4. 反证与相邻盲点。

所有子代理返回摘要和来源，不直接写最终稿，不并行修改文件。

## 6. 不采用的架构

| 方案 | 不采用原因 |
|---|---|
| 巨型单 Prompt | 难测试、难触发、上下文浪费、维护性差 |
| 全自动多代理流水线 | token 与协调成本可能吞噬 ROI；写入冲突 |
| 内置平台爬虫 | 访问条款、登录、版权、维护和安全风险 |
| 统一一个 ROI 分 | 隐藏注意力与商业价值的错位 |
| 只做短视频脚本 | 无法复用到研究、系列、咨询与产品化资产 |
| 自动发布 | 缺少事实、品牌与合规人工审核 |
