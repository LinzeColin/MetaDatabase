# Codex 执行入口

## 结论与默认动作

本任务包已经完成外部只读调研、需求抽象、架构设计、Skill 草案、确定性脚本、测试样例和盲点复核。Codex 的任务不是重新发散设计，而是：

1. 核验当前 Codex Skill 规范是否变化。
2. 审计并小幅优化 `skill_draft/research-high-roi-content/`。
3. 安装为可用 Skill。
4. 完成结构、脚本、触发和质量验证。

默认安装位置：`$HOME/.agents/skills/research-high-roi-content`。

## 最小起始读取

先只读取以下 4 个文件：

1. `AGENTS.md`
2. `START_HERE_FOR_CODEX.md`
3. `CODEX_MASTER_TASK.md`
4. `skill_draft/research-high-roi-content/SKILL.md`

随后按阶段加载，不要一次把整个任务包塞进上下文：

| 阶段 | 再读取 | 用途 |
|---|---|---|
| P0 需求/冲突 | `USER_REQUIREMENTS.md`、`DECISIONS_AND_DEFAULTS.md` | 核对目标、默认值和是否真的需要提问 |
| P0 官方核验 | `RESEARCH_REPORT.md`、`REFERENCE_PROJECT_MATRIX.md` | 复用已完成调研，只检查当前规范差异 |
| P1 实现 | `TARGET_ARCHITECTURE.md`、`IMPLEMENTATION_PLAN.md` | 限定文件、任务和回滚 |
| P2-P3 验证 | `ACCEPTANCE_CHECKLIST.md`、Skill 内 `references/evaluation.md` | 执行机械和语义门禁 |
| P4 交付 | `BLIND_SPOTS_AND_SURPRISES.md`、`VALIDATION_REPORT.md` | 最终盲点、未完成验证与真实剩余风险 |

不要先扫描整个仓库。只读取本任务包、当前阶段明确需要的文件和拟安装目标目录。

## 执行模式

| 阶段 | 模式 | 允许动作 | 退出条件 |
|---|---|---|---|
| P0 | 只读 | 检查规范、目标目录、冲突、现有 Skill | 给出最小实施计划 |
| P1 | 实现 | 仅修改目标 Skill 目录 | 草案通过本地验证 |
| P2 | 验证 | 运行脚本、单测、官方验证器 | 所有阻断项通过 |
| P3 | 前向测试 | 新鲜线程/子代理执行触发与质量用例 | 达到验收阈值 |
| P4 | 安装交付 | 备份旧版、原子复制、复验 | Skill 可发现、可调用、可回滚 |

## 关键默认值

- 用户默认语言：中文。
- 用户默认画像：个人研究者/内容创作者/顾问/小团队；不依赖重资产、牌照或大组织资源。
- 默认工作流：先证据、再评分、后叙事。
- 默认研究档位：STANDARD。
- 默认输出：领域价值池 + 12 个选题雷达 + Top 3 深拆 + 1 个原创解说结构。
- 默认不追问；仅当缺失信息会实质改变范围、合规或验收时，最多提出 3 个编号问题，并同时给出推荐默认值。
- 默认不启用多代理；只有 DEEP 档位且任务可并行、以只读研究为主时才启用。

## 最小测试命令

在任务包根目录运行：

```bash
python3 skill_draft/research-high-roi-content/scripts/validate_skill.py \
  skill_draft/research-high-roi-content

python3 -m unittest discover \
  -s skill_draft/research-high-roi-content/tests -v

python3 skill_draft/research-high-roi-content/scripts/score_topics.py \
  --input skill_draft/research-high-roi-content/assets/topic-score-input.example.json \
  --format markdown

python3 skill_draft/research-high-roi-content/scripts/validate_deliverable.py \
  --input skill_draft/research-high-roi-content/assets/deliverable.example.json \
  --strict
```

若当前 `$skill-creator` 暴露官方 `quick_validate.py`，再对最终 Skill 运行官方验证器；不要猜测固定路径，先从当前系统 Skill 的真实路径定位。

## 完成定义

只有在以下项目全部满足时才结束：

- 目标目录只有本 Skill 的预期文件。
- `SKILL.md` frontmatter 仅包含 `name` 与 `description`。
- 所有 Python 脚本无第三方依赖并通过测试。
- 10 个正向触发样例与 10 个负向样例达到阈值。
- 3 个代表任务完成 A/B 前向测试，Skill 版本在证据完整性、机制深度或行动性上有可见提升，且没有不可接受的成本膨胀。
- 没有精确模仿现实创作者、无来源事实、收益保证或高风险个性化建议。
- 最终给出安装位置、变更摘要、测试结果、回滚命令和剩余风险。
