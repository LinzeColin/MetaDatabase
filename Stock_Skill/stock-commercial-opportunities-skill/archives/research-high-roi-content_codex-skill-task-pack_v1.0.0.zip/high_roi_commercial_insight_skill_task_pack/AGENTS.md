# Project instructions for Codex

## Scope

- Work on one issue only: create or upgrade `research-high-roi-content`.
- Read only this task-pack directory and the exact destination skill directory unless a test failure identifies a specific additional file.
- Do not scan the whole repository, home directory, or unrelated skills.
- Do not refactor unrelated files or add platform integrations.

## Workflow

1. Start in read-only mode.
2. Verify current official Codex Skill documentation before relying on paths or metadata fields.
3. List files to read, files to create/modify, test commands, and rollback before writing.
4. Use the bundled draft as the baseline; prefer minimal diffs over redesign.
5. Run deterministic checks before semantic evaluations.
6. Use subagents only for independent, read-heavy checks. Never let parallel agents write the same files.
7. Keep final synthesis and installation single-writer.

## Safety and integrity

- Never fabricate sources, figures, dates, market sizes, ROI, quotes, or case studies.
- Separate facts, inferences, estimates, and opinions.
- Do not produce personalized financial, medical, legal, tax, or regulatory advice.
- Do not guarantee revenue, investment returns, traffic, virality, conversion, or ranking.
- Do not imitate a living creator's exact voice, signature phrases, or distinctive expression. Extract only high-level structural traits and produce original wording.
- Do not scrape login-gated, paywalled, private, or terms-restricted platforms. Do not automate publishing.
- Do not copy third-party repository code. Architectural ideas may be independently reimplemented and attributed in research notes.

## Quality bar

- One focused skill, progressive disclosure, concise `SKILL.md`.
- Deterministic behavior belongs in tested scripts; flexible judgment stays in instructions.
- Every output mode must have explicit inputs, outputs, stop conditions, evidence rules, and acceptance checks.
- Preserve low-cost defaults: FAST/STANDARD/DEEP lanes, wide-to-narrow research, source deduplication, optional read-only parallelism.

## Handoff

Report:

- exact install path;
- files changed;
- validation and test commands with results;
- trigger-eval and quality-eval summary;
- performance/cost observations;
- rollback command;
- unresolved risks only, not speculative filler.
