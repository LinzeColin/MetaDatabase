# 包内容说明

## 根目录

- `CODEX_START_PROMPT.txt`：复制给 Codex 的最短入口。
- `START_HERE_FOR_CODEX.md`：执行顺序和完成定义。
- `AGENTS.md`：范围、工作流和安全约束。
- `CODEX_MASTER_TASK.md`：完整实施任务。
- `USER_REQUIREMENTS.md`：痛点、用户画像和非目标。
- `DECISIONS_AND_DEFAULTS.md`：无需追问的默认决策。
- `RESEARCH_REPORT.md`：公开网络与 GitHub 调研。
- `REFERENCE_PROJECT_MATRIX.md`：同类项目对比。
- `TARGET_ARCHITECTURE.md`：目标目录与运行架构。
- `IMPLEMENTATION_PLAN.md`：任务颗粒度、测试与风险。
- `ACCEPTANCE_CHECKLIST.md`：验收门禁。
- `BLIND_SPOTS_AND_SURPRISES.md`：盲点和反直觉发现。
- `LICENSE_AND_ATTRIBUTION.md`：第三方引用边界。
- `VALIDATION_REPORT.md`：本任务包生成时的本地验证结果。
- `MANIFEST.sha256`：文件完整性哈希。

## Skill 草案

`skill_draft/research-high-roi-content/` 已是可实现基线，包含：

- 核心 `SKILL.md`；
- UI 元数据；
- 7 个渐进披露参考文件；
- 3 个标准库脚本；
- 6 个模板/示例资产；
- 触发和质量评估集；
- 单元测试。
