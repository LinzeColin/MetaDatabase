# 参考项目与方法矩阵

> 快照日期：2026-07-19。License 只按当日仓库元数据/文件记录；`unasserted` 表示本任务包不据此授予复制权。实际复用前需重新核验。这里仅采用可独立实现的概念模式。

| 参考 | 类型 | 可借鉴模式 | 不直接采用/警示 | License/边界 |
|---|---|---|---|---|
| [OpenAI Skills](https://github.com/openai/skills) | 官方示例 | focused Skill、渐进披露、资源目录 | 不把所有工作塞进一个 Skill | 以仓库当前文件为准 |
| [STORM](https://github.com/stanford-oval/storm) | 深度研究 | 多视角研究、引用组织 | 不是客户需求验证器 | MIT snapshot |
| [Open Deep Research](https://github.com/langchain-ai/open_deep_research) | 深度研究 | 可配置研究 agent | 引用契约仍会冲突；见 #232 | MIT snapshot |
| [GPT Researcher](https://github.com/assafelovic/gpt-researcher) | 深度研究 | 多来源报告与执行流水线 | 空上下文幻觉、snippet/fulltext 混淆风险 | Apache-2.0 snapshot |
| [TrendRadar](https://github.com/sansan0/TrendRadar) | 趋势聚合 | signal 聚合、雷达化输出 | 热度不等于付费问题；GPL 不能随意拷贝 | GPL-3.0 snapshot |
| [TubeFlow](https://github.com/wnstify/tubeflow) | 内容工作流 | 视频研究到选题的窄流程 | 内容只作为 v2 可选下游 | MIT snapshot |
| [Product-Manager-Skills](https://github.com/deanpeters/Product-Manager-Skills) | PM Skills | OST、landscape、TAM/SAM/SOM 分工 | 部分元数据不能原样当 OpenAI frontmatter；代码不复制 | unasserted |
| [phuryn/pm-skills](https://github.com/phuryn/pm-skills) | PM Skills | discovery/assumption/market/GTM 分离 | 避免巨型单提示 | MIT snapshot |
| [wondelai/skills](https://github.com/wondelai/skills) | Discovery Skills | JTBD、non-consumption、push/pull/anxiety/habit | 访谈结构不自动产生真实访谈 | MIT snapshot |
| [mission-control](https://github.com/crshdn/mission-control) | 产品流水线 | research→human swipe→build/test/review；cost cap | 自动构建/分发超出本 Skill | MIT snapshot |
| [OpenSEO](https://github.com/every-app/open-seo) | SEO workflows | 聚焦工作流、关键词/竞品信号 | SEO signal 不能证明 demand | MIT snapshot |
| [paper2product](https://github.com/Agentra-Labs/paper2product) | 研究到产品 | pain scanner、temporal arbitrage、red-team destroyer | 低成熟项目；仅作为 surprise lens | unasserted |
| [Emotix OSS](https://github.com/agshinrajabov/emotix-oss) | 市场研究产品 | 研究管线、失败复盘 | 产品能工作仍无 PMF；distribution 关键 | MIT snapshot；archived |
| [Expected Parrot EDSL](https://github.com/expectedparrot/edsl) | 合成研究 | 研究协议预试、问卷模拟 | AI 响应非真实群体意见 | MIT snapshot |
| [Product Talk OST](https://www.producttalk.org/2016/08/opportunity-solution-tree/) | 方法 | outcome→opportunity→solution→experiment | 需客户理论和故事访谈前置 | 方法引用，不复制文本 |
| [Strategyzer Test Card](https://www.strategyzer.com/library/validate-your-ideas-with-the-test-card) | 方法 | 假设/测试/度量/阈值 | 需要真实执行证据 | 方法引用，不复制模板表达 |
| [Strategyn ODI](https://strategyn.com/outcome-driven-innovation-process/) | 方法 | importance + underserved outcomes | 仍需验证 reachability/value capture | 方法引用 |
| [Productboard Insights](https://www.productboard.com/product/insights/) | 商业产品 | feedback→insight→feature/opportunity traceability | 产品营销页不证明结果 | 产品形态参考 |
| [Dovetail](https://dovetail.com/customer-insights/) | 商业产品 | 客户证据集中、分析、分享 | 持久数据与权限超出 Skill | 产品形态参考 |
| [ITONICS](https://www.itonics-innovation.com/) | 创新平台 | signals/trends/opportunities pipeline | 重平台，不内嵌 | 产品形态参考 |
| [FIBRES](https://www.fibresonline.com/) | 趋势平台 | foresight radar、signals | trend 不等于 demand | 产品形态参考 |
| [Qmarkets](https://www.qmarkets.net/) | 创新平台 | idea/opportunity portfolio | 企业治理层超出 Skill | 产品形态参考 |

## 选择矩阵

| 能力 | Skill v2 | 未来产品层 | 排除 |
|---|:---:|:---:|:---:|
| Decision Contract、机会卡、验证卡 | ✓ | 可持久化 | — |
| 来源/主张/假设/实验 ID 关系 | ✓ | 可图谱化 | — |
| M0–M5 与 Go gates | ✓ | 可做 portfolio dashboard | — |
| 标准库评分/校验 | ✓ | 可服务化 | — |
| 团队权限、CRM、洞察数据库 | — | ✓ | — |
| 真实客户招募/支付/交付 | 仅设计门禁 | 需授权集成/人工执行 | — |
| 登录态抓取、绕过访问控制 | — | — | ✓ |
| AI persona 代替真实客户 | — | — | ✓ |
| 自动发布/自动外联 | — | 仅独立授权后评估 | 默认排除 |

## 复用规则

只复用方法层模式、术语映射和公开接口思想；不复制仓库代码、模板原文、品牌资产、私有数据或 License 不明内容。若未来引入代码，必须另开依赖审计、License 归属和 NOTICE 更新任务。
