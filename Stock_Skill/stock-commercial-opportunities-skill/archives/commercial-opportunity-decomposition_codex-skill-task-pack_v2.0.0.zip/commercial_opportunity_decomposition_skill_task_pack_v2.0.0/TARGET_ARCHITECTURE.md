# 目标架构

## 架构结论

采用“单一聚焦 Skill + 一层渐进披露 + 3 个标准库脚本 + 模板/评估集”。不在 Skill 内建数据库、浏览器自动化、CRM、爬虫、MCP 或发布系统；需要持久洞察库时再作为独立产品层。

## 目录

```text
qualify-commercial-opportunities/
├── SKILL.md
├── agents/openai.yaml
├── references/
│   ├── workflow.md
│   ├── opportunity-model.md
│   ├── evidence-protocol.md
│   ├── scoring-and-maturity.md
│   ├── validation-experiments.md
│   ├── output-contracts.md
│   ├── safety-and-boundaries.md
│   ├── content-activation.md
│   └── evaluation.md
├── scripts/
│   ├── score_opportunities.py
│   ├── validate_deliverable.py
│   └── validate_skill.py
├── assets/
│   ├── intake-template.md
│   ├── opportunity-card-template.md
│   ├── validation-card-template.md
│   ├── script-template.md
│   ├── evidence-ledger.csv
│   ├── opportunity-score-input.example.json
│   └── deliverable.example.json
├── evals/
│   ├── trigger_cases.jsonl
│   ├── quality_cases.jsonl
│   └── benchmark-template.csv
└── tests/test_scripts.py
```

## 决策流

```mermaid
flowchart LR
  A["Decision Contract"] --> B["Evidence Register"]
  B --> C["Problem / buyer / payer / alternative"]
  C --> D["Attractiveness + risk + confidence"]
  D --> E["Evidence maturity M0-M5"]
  E --> F{"Decision gate"}
  F -->|STOP/WATCH| G["Kill, park, or reopen condition"]
  F -->|TEST_NEXT| H["Highest-VOI Validation Card"]
  F -->|GO_PILOT/SCALE| I["Authorized delivery gate"]
  H --> J["Evidence update"]
  J --> E
  F -. optional .-> K["Content activation"]
```

## 数据边界

- Source Register 是所有事实 URL 与私有 locator 的 allowlist。
- Claim、Opportunity、Assumption、Experiment 通过 ID 建立可审计关系。
- `origin=private` 与 `output_visibility=public` 时必须脱敏；原始私有材料不进入公共包。
- `snippet_only` 与 `synthetic` 不能独立支撑 core claim。
- 完成实验必须引用真实 evidence source；未运行或无证据不得写 `passed`。

## 性能策略

| 阶段 | 候选/来源上限 | 停止条件 | 成本控制 |
|---|---:|---|---|
| SCOUT | 候选 ≤8；来源家族 3–6 | 两轮无新 problem/buyer/alternative | 只做轻量卡片 |
| QUALIFY | 深拆 ≤3 | 关键主张可判、矛盾已标注或 cap 达到 | 只打开支撑核心决定的来源 |
| VALIDATE | 默认 1 个实验 | pass/fail/stop/timebox | 先做最可逆、最高 VOI 测试 |

## 不采用的方案

| 方案 | 原因 |
|---|---|
| 固定 12 个候选/Top 3 | 激励填充并增加研究成本 |
| 单一“机会分” | 隐藏证据成熟度和风险 |
| AI personas 作为买方证明 | 不代表真实群体行为 |
| 自动多 agent | 不是本 Skill 的必要条件，协调和 token 成本不稳定 |
| 自动外联/发布 | 权限、品牌、隐私和合规风险 |
| 一步做成洞察 SaaS | 明显超出 Skill 的维护和授权边界 |
