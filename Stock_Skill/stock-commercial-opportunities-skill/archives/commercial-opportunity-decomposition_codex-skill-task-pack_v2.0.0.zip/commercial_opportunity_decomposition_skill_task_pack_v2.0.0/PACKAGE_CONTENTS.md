# 包内容索引

## 任务包层

| 文件 | 用途 |
|---|---|
| `START_HERE_FOR_CODEX.md` | 最小读取顺序与当前 Gate |
| `AGENTS.md` | 执行、证据、权限与工程约束 |
| `CODEX_MASTER_TASK.md` | 单一目标、Gate、Run Contract 入口 |
| `USER_REQUIREMENTS.md` | 痛点、业务区分与非目标 |
| `DECISIONS_AND_DEFAULTS.md` | v2 破坏性决策和唯一待确认项 |
| `RESEARCH_REPORT.md` | 公开研究、Issues、方法与设计映射 |
| `REFERENCE_PROJECT_MATRIX.md` | 参考项目、可借鉴模式、License 边界 |
| `TARGET_ARCHITECTURE.md` | 目录、数据流、边界和性能策略 |
| `IMPLEMENTATION_PLAN.md` | R00–H01 任务颗粒度与 RC-0–RC-3 |
| `ACCEPTANCE_CHECKLIST.md` | 定位、证据、实验、安全、自动/语义验收 |
| `VALIDATION_REPORT.md` | 同次实际命令、结果、未运行项 |
| `BLIND_SPOTS_AND_SURPRISES.md` | 红队盲点、surprise 与剩余边界 |
| `LICENSE_AND_ATTRIBUTION.md` | 独立实现、外部参考与依赖说明 |
| `CHANGELOG.md`, `VERSION` | 2.0.0 迁移记录 |
| `MANIFEST.sha256` | 最终文件完整性 |
| `CODEX_START_PROMPT.txt` | 下一线程最小启动指令 |

## Skill 层

`skill_draft/qualify-commercial-opportunities/` 是可 staging 的草案：

- `SKILL.md` 与 `agents/openai.yaml`：触发与产品界面。
- `references/`：workflow、机会模型、证据协议、评分/成熟度、实验、输出、安全、内容激活、评估。
- `scripts/`：机会评分、结构化交付验证、Skill 包验证。
- `assets/`：intake、Opportunity/Validation Card、证据台账、示例输入/交付。
- `evals/`：22 个触发用例、8 个质量用例和 benchmark schema。
- `tests/`：26 个确定性回归测试。

## 不包含

已安装 Skill、目标目录备份、真实客户/财务/账号数据、抓取缓存、模型 A/B 原始输出、虚构 benchmark、外部仓库代码、平台凭证或自动发布配置。
