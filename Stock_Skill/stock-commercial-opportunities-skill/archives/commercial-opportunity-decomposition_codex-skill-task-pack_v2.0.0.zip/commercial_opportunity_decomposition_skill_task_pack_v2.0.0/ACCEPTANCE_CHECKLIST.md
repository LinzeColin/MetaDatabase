# 验收清单

状态只允许 `PASS / FAIL / BLOCKED / NOT_RUN / NOT_AVAILABLE`；没有同次证据不得勾选 PASS。

## A. 定位与契约

- [ ] `name=qualify-commercial-opportunities` 且目录一致。
- [ ] 中文显示名为“商业机会拆解”。
- [ ] 核心 job 是商业机会资格与验证，不是内容批量生成。
- [ ] `SCOUT / QUALIFY / VALIDATE` 均有输入、输出、cap 和停止条件。
- [ ] 内容仅为可选下游，继承 opportunity ID/status/maturity。
- [ ] 允许 `0` 个合格候选和 `NO_QUALIFIED_OPPORTUNITY`。

## B. 商业模型

- [ ] problem actor、struggling moment、经济后果可分辨。
- [ ] user/problem owner/payer/budget owner/veto 不混写。
- [ ] current alternative/non-consumption 有证据或标为假设。
- [ ] distribution/procurement 为一级维度，不用“发内容”作默认答案。
- [ ] value delivered、price logic、delivery cost 和 value capture 可检验。
- [ ] why now 与 window decay 可证伪。
- [ ] 机会吸引力、风险、置信度、证据成熟度分开呈现。

## C. 证据与成熟度

- [ ] 每个核心事实/推断有 source IDs。
- [ ] 所有 URL 在 Source Register；未注册 URL 被阻断。
- [ ] `snippet_only`/`synthetic` 不能单独支撑 core claim。
- [ ] 公开桌面研究最高 `M1`。
- [ ] `M2` 需要真实访谈与观察问题；`M3` 需要承诺或交易。
- [ ] `M4` 需要交易与成功交付；`M5` 需要重复/复购证据。
- [ ] 高吸引力 `M1` 不能标 `GO_PILOT/GO_SCALE`。
- [ ] 冲突、过期和缺失证据导致降级，不被平均分掩盖。

## D. 验证实验

- [ ] 每个实验绑定一个 opportunity 和 assumption。
- [ ] 假设、目标 segment、行为/事件、metric 与 denominator 明确。
- [ ] pass、fail/stop threshold 在运行前写定。
- [ ] timebox、cash/coordination cap、owner 和隐私边界明确。
- [ ] pass/fail/inconclusive 三分支会改变决定。
- [ ] 未运行或无证据的实验不能标 completed/passed。
- [ ] 默认只推荐一个最高 VOI 下一实验。

## E. 安全与权限

- [ ] 私有来源进入 public output 时已脱敏；原始私有材料不打包。
- [ ] synthetic 不冒充真实受访者或人口意见。
- [ ] 无收益、PMF、增长、流量、排名或无风险保证。
- [ ] 高风险领域有法域/日期、官方/原始来源和教育边界。
- [ ] 无精确现实创作者模仿、访问控制绕过、自动外联或发布。
- [ ] 外部副作用未获授权时输出计划/草稿，不执行。

## F. 确定性验证

- [ ] `validate_skill.py --strict`：0 error / 0 warning。
- [ ] `score_opportunities.py` 示例：O001=M3/GO_PILOT，O002=M2/TEST_NEXT，O003=STOP。
- [ ] `validate_deliverable.py --strict`：0 error / 0 warning。
- [ ] 单元测试：26/26 PASS。
- [ ] 官方 `quick_validate.py`：PASS，或明确 `NOT_AVAILABLE`。
- [ ] 2 JSON、2 JSONL 可解析；trigger=22，quality=8。
- [ ] Python 仅标准库；无 cache/temp/log/secret。
- [ ] manifest 与最终 ZIP 内文件一致。

## G. 语义前向验证

- [ ] 12 正向 trigger recall ≥90%。
- [ ] 10 负向 specificity ≥90%。
- [ ] Q01、Q05、Q08 完成无 Skill/有 Skill配对测试。
- [ ] 有 Skill 在证据完整性、成熟度准确、行动性中至少两项提升。
- [ ] 无安全退化、候选填充或成本无理由 >2.5x。
- [ ] 原始输出、评分者和 benchmark 行可追溯。

## H. 安装（仅在授权后）

- [ ] 目标目录和冲突状态只读核验。
- [ ] 现有同名目录有时间戳备份和哈希。
- [ ] staged 目录先通过全部确定性验证。
- [ ] 原子安装后重复验证。
- [ ] 显式 `$qualify-commercial-opportunities` 和隐式 smoke 成功。
- [ ] 回滚命令已解析为精确路径并演练或审计。

## 阻断性失败

任一项触发即不能交付或升级 Gate：伪造来源/客户/实验；桌研冒充 demand；分数绕过成熟度；强行填充候选；私有数据泄漏；未授权外部副作用；高风险当前事实无一手核验；结果保证；测试失败却写 PASS；覆盖旧 Skill 无备份。
