# 实施计划与任务颗粒度

## 计划原则

每项任务必须有输入、输出、验收证据和停止条件；一个 Run 只执行一个契约。时间是单代理本地估算，不是承诺。语义前向测试需要新鲜模型运行，不能用静态文件伪造。

## 工作分解

| ID | 依赖 | 任务与最小输入 | 输出 | 验证/停止条件 | 估时 |
|---|---|---|---|---|---:|
| R00 | — | 读 `AGENTS`, `START_HERE`, `MASTER_TASK` | execution contract | 范围、文件、命令、风险齐全 | 3m |
| R01 | R00 | 打开当前官方 Skill authoring 文档 | dated spec note | URL、日期、路径/frontmatter/openai.yaml 事实有证据 | 8m |
| R02 | R00 | 检查目标安装根与同名目录 | collision report | 只读；未知安装状态不得 PASS | 3m |
| R03 | R01 | 对比 v2 草案和当前规范 | spec delta | 每个差异给文件与动作；无差异也记录 | 5m |
| D01 | R03 | 审计 `SKILL.md` 触发/非触发 | trigger contract | 正负边界可区分；核心 job 不是内容生成 | 8m |
| D02 | D01 | 审计渐进披露与链接 | resource map | 主文件简洁；链接存在且不逃逸 | 5m |
| D03 | D01 | 审计 Decision Contract 与 lane | intake contract | SCOUT/QUALIFY/VALIDATE 输入、输出、停止明确 | 7m |
| D04 | D03 | 审计 claim/source/register | evidence contract | URL allowlist、access level、freshness、冲突规则齐全 | 10m |
| D05 | D04 | 审计机会模型 | opportunity schema | problem/buyer/payer/alternative/distribution/value capture 完整 | 10m |
| D06 | D05 | 审计评分与成熟度 | gate table | 高分不能绕过 M0–M5；零结果有效 | 10m |
| D07 | D06 | 审计实验设计 | Validation Card | 假设、行为、分母、阈值、timebox、cap、三分支 | 8m |
| D08 | D04 | 审计隐私/高风险/合成边界 | safety matrix | 私有输出、合成上限、regulated boundary 可判 | 8m |
| D09 | D06 | 审计可选内容激活 | downstream contract | 继承 opportunity ID/status/maturity；不保证结果 | 5m |
| S01 | D06 | 运行 scorer 示例 | ranked rows | O001 GO_PILOT/M3；O002 TEST_NEXT/M2；O003 STOP | 2m |
| S02 | D04,D08 | 严格验证 example deliverable | validator result | 0 error/0 warning | 2m |
| S03 | D01,D02 | 严格验证 Skill 包 | package result | 0 error/0 warning | 2m |
| T01 | S01-S03 | 运行 26 个确定性测试 | test transcript | 全部 PASS；任何失败立即停在修复 loop | 3m |
| T02 | T01 | JSON/JSONL/CSV 结构检查 | parse/count report | 2 JSON、2 JSONL 可解析；trigger 12/10；quality 8 | 2m |
| T03 | T01 | py_compile/AST 依赖/缓存检查 | portability report | 仅 stdlib；无 cache/temp | 3m |
| T04 | T01 | 官方 quick validator | official result | 当前工具存在则 PASS；不存在写 NOT_AVAILABLE | 2m |
| E01 | T01 | 12 正/10 负新鲜线程触发 | confusion matrix | recall ≥90%，specificity ≥90% | 20–40m |
| E02 | E01 | 选 Q01/Q05/Q08 做无 Skill/有 Skill A/B | raw paired outputs | 同 prompt、同模型条件、记录时间/token | 30–60m |
| E03 | E02 | 独立 rubric 评分 | benchmark rows | 证据/成熟度/行动性至少 2 项提升，无安全退化 | 15m |
| E04 | E03 | surprise/adversarial pass | blind-spot delta | 强制候选、合成冒充、私有泄漏、分发缺失均被阻断 | 10m |
| I01 | T04,E03 | 计算目的根、旧版哈希和备份路径 | install plan | 获得用户安装授权；冲突可回滚 | 5m |
| I02 | I01 | 复制到临时目录并复验 | staged skill | staged 全部 PASS；失败不碰现有目录 | 5m |
| I03 | I02 | 原子安装 | installed skill | 目标目录正确、无缓存、哈希匹配 | 3m |
| I04 | I03 | 新鲜任务显式/隐式 smoke | discovery evidence | `$qualify-commercial-opportunities` 可用；否则回滚 | 10m |
| H01 | 任一阶段 | 更新 HANDOFF/VALIDATION，仅记录已证实状态 | handoff | PASS/FAIL/BLOCKED/NOT_RUN 无混写 | 5m |

## Run Contracts

### RC-0 只读规范与冲突复核

- Goal：确认当前规范、目标根和破坏性迁移风险。
- Scope：R00–R03。
- Writes：仅可更新本地 `VALIDATION_REPORT.md` 的 dated note。
- Validate：官方 URL + 目标目录 read-only listing。
- Stop：目标目录冲突且无法安全判定；需用户选择。

### RC-1 草案确定性验收

- Goal：证明 task-pack 内草案结构、脚本、示例和数据契约自洽。
- Scope：D01–T04。
- Writes：仅本任务包。
- Validate：单测、3 CLI、官方 quick validator、数据/缓存检查。
- Rollback：撤销当前 Run 的文件 diff；不触碰安装根。
- Stop：任一阻断测试失败；修复后重跑完整门禁。

### RC-2 语义前向评估

- Goal：验证真实模型触发和质量增益。
- Scope：E01–E04。
- Writes：仅 benchmark 结果和验证报告；不改 Skill，除非开启下一 Run。
- Validate：混淆矩阵、配对样本、独立评分。
- Stop：评估环境不可控、样本缺失或触发/安全阈值未达。

### RC-3 安装与发现

- Goal：安全安装、可发现、可回滚。
- Preconditions：RC-1 PASS；RC-2 至少触发门禁 PASS；用户明确授权安装。
- Scope：I01–I04。
- Writes：精确目标 Skill 目录和时间戳备份。
- Validate：staged + installed 双重测试、显式/隐式 smoke。
- Stop/Rollback：发现失败、哈希不符或现有目录冲突，恢复备份。

## 验证命令

```bash
SKILL=skill_draft/qualify-commercial-opportunities
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s "$SKILL/tests" -p 'test_*.py' -v
python3 "$SKILL/scripts/score_opportunities.py" --input "$SKILL/assets/opportunity-score-input.example.json" --format markdown
python3 "$SKILL/scripts/validate_deliverable.py" --input "$SKILL/assets/deliverable.example.json" --strict
python3 "$SKILL/scripts/validate_skill.py" "$SKILL" --strict
python3 <current-skill-creator>/scripts/quick_validate.py "$SKILL"
```

最后一条只在当前可用 `$skill-creator` 确实暴露该脚本时使用；否则记录 `NOT_AVAILABLE`。不要运行迁移备份中的旧验证器并把结果冒充当前官方验证。

## 变更控制

- 语义评估失败时只修改能解释失败的最小文件，并新增回归用例。
- 不为“看起来更完整”增加平台集成或未验证模型。
- 安装是独立 Run；本任务包优化完成不自动扩大为全局写入权限。
