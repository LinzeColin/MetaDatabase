# v2 任务包验证报告

> 验证日期：2026-07-19  
> 环境：macOS 15.1；Python 3.9.6  
> 对象：`skill_draft/qualify-commercial-opportunities/`

## 结论

本地确定性 Gate **PASS**：草案结构、示例、三脚本、26 个回归测试、数据文件、YAML、局部链接、标准库依赖和包清洁均通过。当前官方 `quick_validate.py` 在活动 skill-creator 路径中不可用，状态为 **NOT_AVAILABLE**，不是 PASS。

隐式触发、模型质量 A/B、全局安装/发现和真实商业需求验证均为 **NOT_RUN**。因此可声称“v2 task pack 确定性验收通过”，不能声称“Skill 已安装上线”“语义效果已验证”或“商业机会已验证”。

## 状态矩阵

| 验证项 | 状态 | 同次证据 |
|---|---|---|
| 公开网络/GitHub 只读研究 | PASS | `RESEARCH_REPORT.md`, `REFERENCE_PROJECT_MATRIX.md` |
| Package validator strict | PASS | `PASS: 0 error(s), 0 warning(s)` |
| Deliverable validator strict | PASS | `PASS: 0 error(s), 0 warning(s)` |
| Opportunity scorer fixture | PASS | O001=M3/GO_PILOT；O002=M2/TEST_NEXT；O003=M1/STOP |
| 单元与 CLI 回归 | PASS | `Ran 26 tests ... OK` |
| Python compile | PASS | 4 个 Python 文件以 `py_compile` 编译到 `/tmp` cache prefix |
| JSON | PASS | 2/2 可解析 |
| JSONL | PASS | trigger=22（12 正/10 负）；quality=8 |
| CSV schema | PASS | benchmark header=36 columns |
| YAML | PASS | Ruby stdlib YAML 解析，interface/policy 为 mapping |
| Skill 本地 Markdown 链接 | PASS | 16 个相对链接存在且不逃逸 |
| 脚本运行依赖 | PASS | 3 个脚本静态导入均为 Python 标准库 |
| 缓存/临时产物 | PASS | task-pack 内无 `__pycache__`, pyc/pyo/log/tmp/DS_Store |
| 当前官方 quick validator | NOT_AVAILABLE | 活动路径无脚本；只发现旧迁移备份，未冒充当前验证 |
| 新鲜线程隐式触发 | NOT_RUN | 用例已备，不在本 Run 启动子代理/新任务 |
| 无 Skill / 有 Skill质量 A/B | NOT_RUN | rubric/benchmark 已备，无真实配对输出 |
| 用户级安装与 discovery smoke | NOT_RUN | 本请求没有全局安装授权 |
| 真实客户/需求/交易/交付验证 | NOT_RUN | 公开研究最高仅能支持 M1 |

## 实际命令与结果

### 单元测试

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover \
  -s skill_draft/qualify-commercial-opportunities/tests \
  -p 'test_*.py' -v
```

结果：26/26 PASS，覆盖机会排序、hard stop、合法零候选与零结果决策、缺失/越界输入、成熟度推导、GO 门禁、snippet/synthetic、URL allowlist、私有数据、未运行实验、保证性语言、高风险来源、frontmatter 与 3 个 CLI smoke。

### Scorer

```bash
python3 skill_draft/qualify-commercial-opportunities/scripts/score_opportunities.py \
  --input skill_draft/qualify-commercial-opportunities/assets/opportunity-score-input.example.json \
  --format markdown
```

| Rank | ID | Base | Risk | Confidence | Decision | Maturity | Status |
|---:|---|---:|---:|---:|---:|---|---|
| 1 | O001 | 86.20 | 7.00 | 80.00 | 76.20 | M3 | GO_PILOT |
| 2 | O002 | 83.60 | 7.20 | 78.25 | 73.14 | M2 | TEST_NEXT |
| 3 | O003 | 35.30 | 27.40 | 38.00 | 0.00 | M1 | STOP |

该 fixture 只验证算法门禁，不代表三个示例方向在真实市场中已拥有这些证据。

### Strict validators

```bash
python3 skill_draft/qualify-commercial-opportunities/scripts/validate_deliverable.py \
  --input skill_draft/qualify-commercial-opportunities/assets/deliverable.example.json --strict
python3 skill_draft/qualify-commercial-opportunities/scripts/validate_skill.py \
  skill_draft/qualify-commercial-opportunities --strict
```

两条均为：`PASS: 0 error(s), 0 warning(s)`。

### 数据、依赖与清洁度

- `opportunity-score-input.example.json`, `deliverable.example.json`：JSON PASS。
- `trigger_cases.jsonl`：22 行可解析，12 positive / 10 negative。
- `quality_cases.jsonl`：8 行可解析。
- `benchmark-template.csv`：36 列 header 可解析。
- `score_opportunities.py`, `validate_deliverable.py`, `validate_skill.py`：AST import allowlist PASS。
- `agents/openai.yaml`：YAML syntax + root/interface/policy shape PASS。
- task-pack 内缓存/临时文件检查：PASS。

## 未运行的验收和真实下一 Gate

1. 在新鲜 Codex 任务中执行 22 个 trigger cases，记录 confusion matrix。
2. 对 Q01、Q05、Q08 做相同模型条件下的无 Skill/有 Skill配对输出与独立评分。
3. 用户接受新调用 ID 并明确授权后，再 staging、备份、原子安装与 discovery smoke。
4. 对任何具体机会，只有获得真实访谈/行为/承诺/交易/交付证据后才升级 `M2+`。

## 剩余风险

- 当前官方 Skill 工具链没有暴露 quick validator；本地 package validator 不能替代未来官方兼容性验证。
- 隐式触发 precision/recall 会受模型版本与其他已安装 Skills 影响。
- 评分权重与 M2–M5 数量阈值是早期决策启发式，需要真实 outcome 校准。
- 仓库、产品、政策与许可状态会变化，实际运行要同次复核。
