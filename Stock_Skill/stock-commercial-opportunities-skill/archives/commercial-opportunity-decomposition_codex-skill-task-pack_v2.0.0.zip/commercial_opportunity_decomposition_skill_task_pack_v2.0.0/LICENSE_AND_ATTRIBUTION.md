# License 与归属说明

## 本任务包

本任务包中的 Skill 指令、模板、示例和 Python 脚本为本任务独立编写。未从参考仓库复制源代码、长段文本、品牌资产或私有数据。本文件不为用户的整体项目选择许可证，也不替代法律意见。

## 外部参考用途

`RESEARCH_REPORT.md` 与 `REFERENCE_PROJECT_MATRIX.md` 仅引用公开链接并抽象方法/架构模式。仓库许可证状态按 2026-07-19 快照记录，可能变化；任何未来代码复用都必须单独核验准确 commit、license、NOTICE、copyleft/attribution 义务。

特别边界：

- `unasserted` 或无明确许可证的仓库只可研究，不得推定可复制。
- GPL 项目（例如当日快照的 TrendRadar）只用于模式研究，本包不包含其代码。
- 商业产品页仅帮助理解产品形态，不代表获得其模板、内容、商标或实现权。
- Product Talk、Strategyzer、Strategyn 等方法以短述和链接引用，不复制其模板原文或受保护表达。
- 用户提供的私有证据归用户/相关权利人所有，不应进入公开任务包或示例。

## 依赖

三个运行脚本仅使用 Python 标准库。`agents/openai.yaml` 与 Markdown/JSON/JSONL/CSV 资产无运行时第三方包依赖。官方验证器是开发环境工具，不随本包再分发。

## 精确模仿与内容边界

可抽象高层结构、节奏和论证机制，但不得复刻现实创作者的签名措辞、独特表达或人格。可选 content activation 必须原创、保留 claim/source 关系并避免结果保证。
