# 输出合同

## 1. 所有模式共有

先输出：Decision Contract、Assumptions、as-of 日期、来源/访问限制、当前成熟度含义。结尾必须有：status、why not stronger、strongest countercase、evidence that changes the decision、owner/review date、single next test。

候选和来源使用范围上限，不使用固定配额。允许零机会。

## 2. Opportunity Radar

| ID | Actor/problem | Payer | Current alternative | Distribution | Base/risk/confidence | Maturity | Status | Fatal unknown | Next evidence |
|---|---|---|---|---|---|---|---|---|---|

另列：淘汰候选及原因、来源饱和说明、Top 1–3 的敏感性。

## 3. Opportunity Dossier

1. 决策结论与边界；
2. actor/job/struggling moment；
3. payer、budget owner、veto 和 procurement；
4. current alternatives、non-consumption 和 switching forces；
5. 问题经济、价值捕获和成本公式；
6. distribution/GTM 路径；
7. why now 与窗口衰减；
8. 竞争与差异化；
9. 五类假设图；
10. 主张—来源—访问状态—证据等级；
11. 评分、成熟度和敏感性；
12. 最强反例、失败/kill 条件；
13. 最小验证实验；
14. 决策与复核日期。

## 4. Validation Sprint

输出最多 3 张按 VOI 排序的 Test Card、事件记录表、证据升级条件、预算/时间上限、隐私/权限边界、日程、owner 和决策分支。没有真实运行证据时状态必须是 `planned`。

## 5. Go/No-Go Memo

```text
Decision: STOP | WATCH | TEST_NEXT | GO_PILOT | GO_SCALE | NO_QUALIFIED_OPPORTUNITY
Decision owner:
Opportunity and segment:
Evidence maturity:
Attractiveness / risk / confidence:
What is verified:
What is inferred:
What is still unknown:
Why this status is not stronger:
Commitment requested and cap:
Kill criteria:
Evidence that changes the decision:
Review date:
```

`GO_PILOT` 仅批准有限试点；`GO_SCALE` 需要 M5。没有 owner/预算/停止条件不得 Go。

## 6. Evidence Audit

| ID | Claim/decision | Type | Source IDs | Access/evidence class | Problem | Severity | Minimum repair |
|---|---|---|---|---|---|---|---|

检查：无来源、虚构/未登记 URL、snippet-only、合成证据冒充客户、重复来源、冲突未披露、时效、私密泄露、成熟度高估、score laundering、收益保证、无分发、无反例、无停止条件。

## 7. Content Activation（可选）

只在用户要求时追加。内容必须声明当前成熟度；不得把桌面资格审查写成“市场已验证”。完整结构见 `content-activation.md`。

## 8. 零结果合同

当没有候选通过：

- `Decision: NO_QUALIFIED_OPPORTUNITY`；
- 搜索/证据范围；
- 每个候选的淘汰原因；
- 最大未知；
- 什么信号或证据可重开；
- 默认停止，不强行生成 12 个题目或商业建议。

## 9. 结构化 JSON 顶层

```json
{
  "meta": {},
  "sources": [],
  "claims": [],
  "opportunities": [],
  "assumptions": [],
  "experiments": [],
  "decision": {},
  "content_activation": {"enabled": false}
}
```

ID 关系：claim.source_ids → sources；opportunity.claim_ids → claims；opportunity.assumption_ids → assumptions；experiment.assumption_id → assumptions；decision.selected_opportunity_id → opportunities。

完整示例见 `assets/deliverable.example.json`。验证：

```bash
python3 scripts/validate_deliverable.py \
  --input assets/deliverable.example.json --strict
```

## 10. Markdown 交付纪律

- 结论 > 状态/证据 > 机制 > 风险 > 下一测试；
- 文字状态不可只靠颜色；
- 每个任务含 owner、输入、输出、阈值、停止条件；
- 默认 Markdown/JSON；只有用户要求再生成 PDF、Word、PPT 或系统导入格式。
