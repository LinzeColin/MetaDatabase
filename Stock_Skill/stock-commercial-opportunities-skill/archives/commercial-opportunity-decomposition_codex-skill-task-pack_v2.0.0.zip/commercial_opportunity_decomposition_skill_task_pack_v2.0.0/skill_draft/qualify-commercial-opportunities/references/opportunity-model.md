# 商业机会对象模型

## 1. 机会不是信号、解决方案或市场规模

| 对象 | 定义 | 常见误判 |
|---|---|---|
| Signal | 变化或异常，如搜索增长、政策、招聘、投诉 | 把信号直接写成机会 |
| Problem | 某 actor 在具体情境中的昂贵/频繁/高风险阻力 | 只描述情绪，没有当前行为 |
| Opportunity | 可服务问题 + 可识别买方 + 不足替代 + 可达渠道 + 可验证价值 | 把大市场或技术能力当机会 |
| Solution | 解决机会的产品、服务、流程或合作方式 | 先爱上方案，再寻找问题 |
| Experiment | 以最低成本减少关键不确定性的行动 | 把“继续研究”当实验 |
| Business | 可重复触达、交付、收费并留住客户的系统 | 一次成交被当作规模成立 |

## 2. 决策对象

先选择一个主对象：

- `product`：软件、硬件或数字产品；
- `service`：咨询、审计、培训、实施、代运营；
- `market_entry`：进入地域、行业或客群；
- `partnership`：渠道、供应、授权或生态合作；
- `internal_capability`：组织内部流程/数据/工具改造；
- `content_activation`：用内容测试语言、受众和兴趣；不能替代商业验证。

不同对象使用不同经济和证据口径。不得用内容点击率证明企业会采购服务，也不得用访谈好评证明产品能交付价值。

## 3. Actor 与决策链

每个机会至少区分：

| 角色 | 要回答的问题 |
|---|---|
| User | 谁实际使用或承受流程变化？ |
| Problem owner | 谁承担当前问题的后果？ |
| Payer | 钱从谁的预算流出？ |
| Budget owner | 谁能批准预算或重新分配资源？ |
| Influencer | 谁定义标准、推荐或影响选择？ |
| Blocker/Veto | 法务、安全、采购、IT、工会或管理者谁能否决？ |
| Channel partner | 谁能低成本触达或交付？ |
| Cost bearer | 失败、迁移、责任和学习成本由谁承担？ |

“受众很多”不能替代 payer、budget owner 和 veto 路径。

## 4. Job、struggling moment 与切换力量

用以下结构描述问题：

```text
When [具体情境/触发事件],
[actor] wants to make progress from [当前状态] to [期望状态],
but [现有阻力/替代缺陷] causes [可观察后果].
```

同时检查四种力量：

- Push：现状为何痛到需要改变；
- Pull：新方案提供什么可测量进步；
- Anxiety：采用、责任、数据、安全、品牌或职业风险；
- Habit：流程、合同、集成、培训和“还能凑合”的惯性。

若 Push + Pull 不能明显超过 Anxiety + Habit，市场热度也不等于可采用机会。

## 5. 竞争与替代全集

至少检查：

1. 同类直接产品；
2. 相邻类别/服务商；
3. 内部团队自建；
4. 表格、邮件、人工、外包等 workaround；
5. 组合方案；
6. 延后、接受损失或什么都不做；
7. 预算竞争——买方把同一预算投向的其他结果。

“没有直接竞品”可能表示分类错误、需求太弱、买方用非消费解决，不能自动视为蓝海。

## 6. 商业机制

对每个候选填写：

```text
Problem frequency × consequence
→ current total cost / risk / lost value
→ budget and trigger
→ value delivered
→ price or exchange mechanism
→ cost to acquire + cost to deliver + support/liability
→ gross contribution and cash timing
→ retention/repeat mechanism
→ distribution bottleneck
```

无法获得真实数字时给范围、公式和待验证输入，不把估算写成事实。

## 7. Distribution 是一级对象

至少回答：

- ICP 在哪里聚集、如何被识别？
- 谁已有信任和触达权？
- 买方如何发现、评估、试用、采购和续约？
- 销售周期、采购门槛和证明材料是什么？
- 每个渠道的可控性、单位成本、反馈速度和依赖风险是什么？
- 若产品有效但没有分发，机会是否仍成立？

没有可测试的触达路径时，把 reachability 标为高影响未知，而不是假定“做好产品自然有人来”。

## 8. 五类假设

| 类别 | 关键问题 | 典型致命假设 |
|---|---|---|
| desirability | 问题是否真实、频繁、重要且替代不足？ | 用户只是口头抱怨但不会改变行为 |
| viability | payer、WTP、成本和价值捕获是否成立？ | 受益者无预算或交付成本吃掉收入 |
| feasibility | 能否合法、可靠、及时交付？ | 关键数据、集成、人才或质量不可得 |
| reachability | 能否持续触达、获得信任并完成采购？ | ICP 不可识别、渠道被平台/伙伴控制 |
| risk | 法规、责任、依赖、声誉、集中度是否可接受？ | 一次事故或政策变化可摧毁模式 |

## 9. 机会图最小关系

```text
Signal -> suggests -> Problem hypothesis
Actor -> experiences -> Problem
Actor -> hires/uses -> Alternative
Payer -> controls -> Budget
Opportunity -> depends_on -> Assumption
Claim -> supported_by/challenged_by -> Source
Experiment -> tests -> Assumption
Evidence -> changes -> Maturity
Decision -> selects/stops -> Opportunity
```

使用稳定 ID 保持可追溯；不得在成稿时丢掉主张、来源、假设和决定之间的关系。

## 10. Surprise 扫描

在终端产品之外检查“无聊但昂贵”的邻接层：合规/认证、质量/验收、采购、数据迁移、系统集成、维护/停机、责任/保险、培训/流程变更、渠道/售后、退役/回收、标准与互操作。

再做二阶反转：新技术/政策一旦普及，会新产生什么验收、治理、迁移、审计、保险、人才或基础设施问题？
