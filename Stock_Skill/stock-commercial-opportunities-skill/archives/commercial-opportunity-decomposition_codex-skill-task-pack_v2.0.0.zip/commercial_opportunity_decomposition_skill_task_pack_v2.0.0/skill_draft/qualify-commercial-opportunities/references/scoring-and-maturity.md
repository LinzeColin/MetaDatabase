# 评分、证据成熟度与决策门禁

## 1. 四个独立输出

评分只用于比较研究/测试预算，不预测收益。始终分别展示：

1. 吸引力基础分；
2. 风险扣分；
3. 证据置信度；
4. 证据成熟度；
5. 决策分与状态。

不得把成熟度折进单一总分后隐藏，也不得用高吸引力补偿低证据。

## 2. 四类 ROI（0–10）

| ROI | 含义 |
|---|---|
| R1 Learning | 下一测试能否以低成本显著减少关键不确定性 |
| R2 Customer | 若成立，对目标 actor 的结果改善是否重要且可测 |
| R3 Commercial | payer、WTP、价值捕获、毛利/现金与复购潜力 |
| R4 Execution | 当前 operator 能否合法、快速、可逆地触达并交付 |

内容注意力只在 `content_activation` 模式单独评估，不能替代商业 ROI。

## 3. 吸引力基础分（0–100）

| 字段 | 权重 | 10 分锚点 |
|---|---:|---|
| problem_severity_frequency | 16 | 问题高频/昂贵/高风险且有实例 |
| buyer_budget_wtp | 14 | payer、预算、触发和 WTP 证据清楚 |
| reachability_distribution | 14 | ICP 可识别，渠道可测试，信任/采购路径清楚 |
| alternative_inadequacy | 10 | 直接/替代/自建/非消费均有明确不足 |
| value_capture_margin | 10 | 价值、价格、交付成本和现金逻辑可解释 |
| structural_timing | 8 | 多个已验证时点驱动，非短期噪声 |
| operator_advantage | 8 | 资历、资产、数据、渠道或速度形成真实优势 |
| speed_to_evidence | 8 | 7–30 天内能得到决定性新证据 |
| delivery_feasibility | 7 | 技术、数据、流程、质量和合规可控 |
| strategic_optionality | 5 | 即使主假设失败也能沉淀可复用资产/相邻选项 |

```text
base_score = Σ(dimension / 10 × weight)
```

## 4. 风险扣分（0–40）

| 字段 | 最大扣分 | 高风险示例 |
|---|---:|---|
| evidence_gap | 8 | 核心链只靠假设、snippet 或单一利益方 |
| adoption_switching_friction | 6 | 迁移、习惯、责任、集成和组织阻力大 |
| regulatory_liability | 6 | 强监管、责任、隐私、安全或专业建议风险 |
| capital_access | 5 | 重资产、牌照、专有数据、长账期或高前置成本 |
| competitive_response | 4 | 巨头易复制、渠道封锁、价格战或标准控制 |
| concentration_dependency | 4 | 单一平台、客户、供应商、人物或政策依赖 |
| delivery_complexity | 4 | 定制/支持/质量成本难规模化 |
| freshness_decay | 3 | 机会窗口、平台规则或信息快速衰减 |

```text
risk_deduction = Σ(risk / 10 × maximum)
```

## 5. 证据置信度（0–100）

| 字段 | 权重 |
|---|---:|
| claim_coverage | 25 |
| source_quality | 20 |
| source_diversity | 15 |
| evidence_directness | 20 |
| recency | 10 |
| contradiction_resolution | 10 |

```text
confidence = Σ(part / 10 × weight)
uncertainty_penalty = (100 - confidence) × 0.15
decision_score = clamp(base_score - risk_deduction - uncertainty_penalty, 0, 100)
```

置信度描述当前证据对当前主张的支持程度，不是未来成功概率。

## 6. 成熟度

| 代码 | 状态 | 最低保守证据 |
|---|---|---|
| M0 | Hypothesis | 少量信号或纯假设 |
| M1 | Desk-qualified | ≥3 个合适公开来源家族，核心事实初步成立 |
| M2 | Problem-evidenced | ≥3 次目标 segment 真实访谈 + ≥2 个过去/当前问题实例 |
| M3 | Demand-evidenced | M2 + ≥2 个资源承诺，或 ≥1 个真实付款/等价强承诺 |
| M4 | Delivery-evidenced | ≥1 真实付款 + ≥1 成功交付并测得价值 |
| M5 | Scale-evidenced | ≥3 付款、≥3 成功交付、≥1 复购/重复客户，并有单位经济/渠道证据 |

脚本根据 `evidence_signals` 计算保守成熟度。阈值只是一致性门禁，不代表统计显著；例外必须人工说明，默认不在脚本中晋级。

## 7. 决策状态

| 状态 | 默认条件 | 含义 |
|---|---|---|
| STOP | score <45 或 hard stop | 停止当前假设/重构范围 |
| WATCH | score 45–59 | 保留触发条件，不投入主动验证 |
| TEST_NEXT | score ≥60 但成熟度/置信度未达 Go | 只批准下一低风险证据实验 |
| GO_PILOT | score ≥75、confidence ≥65、M3+ | 可投入有上限的试点；不是规模成立 |
| GO_SCALE | score ≥80、confidence ≥70、M5 | 可提交规模化决策，仍需 owner 审批 |
| NO_QUALIFIED_OPPORTUNITY | 无候选通过剪枝 | 有效结果，不生成 filler |

额外硬门禁：

- Core 主张 Missing/Conflicting 时不得 Go；
- 只有 desk/synthetic/community 信号时成熟度上限 M1；
- 未知分发路径时不得 GO_SCALE；
- 受监管领域缺当前官方来源时不得 Go；
- 收益保证、非法访问、精确人物模仿或未授权外部动作直接阻断。

## 8. Value of Information（VOI）

下一实验优先级：

```text
voi_priority = decision_impact × uncertainty × decision_reversibility
               ÷ (cash_cost + time_cost + coordination_cost + risk_cost)
```

使用 1–5 粗粒度评分即可。若无法说明测试结果如何改变 STOP/WATCH/TEST/GO，实验的 VOI 视为低。

## 9. 敏感性与防伪精确

- 呈现分数最多一位小数；强调分档而非 0.1 差距。
- Top 候选差距 <5 分时，改变 reachability、WTP、delivery 三项各 ±2 分，检查排名是否翻转。
- 给出最可能改变排名的 1–3 条证据。
- 不从网页、模型或主观印象直接生成“87% 成功率”。

## 10. 脚本输入

`scripts/score_opportunities.py` 要求每个 opportunity 包含：`dimensions`、`risks`、`confidence`、`roi`、`evidence_signals` 和可选 `hard_stops`。脚本输出排名、分离分数、成熟度、状态和下一成熟度门禁。
