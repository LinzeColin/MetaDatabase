# 证据协议：来源、主张、成熟度与可追溯性

## 1. 证据目的

研究的目标不是收集链接，而是回答“哪个关键不确定性已经被什么直接证据改变”。保持来源、主张、证据等级和机会成熟度分离。

## 2. 来源登记表

每个来源使用稳定 `source_id`，至少记录：

| 字段 | 说明 |
|---|---|
| title | 人可识别标题；内部来源使用脱敏名称 |
| url / locator | 公开 URL 或私有材料定位，二者至少一个 |
| source_type | official、primary_research、company_first_party、customer_interview、behavioral_analytics、community、media、user_material、internal_system、synthetic_simulation |
| origin | public、private、synthetic |
| access_level | opened_fulltext、opened_partial、snippet_only、user_provided、internal_private、synthetic |
| evidence_class | desk、customer_statement、behavior、commitment、transaction、delivery |
| published_at | 发布/发生/生效时间（可得时） |
| retrieved_at | 本次检索或接收日期 |
| jurisdiction/segment | 适用法域或客群 |
| method_note | 样本、口径、利益关系和主要限制 |
| content_digest | 可得时记录内容哈希或版本；不能替代人工检查 |
| redacted | 公开输出中的私有来源是否已脱敏 |

## 3. 访问状态门禁

- 搜索结果页和 snippet 只用于找线索，不是完整证据。
- 核心主张不能只由 `snippet_only` 支持。
- 页面打不开、仅登录/付费可见或只看到营销摘要时，记录限制并找替代源；不得假装已阅读全文。
- 生成输出中的所有 URL 必须来自来源登记表。验证器会阻断未登记 URL，以降低“看似真实的虚构链接”。
- 引用必须说明来源如何支持或挑战主张；只列“参考资料”不构成可追溯性。

## 4. 证据强度阶梯

| 等级 | 例子 | 能证明什么 | 不能证明什么 |
|---|---|---|---|
| Desk signal | 官方文件、论文、产品页、招聘、采购、趋势、社区 | 定义、市场结构、候选问题、时点、假设 | 某目标客群一定会购买 |
| Customer statement | 真实访谈、支持工单、流失原因、销售记录 | 问题语言、过去行为、约束和购买过程 | 未来承诺或规模 |
| Behavior | 使用日志、任务观察、落地页行动、真实切换 | 实际行为和摩擦 | 价格/长期留存一定成立 |
| Commitment | 试点协议、LOI、排期、数据接入、押金、预付 | 对问题/方案投入资源的意愿 | 可持续交付和经济性 |
| Transaction | 真实付款、续费、扩容 | WTP 与部分需求 | 毛利、可复制获客或长期价值 |
| Delivery | 已交付并测得结果、复购、推荐、稳定 SLA | 可交付价值与重复性 | 在更大规模仍成立 |

弱证据可以决定“下一步测什么”，不能被措辞升级为强证据。

## 5. 证据成熟度上限

- 只有公开桌面证据：最多 `M1 Desk-qualified`。
- 至少 3 次相关真实访谈并有过去行为/实例：可达 `M2 Problem-evidenced`。
- 有实际行为测试或资源承诺，且对象匹配：可达 `M3 Demand-evidenced`。
- 有付费和成功交付：可达 `M4 Delivery-evidenced`。
- 有重复客户/复购、可解释单位经济和可重复渠道：可达 `M5 Scale-evidenced`。

这些是保守默认门禁，不是统计显著性声明。高客单/长周期场景若需例外，必须记录理由、替代证据和风险，不能静默提升。

## 6. 合成证据边界

LLM personas、synthetic surveys、模拟焦点组和生成式访谈可用于：

- 生成假设、反例和访谈题；
- 预演问卷歧义；
- 压力测试定位和信息表达；
- 选择优先接触的真实细分。

它们不能作为真实人口意见、问题频率、WTP、采用意愿或需求验证；其存在不能把成熟度提升到 M2。标记 `origin=synthetic`、`evidence_class=desk`。

## 7. 主张原子化

每条 `claim` 至少包含：ID、statement、Fact/Inference/Estimate/Opinion/Unverified、Core/Supporting/Context、freshness、confidence、source_ids、supports/challenges 关系。

把复合句拆开，例如：

1. 某 actor 存在可观察流程损失（Fact/Estimate）；
2. 当前替代在某条件下不足（Fact/Inference）；
3. 某 budget owner 能批准支出（Fact/Inference）；
4. 某渠道可触达该 buyer（Fact/Inference）；
5. 候选方案可能降低该损失（Inference）；
6. 价格和毛利可能成立（Estimate）。

宏观增长数据不能一次支撑完整商业链。

## 8. 来源优先级与用途

1. 法规、监管、政府数据、标准、法定披露、官方文档、原始论文/数据；
2. 方法透明的行业/机构研究；
3. 客户访谈、行为、交易、交付和内部系统；
4. 公司产品页、案例、采购/招聘信号；
5. 专业媒体和分析师；
6. 社区、论坛、评论和趋势。

优先级不是机械真值：检查方法、样本、时点、法域和利益关系。社区可证明“有人在说”，不能单独证明事实或因果。

## 9. 两轮检索与反证

### Round 1：地图

查 actor、术语、问题、替代、决策链、公开市场结构、分发和原始来源。输出候选与缺口，不写最终推荐。

### Round 2：主张驱动

只补入围候选的 Core 主张：问题频率/后果、预算与采购、替代不足、触达、交付、单位经济和时点。

### Contradiction pass

主动查：失败案例、无 PMF、低采用、渠道受阻、切换失败、方法争议、监管变化、单位经济反例、客户选择非消费的原因。

## 10. 冲突与新鲜度

冲突时检查定义、样本、时间、地区、单位和利益关系；记录双方，不静默选更好听的值。无法化解则 `Conflicting`，降低置信度和决策级别。

| 事实类型 | 默认复核窗口 |
|---|---|
| 价格、产品功能、软件版本、职位、平台政策 | 同次官方核验 |
| 法律、监管、税务、政策 | 同次核验法域、生效日、修订状态 |
| 市场份额、采用率、宏观数据 | 优先 12–18 个月且方法透明 |
| 客户/交易/交付证据 | 记录事件时间、segment 和样本边界 |
| 稳定理论 | 可用经典来源，但检查是否已被修订/反驳 |

## 11. 私密数据与公开输出

- 默认私密处理客户访谈、合同、财务、CRM、支持工单、使用日志和内部材料。
- 公开网络研究不得上传私有原文、客户名单、金额、凭据或可识别个人信息。
- `output_visibility=public` 时，所有私有来源必须 `redacted=true`，只保留聚合、结构或经授权摘要。
- 内部证据和公开证据分别标记，避免把不可复核内部材料包装为公开事实。

## 12. 完成定义

QUALIFY 至少满足：Core 主张覆盖 ≥85%；至少 3 个独立来源家族；已打开关键页面；有一轮反证；买方、替代、分发和致命假设明确；成熟度不高估；新增来源接近饱和；未覆盖证据不会被写成已验证结论。
