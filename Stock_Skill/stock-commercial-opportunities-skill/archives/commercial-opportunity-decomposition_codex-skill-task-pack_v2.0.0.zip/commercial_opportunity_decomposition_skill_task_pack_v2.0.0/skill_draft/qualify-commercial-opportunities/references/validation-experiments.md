# 最小验证实验与学习门禁

## 1. 实验目标

实验不是证明想法正确，而是用最低总成本让高影响未知更快变成支持、挑战或失效。公开研究结束后，优先验证最可能杀死机会的假设。

## 2. 风险优先级

对每条假设评分 1–5：

- decision impact：若为假，是否杀死/大幅改变机会；
- uncertainty：当前证据有多弱；
- cost/time：获得更强证据的成本与时间；
- reversibility：错误行动是否容易回滚。

先测高影响、高不确定、低成本、可逆项。不得因技术 demo 最容易做，就跳过 problem、payer 或 distribution。

## 3. Test Card

每个实验必须写：

```text
Assumption ID:
We believe:
Target segment and actor:
Current evidence:
Method:
Observed behavior / event:
Primary metric and denominator:
Pass threshold:
Fail / stop threshold:
Timebox:
Cash and coordination cap:
Data/privacy boundary:
Owner:
If pass -> decision change:
If fail -> decision change:
If inconclusive -> next action:
```

阈值必须在运行前定义；运行后改变阈值应被标记为新实验。

## 4. 按假设类型选实验

### Desirability

从弱到强：公开问题扫描 → 真实过去行为访谈 → 任务观察/日志 → concierge/manual workaround → 真实行动测试。

不要问“你会不会买”；重建最近一次问题发生、替代、成本、触发、决策和未改变原因。

### Viability

从弱到强：价格/预算流程访谈 → 带明确范围的报价反馈 → LOI/资源承诺 → 押金/预售/付款 → 续费/扩容。

“喜欢”“有兴趣”“以后可以”不是 WTP。

### Feasibility

技术 spike、数据可得性检查、服务蓝图、质量/验收测试、合规评审、受控小样本交付。验证最难依赖，不先美化界面。

### Reachability

名单可得性检查、目标渠道小批触达、合作伙伴访谈、落地页真实转化、预约/回复率、销售周期与采购关卡记录。未经授权不自动外联。

### Risk

pre-mortem、red-team、法务/安全/隐私评审、依赖故障演练、集中度和政策情景、失败成本上限。

## 5. 证据强度原则

行为通常强于意见；资源承诺强于口头兴趣；真实付款强于价格问卷；成功交付和复购强于首单。选择与待验证主张直接匹配的证据，不机械追求“最强”但无关的实验。

合成访谈只用于题目预演和假设生成，不是客户实验。

## 6. 样本与口径

- 预先写清 segment、招募方式、纳入/排除标准和分母。
- 少样本定性实验用于发现机制，不声称总体比例。
- 定量阈值必须说明基线、窗口和可用样本；数据不足时采用阶段门禁，不伪造显著性。
- 记录失败、拒绝、无回复和流失，不只保留正面案例。
- 区分同一组织内多位受访者与独立买方数量。

## 7. 决策分支

| 结果 | 处理 |
|---|---|
| Pass | 只提升被测试假设；检查是否满足下一成熟度完整门禁 |
| Fail | STOP、缩小 segment、改变问题/模式，或测试替代解释 |
| Inconclusive | 说明数据为何不足；只有高 VOI 时再试一次 |
| Harm/safety trigger | 立即停止，保存证据并升级人工审查 |

单个实验不得自动把整个机会从 M1 跳到 M4。

## 8. 7–14 天默认验证冲刺

1. Day 0：冻结机会、假设、阈值、owner 和权限；
2. Day 1–3：招募/准备最小资产；
3. Day 3–10：运行并逐事件记录；
4. Day 10–12：对照阈值，分析反例和偏差；
5. Day 12–14：更新证据台账、成熟度、分数和决定。

若受众招募、采购周期或法域不支持 14 天，输出真实时间表；不要假装完成。

## 9. 完成定义

实验完成必须有真实发生记录、预设阈值、结果、偏差、对假设和决策的影响、数据/隐私说明以及下一状态。只有计划、脚本、模拟或预期结果均为 `planned`，不是 PASS。
