# 机会到内容/资产的可选激活层

## 1. 使用条件

只有用户明确要求内容、系列、解说、咨询入口或研究资产时加载。内容是传播/学习/触达实验，不是商业验证本身。

每份内容先声明：机会成熟度、哪些是 Fact/Inference/Estimate、哪些仍待真实客户/行为/交易验证。

## 2. 价值链

```text
Opportunity evidence
→ audience-specific question
→ falsifiable thesis
→ original explanation
→ useful decision asset
→ ethical CTA / validation event
→ measured learning
```

不要从播放量直接跳到收入结论。内容 CTA 可以测试语言和兴趣，但除非有更强行为/承诺，不能提升到 Demand-evidenced。

## 3. 九段原创机制结构

1. Falsifiable hook；
2. Concrete phenomenon；
3. Common wrong model；
4. Incentive/economic/constraint mechanism；
5. Payer/user/value capture/cost bearer；
6. Why now；
7. Role-specific reversible action；
8. Strongest countercase and maturity limit；
9. Original compressed conclusion。

叙事强度不得超过证据强度。不得用虚构客户、数字、内幕或“反常识”包装弱证据。

## 4. 可复用资产优先级

优先把研究转为：诊断问卷、证据台账、选型矩阵、成本/风险模型、采购/评估模板、验证卡、实施路线、更新雷达。它们同时支持内容、访谈、咨询和内部决策。

## 5. 商业承接桥

| 层级 | 可验收交付 | 证据用途 |
|---|---|---|
| 免费资产 | 清单、矩阵、备忘录、计算器 | 测试语言/问题识别 |
| 入口测试 | 诊断、工作坊、审计 | 获得真实问题/承诺证据 |
| 有限试点 | 研究包、实施冲刺、小型交付 | 验证付款与交付价值 |
| 重复服务 | 更新、维护、监控 | 验证复购、渠道和规模性 |

只承诺输入、输出、时间和质量门禁，不承诺客户结果。

## 6. 发布前检查

- 每个核心句能回溯到 claim/source 或明确标为推断；
- 当前事实同次核验；
- 未把 M0–M2 写成“市场已验证”；
- 无现实创作者精确模仿；
- 无私密数据和未授权案例；
- CTA 是可逆验证，不是夸大承诺；
- 给出最强反例和更新日期。
