#!/usr/bin/env python3
"""Validate a structured commercial-opportunity deliverable.

The standard-library-only validator checks source registration, source access,
claim relationships, evidence maturity, decision gates, experiment evidence,
privacy, guarantees, and optional content activation.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple
from urllib.parse import urlparse

CLAIM_TYPES = {"fact", "inference", "estimate", "opinion", "unverified"}
IMPORTANCE = {"core", "supporting", "context"}
FRESHNESS = {"Fresh", "Delayed", "Stale", "Missing", "Conflicting"}
SOURCE_TYPES = {
    "official",
    "primary_research",
    "company_first_party",
    "customer_interview",
    "behavioral_analytics",
    "community",
    "media",
    "user_material",
    "internal_system",
    "synthetic_simulation",
}
ORIGINS = {"public", "private", "synthetic"}
ACCESS_LEVELS = {
    "opened_fulltext",
    "opened_partial",
    "snippet_only",
    "user_provided",
    "internal_private",
    "synthetic",
}
EVIDENCE_CLASSES = {
    "desk",
    "customer_statement",
    "behavior",
    "commitment",
    "transaction",
    "delivery",
}
DECISION_OBJECTS = {
    "product",
    "service",
    "market_entry",
    "partnership",
    "internal_capability",
    "content_activation",
}
OPPORTUNITY_STATUSES = {"STOP", "WATCH", "TEST_NEXT", "GO_PILOT", "GO_SCALE"}
DECISION_OUTCOMES = OPPORTUNITY_STATUSES | {"NO_QUALIFIED_OPPORTUNITY"}
MATURITY_CODES = {"M0", "M1", "M2", "M3", "M4", "M5"}
MATURITY_RANK = {code: rank for rank, code in enumerate(sorted(MATURITY_CODES))}
ASSUMPTION_CATEGORIES = {"desirability", "viability", "feasibility", "reachability", "risk"}
ASSUMPTION_STATUSES = {"unknown", "supported", "challenged", "invalidated"}
EXPERIMENT_STATUSES = {"planned", "running", "passed", "failed", "inconclusive", "stopped"}
EVIDENCE_SIGNAL_FIELDS = (
    "desk_source_families",
    "customer_interviews",
    "observed_problem_instances",
    "commitments",
    "paid_transactions",
    "successful_deliveries",
    "repeat_customers",
)

URL_RE = re.compile(r"https?://[^\s<>\]\[\)\(\"']+")
GUARANTEE_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"稳赚",
        r"保本",
        r"无风险",
        r"必爆",
        r"保证(?:收益|收入|回报|转化|排名|播放|市场份额)",
        r"已验证(?:产品市场匹配|PMF)(?!\s*假设)",
        r"guaranteed?\s+(?:return|revenue|conversion|ranking|market share)",
        r"risk[- ]?free",
        r"cannot\s+lose",
    )
]


@dataclass
class Finding:
    severity: str
    code: str
    path: str
    message: str

    def as_dict(self) -> Dict[str, str]:
        return {
            "severity": self.severity,
            "code": self.code,
            "path": self.path,
            "message": self.message,
        }


class ContractError(ValueError):
    pass


def is_mapping(value: Any) -> bool:
    return isinstance(value, Mapping)


def nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def valid_url(value: Any) -> bool:
    if not nonempty_string(value):
        return False
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def valid_iso_date(value: Any) -> bool:
    if not nonempty_string(value):
        return False
    try:
        date.fromisoformat(value)
    except ValueError:
        return False
    return True


def number_in_range(value: Any, minimum: float, maximum: float) -> bool:
    return (
        not isinstance(value, bool)
        and isinstance(value, (int, float))
        and minimum <= float(value) <= maximum
    )


def nonnegative_int(value: Any) -> bool:
    return not isinstance(value, bool) and isinstance(value, int) and value >= 0


def add(
    findings: List[Finding], severity: str, code: str, path: str, message: str
) -> None:
    findings.append(Finding(severity, code, path, message))


def walk_strings(value: Any) -> Iterable[Tuple[str, str]]:
    stack: List[Tuple[str, Any]] = [("$", value)]
    while stack:
        path, item = stack.pop()
        if isinstance(item, str):
            yield path, item
        elif isinstance(item, Mapping):
            for key, child in item.items():
                stack.append((f"{path}.{key}", child))
        elif isinstance(item, list):
            for index, child in enumerate(item):
                stack.append((f"{path}[{index}]", child))


def conservative_maturity(signals: Mapping[str, Any]) -> str:
    if (
        signals.get("paid_transactions", 0) >= 3
        and signals.get("successful_deliveries", 0) >= 3
        and signals.get("repeat_customers", 0) >= 1
    ):
        return "M5"
    if (
        signals.get("paid_transactions", 0) >= 1
        and signals.get("successful_deliveries", 0) >= 1
    ):
        return "M4"
    problem_evidenced = (
        signals.get("customer_interviews", 0) >= 3
        and signals.get("observed_problem_instances", 0) >= 2
    )
    if problem_evidenced and (
        signals.get("commitments", 0) >= 2
        or signals.get("paid_transactions", 0) >= 1
    ):
        return "M3"
    if problem_evidenced:
        return "M2"
    if signals.get("desk_source_families", 0) >= 3:
        return "M1"
    return "M0"


def _required_fields(
    findings: List[Finding], item: Mapping[str, Any], fields: Sequence[str], path: str
) -> None:
    for field in fields:
        if field not in item:
            add(findings, "error", "MISSING_FIELD", f"{path}.{field}", "Required field is missing")


def validate(payload: Any) -> List[Finding]:
    findings: List[Finding] = []
    if not is_mapping(payload):
        return [Finding("error", "ROOT_TYPE", "$", "Root must be an object")]

    top_fields = (
        "meta",
        "sources",
        "claims",
        "opportunities",
        "assumptions",
        "experiments",
        "decision",
        "content_activation",
    )
    _required_fields(findings, payload, top_fields, "$")

    meta = payload.get("meta") if is_mapping(payload.get("meta")) else {}
    if not is_mapping(payload.get("meta")):
        add(findings, "error", "META_TYPE", "$.meta", "meta must be an object")
    meta_fields = (
        "domain",
        "audience",
        "decision_object",
        "geography",
        "horizon",
        "lane",
        "as_of",
        "high_stakes",
        "assumptions",
        "output_visibility",
        "private_data_used",
    )
    _required_fields(findings, meta, meta_fields, "$.meta")
    for field in ("domain", "audience", "geography", "horizon"):
        if field in meta and not nonempty_string(meta[field]):
            add(findings, "error", "META_STRING", f"$.meta.{field}", "Must be a non-empty string")
    if meta.get("decision_object") not in DECISION_OBJECTS:
        add(findings, "error", "DECISION_OBJECT", "$.meta.decision_object", f"Must be one of {sorted(DECISION_OBJECTS)}")
    if meta.get("lane") not in {"SCOUT", "QUALIFY", "VALIDATE"}:
        add(findings, "error", "LANE", "$.meta.lane", "Must be SCOUT, QUALIFY, or VALIDATE")
    if not valid_iso_date(meta.get("as_of")):
        add(findings, "error", "AS_OF", "$.meta.as_of", "Must be an ISO date YYYY-MM-DD")
    if not isinstance(meta.get("high_stakes"), bool):
        add(findings, "error", "HIGH_STAKES_TYPE", "$.meta.high_stakes", "Must be boolean")
    if not isinstance(meta.get("private_data_used"), bool):
        add(findings, "error", "PRIVATE_DATA_TYPE", "$.meta.private_data_used", "Must be boolean")
    if not isinstance(meta.get("assumptions"), list):
        add(findings, "error", "META_ASSUMPTIONS", "$.meta.assumptions", "Must be an array")
    if meta.get("output_visibility") not in {"private", "public"}:
        add(findings, "error", "OUTPUT_VISIBILITY", "$.meta.output_visibility", "Must be private or public")
    if meta.get("high_stakes") is True and not nonempty_string(meta.get("educational_boundary")):
        add(findings, "error", "HIGH_STAKES_BOUNDARY", "$.meta.educational_boundary", "High-stakes output requires an educational boundary")
    style = meta.get("style_reference")
    if style is not None:
        if not is_mapping(style):
            add(findings, "error", "STYLE_TYPE", "$.meta.style_reference", "Must be an object")
        elif style.get("exact_creator_imitation") is True:
            add(findings, "error", "EXACT_IMITATION", "$.meta.style_reference.exact_creator_imitation", "Exact creator imitation is prohibited")

    # Source register.
    raw_sources = payload.get("sources")
    if not isinstance(raw_sources, list):
        add(findings, "error", "SOURCES_TYPE", "$.sources", "sources must be an array")
        raw_sources = []
    source_by_id: Dict[str, Mapping[str, Any]] = {}
    allowed_urls = set()
    for index, raw_source in enumerate(raw_sources):
        path = f"$.sources[{index}]"
        if not is_mapping(raw_source):
            add(findings, "error", "SOURCE_TYPE", path, "source must be an object")
            continue
        source = raw_source
        _required_fields(
            findings,
            source,
            ("id", "title", "source_type", "origin", "access_level", "evidence_class", "retrieved_at", "redacted"),
            path,
        )
        source_id = source.get("id")
        if not nonempty_string(source_id):
            add(findings, "error", "SOURCE_ID", f"{path}.id", "Must be non-empty")
            continue
        if source_id in source_by_id:
            add(findings, "error", "DUPLICATE_SOURCE", f"{path}.id", f"Duplicate source id: {source_id}")
        source_by_id[source_id] = source
        if not nonempty_string(source.get("title")):
            add(findings, "error", "SOURCE_TITLE", f"{path}.title", "Must be non-empty")
        if source.get("source_type") not in SOURCE_TYPES:
            add(findings, "error", "SOURCE_KIND", f"{path}.source_type", f"Must be one of {sorted(SOURCE_TYPES)}")
        if source.get("origin") not in ORIGINS:
            add(findings, "error", "SOURCE_ORIGIN", f"{path}.origin", f"Must be one of {sorted(ORIGINS)}")
        if source.get("access_level") not in ACCESS_LEVELS:
            add(findings, "error", "SOURCE_ACCESS", f"{path}.access_level", f"Must be one of {sorted(ACCESS_LEVELS)}")
        if source.get("evidence_class") not in EVIDENCE_CLASSES:
            add(findings, "error", "EVIDENCE_CLASS", f"{path}.evidence_class", f"Must be one of {sorted(EVIDENCE_CLASSES)}")
        if not valid_iso_date(source.get("retrieved_at")):
            add(findings, "error", "RETRIEVED_AT", f"{path}.retrieved_at", "Must be an ISO date")
        if not isinstance(source.get("redacted"), bool):
            add(findings, "error", "REDACTED_TYPE", f"{path}.redacted", "Must be boolean")
        url = source.get("url")
        locator = source.get("locator")
        if source.get("origin") == "public":
            if not valid_url(url):
                add(findings, "error", "PUBLIC_SOURCE_URL", f"{path}.url", "Public source requires a valid http(s) URL")
        elif not valid_url(url) and not nonempty_string(locator):
            add(findings, "error", "SOURCE_LOCATOR", path, "Private/synthetic source requires a URL or non-empty locator")
        if valid_url(url):
            allowed_urls.add(url)
        if source.get("origin") == "synthetic":
            if source.get("access_level") != "synthetic" or source.get("evidence_class") != "desk":
                add(findings, "error", "SYNTHETIC_CLASS", path, "Synthetic sources must use access_level=synthetic and evidence_class=desk")
        if source.get("source_type") == "synthetic_simulation" and source.get("origin") != "synthetic":
            add(findings, "error", "SYNTHETIC_ORIGIN", path, "synthetic_simulation requires origin=synthetic")
        if meta.get("output_visibility") == "public" and source.get("origin") == "private" and source.get("redacted") is not True:
            add(findings, "error", "PRIVATE_NOT_REDACTED", path, "Private source in public output must be redacted")

    # Claims and source relationships.
    raw_claims = payload.get("claims")
    if not isinstance(raw_claims, list):
        add(findings, "error", "CLAIMS_TYPE", "$.claims", "claims must be an array")
        raw_claims = []
    claim_by_id: Dict[str, Mapping[str, Any]] = {}
    for index, raw_claim in enumerate(raw_claims):
        path = f"$.claims[{index}]"
        if not is_mapping(raw_claim):
            add(findings, "error", "CLAIM_TYPE", path, "claim must be an object")
            continue
        claim = raw_claim
        _required_fields(findings, claim, ("id", "statement", "type", "importance", "freshness_status", "confidence", "source_ids"), path)
        claim_id = claim.get("id")
        if not nonempty_string(claim_id):
            add(findings, "error", "CLAIM_ID", f"{path}.id", "Must be non-empty")
            continue
        if claim_id in claim_by_id:
            add(findings, "error", "DUPLICATE_CLAIM", f"{path}.id", f"Duplicate claim id: {claim_id}")
        claim_by_id[claim_id] = claim
        if not nonempty_string(claim.get("statement")):
            add(findings, "error", "CLAIM_STATEMENT", f"{path}.statement", "Must be non-empty")
        if claim.get("type") not in CLAIM_TYPES:
            add(findings, "error", "CLAIM_LABEL", f"{path}.type", f"Must be one of {sorted(CLAIM_TYPES)}")
        if claim.get("importance") not in IMPORTANCE:
            add(findings, "error", "IMPORTANCE", f"{path}.importance", f"Must be one of {sorted(IMPORTANCE)}")
        if claim.get("freshness_status") not in FRESHNESS:
            add(findings, "error", "FRESHNESS", f"{path}.freshness_status", f"Must be one of {sorted(FRESHNESS)}")
        if not number_in_range(claim.get("confidence"), 0, 100):
            add(findings, "error", "CLAIM_CONFIDENCE", f"{path}.confidence", "Must be 0-100")
        source_ids = claim.get("source_ids")
        if not isinstance(source_ids, list):
            add(findings, "error", "CLAIM_SOURCES", f"{path}.source_ids", "Must be an array")
            source_ids = []
        if claim.get("type") in {"fact", "inference", "estimate"} and not source_ids:
            add(findings, "error", "UNSUPPORTED_CLAIM", f"{path}.source_ids", "Fact/inference/estimate requires at least one source")
        linked_sources = []
        for source_id in source_ids:
            if source_id not in source_by_id:
                add(findings, "error", "UNKNOWN_SOURCE", f"{path}.source_ids", f"Unknown source id: {source_id}")
            else:
                linked_sources.append(source_by_id[source_id])
        weak_only = linked_sources and all(
            source.get("access_level") in {"snippet_only", "synthetic"}
            for source in linked_sources
        )
        synthetic_only = linked_sources and all(source.get("origin") == "synthetic" for source in linked_sources)
        if claim.get("importance") == "core" and weak_only:
            add(findings, "error", "CORE_WEAK_ACCESS", f"{path}.source_ids", "Core claim cannot rely only on snippets or synthetic sources")
        elif weak_only:
            add(findings, "warning", "WEAK_ACCESS", f"{path}.source_ids", "Claim relies only on snippets or synthetic sources")
        if claim.get("importance") == "core" and synthetic_only:
            add(findings, "error", "CORE_SYNTHETIC_ONLY", f"{path}.source_ids", "Core claim cannot rely only on synthetic sources")

    # Assumptions.
    raw_assumptions = payload.get("assumptions")
    if not isinstance(raw_assumptions, list):
        add(findings, "error", "ASSUMPTIONS_TYPE", "$.assumptions", "assumptions must be an array")
        raw_assumptions = []
    assumption_by_id: Dict[str, Mapping[str, Any]] = {}
    for index, raw_assumption in enumerate(raw_assumptions):
        path = f"$.assumptions[{index}]"
        if not is_mapping(raw_assumption):
            add(findings, "error", "ASSUMPTION_TYPE", path, "assumption must be an object")
            continue
        assumption = raw_assumption
        _required_fields(findings, assumption, ("id", "opportunity_id", "category", "statement", "impact", "uncertainty", "status", "source_ids"), path)
        assumption_id = assumption.get("id")
        if not nonempty_string(assumption_id):
            add(findings, "error", "ASSUMPTION_ID", f"{path}.id", "Must be non-empty")
            continue
        if assumption_id in assumption_by_id:
            add(findings, "error", "DUPLICATE_ASSUMPTION", f"{path}.id", f"Duplicate assumption id: {assumption_id}")
        assumption_by_id[assumption_id] = assumption
        if assumption.get("category") not in ASSUMPTION_CATEGORIES:
            add(findings, "error", "ASSUMPTION_CATEGORY", f"{path}.category", f"Must be one of {sorted(ASSUMPTION_CATEGORIES)}")
        if not nonempty_string(assumption.get("statement")):
            add(findings, "error", "ASSUMPTION_STATEMENT", f"{path}.statement", "Must be non-empty")
        for field in ("impact", "uncertainty"):
            if not number_in_range(assumption.get(field), 1, 5):
                add(findings, "error", "ASSUMPTION_SCORE", f"{path}.{field}", "Must be 1-5")
        if assumption.get("status") not in ASSUMPTION_STATUSES:
            add(findings, "error", "ASSUMPTION_STATUS", f"{path}.status", f"Must be one of {sorted(ASSUMPTION_STATUSES)}")
        source_ids = assumption.get("source_ids")
        if not isinstance(source_ids, list):
            add(findings, "error", "ASSUMPTION_SOURCES", f"{path}.source_ids", "Must be an array")
            source_ids = []
        if assumption.get("status") != "unknown" and not source_ids:
            add(findings, "error", "ASSUMPTION_EVIDENCE", f"{path}.source_ids", "Non-unknown assumption requires evidence")
        for source_id in source_ids:
            if source_id not in source_by_id:
                add(findings, "error", "UNKNOWN_SOURCE", f"{path}.source_ids", f"Unknown source id: {source_id}")

    # Opportunities and their gates.
    raw_opportunities = payload.get("opportunities")
    if not isinstance(raw_opportunities, list):
        add(findings, "error", "OPPORTUNITIES_TYPE", "$.opportunities", "opportunities must be an array")
        raw_opportunities = []
    opportunity_by_id: Dict[str, Mapping[str, Any]] = {}
    for index, raw_opportunity in enumerate(raw_opportunities):
        path = f"$.opportunities[{index}]"
        if not is_mapping(raw_opportunity):
            add(findings, "error", "OPPORTUNITY_TYPE", path, "opportunity must be an object")
            continue
        opportunity = raw_opportunity
        _required_fields(
            findings,
            opportunity,
            (
                "id", "title", "problem", "buyer", "payer", "current_alternative",
                "distribution_path", "why_now", "decision_score", "evidence_confidence",
                "maturity_code", "status", "claim_ids", "assumption_ids",
                "evidence_signals", "hard_stops",
            ),
            path,
        )
        opportunity_id = opportunity.get("id")
        if not nonempty_string(opportunity_id):
            add(findings, "error", "OPPORTUNITY_ID", f"{path}.id", "Must be non-empty")
            continue
        if opportunity_id in opportunity_by_id:
            add(findings, "error", "DUPLICATE_OPPORTUNITY", f"{path}.id", f"Duplicate opportunity id: {opportunity_id}")
        opportunity_by_id[opportunity_id] = opportunity
        for field in ("title", "problem", "buyer", "payer", "current_alternative", "distribution_path", "why_now"):
            if not nonempty_string(opportunity.get(field)):
                add(findings, "error", "OPPORTUNITY_TEXT", f"{path}.{field}", "Must be non-empty")
        for field in ("decision_score", "evidence_confidence"):
            if not number_in_range(opportunity.get(field), 0, 100):
                add(findings, "error", "OPPORTUNITY_SCORE", f"{path}.{field}", "Must be 0-100")
        maturity = opportunity.get("maturity_code")
        if maturity not in MATURITY_CODES:
            add(findings, "error", "MATURITY", f"{path}.maturity_code", f"Must be one of {sorted(MATURITY_CODES)}")
        status = opportunity.get("status")
        if status not in OPPORTUNITY_STATUSES:
            add(findings, "error", "OPPORTUNITY_STATUS", f"{path}.status", f"Must be one of {sorted(OPPORTUNITY_STATUSES)}")
        hard_stops = opportunity.get("hard_stops")
        if not isinstance(hard_stops, list) or any(not nonempty_string(stop) for stop in hard_stops):
            add(findings, "error", "HARD_STOPS", f"{path}.hard_stops", "Must be an array of non-empty strings")
            hard_stops = []
        signals = opportunity.get("evidence_signals")
        if not is_mapping(signals):
            add(findings, "error", "EVIDENCE_SIGNALS", f"{path}.evidence_signals", "Must be an object")
            signals = {}
        else:
            missing = sorted(set(EVIDENCE_SIGNAL_FIELDS) - set(signals))
            unknown = sorted(set(signals) - set(EVIDENCE_SIGNAL_FIELDS))
            if missing:
                add(findings, "error", "EVIDENCE_SIGNAL_MISSING", f"{path}.evidence_signals", f"Missing: {', '.join(missing)}")
            if unknown:
                add(findings, "error", "EVIDENCE_SIGNAL_UNKNOWN", f"{path}.evidence_signals", f"Unknown: {', '.join(unknown)}")
            for field in EVIDENCE_SIGNAL_FIELDS:
                if field in signals and not nonnegative_int(signals[field]):
                    add(findings, "error", "EVIDENCE_SIGNAL_COUNT", f"{path}.evidence_signals.{field}", "Must be a non-negative integer")
        derived = conservative_maturity(signals)
        if maturity in MATURITY_CODES and maturity != derived:
            add(findings, "error", "MATURITY_MISMATCH", f"{path}.maturity_code", f"Declared {maturity}, conservative evidence signals derive {derived}")

        claim_ids = opportunity.get("claim_ids")
        if not isinstance(claim_ids, list) or not claim_ids:
            add(findings, "error", "OPPORTUNITY_CLAIMS", f"{path}.claim_ids", "Must be a non-empty array")
            claim_ids = []
        linked_claims = []
        for claim_id in claim_ids:
            if claim_id not in claim_by_id:
                add(findings, "error", "UNKNOWN_CLAIM", f"{path}.claim_ids", f"Unknown claim id: {claim_id}")
            else:
                linked_claims.append(claim_by_id[claim_id])
        assumption_ids = opportunity.get("assumption_ids")
        if not isinstance(assumption_ids, list) or not assumption_ids:
            add(findings, "error", "OPPORTUNITY_ASSUMPTIONS", f"{path}.assumption_ids", "Must be a non-empty array")
            assumption_ids = []
        for assumption_id in assumption_ids:
            if assumption_id not in assumption_by_id:
                add(findings, "error", "UNKNOWN_ASSUMPTION", f"{path}.assumption_ids", f"Unknown assumption id: {assumption_id}")
            elif assumption_by_id[assumption_id].get("opportunity_id") != opportunity_id:
                add(findings, "error", "ASSUMPTION_OPPORTUNITY", f"{path}.assumption_ids", f"Assumption {assumption_id} belongs to another opportunity")

        linked_sources = [
            source_by_id[source_id]
            for claim in linked_claims
            for source_id in claim.get("source_ids", [])
            if source_id in source_by_id
        ]
        classes = {source.get("evidence_class") for source in linked_sources}
        if maturity in {"M3", "M4", "M5"} and not classes.intersection({"commitment", "transaction", "delivery"}):
            add(findings, "error", "MATURITY_DEMAND_SOURCE", path, "M3+ requires commitment, transaction, or delivery source")
        if maturity in {"M4", "M5"} and not {"transaction", "delivery"}.issubset(classes):
            add(findings, "error", "MATURITY_DELIVERY_SOURCE", path, "M4+ requires both transaction and delivery sources")
        if status in {"GO_PILOT", "GO_SCALE"}:
            if hard_stops:
                add(findings, "error", "GO_HARD_STOP", f"{path}.hard_stops", "Go status cannot contain hard stops")
            for claim in linked_claims:
                if claim.get("importance") == "core" and (
                    claim.get("type") == "unverified"
                    or claim.get("freshness_status") in {"Missing", "Conflicting", "Stale"}
                ):
                    add(findings, "error", "GO_CORE_EVIDENCE", path, "Go status requires fresh, non-conflicting verified core claims")
        if status == "GO_PILOT" and (
            MATURITY_RANK.get(maturity, -1) < MATURITY_RANK["M3"]
            or opportunity.get("decision_score", -1) < 75
            or opportunity.get("evidence_confidence", -1) < 65
        ):
            add(findings, "error", "GO_PILOT_GATE", path, "GO_PILOT requires score>=75, confidence>=65, and M3+")
        if status == "GO_SCALE" and (
            maturity != "M5"
            or opportunity.get("decision_score", -1) < 80
            or opportunity.get("evidence_confidence", -1) < 70
        ):
            add(findings, "error", "GO_SCALE_GATE", path, "GO_SCALE requires score>=80, confidence>=70, and M5")

    # Check reverse assumption relationship after opportunity IDs exist.
    for index, assumption in enumerate(raw_assumptions):
        if is_mapping(assumption) and assumption.get("opportunity_id") not in opportunity_by_id:
            add(findings, "error", "UNKNOWN_OPPORTUNITY", f"$.assumptions[{index}].opportunity_id", f"Unknown opportunity id: {assumption.get('opportunity_id')}")

    # Experiments.
    raw_experiments = payload.get("experiments")
    if not isinstance(raw_experiments, list):
        add(findings, "error", "EXPERIMENTS_TYPE", "$.experiments", "experiments must be an array")
        raw_experiments = []
    experiment_ids = set()
    for index, raw_experiment in enumerate(raw_experiments):
        path = f"$.experiments[{index}]"
        if not is_mapping(raw_experiment):
            add(findings, "error", "EXPERIMENT_TYPE", path, "experiment must be an object")
            continue
        experiment = raw_experiment
        _required_fields(
            findings,
            experiment,
            ("id", "opportunity_id", "assumption_id", "hypothesis", "method", "metric", "threshold", "timebox", "budget_cap", "stop_rule", "owner", "status", "evidence_source_ids"),
            path,
        )
        experiment_id = experiment.get("id")
        if not nonempty_string(experiment_id):
            add(findings, "error", "EXPERIMENT_ID", f"{path}.id", "Must be non-empty")
        elif experiment_id in experiment_ids:
            add(findings, "error", "DUPLICATE_EXPERIMENT", f"{path}.id", f"Duplicate experiment id: {experiment_id}")
        else:
            experiment_ids.add(experiment_id)
        if experiment.get("opportunity_id") not in opportunity_by_id:
            add(findings, "error", "UNKNOWN_OPPORTUNITY", f"{path}.opportunity_id", "Experiment opportunity does not exist")
        if experiment.get("assumption_id") not in assumption_by_id:
            add(findings, "error", "UNKNOWN_ASSUMPTION", f"{path}.assumption_id", "Experiment assumption does not exist")
        elif assumption_by_id[experiment["assumption_id"]].get("opportunity_id") != experiment.get("opportunity_id"):
            add(findings, "error", "EXPERIMENT_RELATION", path, "Experiment assumption and opportunity do not match")
        for field in ("hypothesis", "method", "metric", "threshold", "timebox", "budget_cap", "stop_rule", "owner"):
            if not nonempty_string(experiment.get(field)):
                add(findings, "error", "EXPERIMENT_TEXT", f"{path}.{field}", "Must be non-empty")
        if experiment.get("status") not in EXPERIMENT_STATUSES:
            add(findings, "error", "EXPERIMENT_STATUS", f"{path}.status", f"Must be one of {sorted(EXPERIMENT_STATUSES)}")
        evidence_ids = experiment.get("evidence_source_ids")
        if not isinstance(evidence_ids, list):
            add(findings, "error", "EXPERIMENT_EVIDENCE", f"{path}.evidence_source_ids", "Must be an array")
            evidence_ids = []
        if experiment.get("status") in {"passed", "failed", "inconclusive", "stopped"} and not evidence_ids:
            add(findings, "error", "UNRUN_EXPERIMENT", f"{path}.evidence_source_ids", "Completed experiment status requires evidence")
        linked_evidence = []
        for source_id in evidence_ids:
            if source_id not in source_by_id:
                add(findings, "error", "UNKNOWN_SOURCE", f"{path}.evidence_source_ids", f"Unknown source id: {source_id}")
            else:
                linked_evidence.append(source_by_id[source_id])
        if linked_evidence and all(source.get("origin") == "synthetic" for source in linked_evidence):
            add(findings, "error", "SYNTHETIC_EXPERIMENT", path, "Synthetic-only evidence cannot complete a real experiment")

    # Decision.
    decision = payload.get("decision") if is_mapping(payload.get("decision")) else {}
    if not is_mapping(payload.get("decision")):
        add(findings, "error", "DECISION_TYPE", "$.decision", "decision must be an object")
    _required_fields(findings, decision, ("outcome", "selected_opportunity_id", "reason", "next_action", "evidence_that_changes_decision", "owner", "review_date"), "$.decision")
    outcome = decision.get("outcome")
    selected_id = decision.get("selected_opportunity_id")
    if outcome not in DECISION_OUTCOMES:
        add(findings, "error", "DECISION_OUTCOME", "$.decision.outcome", f"Must be one of {sorted(DECISION_OUTCOMES)}")
    for field in ("reason", "next_action", "owner"):
        if not nonempty_string(decision.get(field)):
            add(findings, "error", "DECISION_TEXT", f"$.decision.{field}", "Must be non-empty")
    if not isinstance(decision.get("evidence_that_changes_decision"), list) or not decision.get("evidence_that_changes_decision"):
        add(findings, "error", "DECISION_CHANGE_EVIDENCE", "$.decision.evidence_that_changes_decision", "Must be a non-empty array")
    if not valid_iso_date(decision.get("review_date")):
        add(findings, "error", "REVIEW_DATE", "$.decision.review_date", "Must be an ISO date")
    if outcome == "NO_QUALIFIED_OPPORTUNITY":
        if selected_id is not None:
            add(findings, "error", "NO_QUALIFIED_SELECTION", "$.decision.selected_opportunity_id", "NO_QUALIFIED_OPPORTUNITY must not select an opportunity")
        if any(opportunity.get("status") in {"TEST_NEXT", "GO_PILOT", "GO_SCALE"} for opportunity in opportunity_by_id.values()):
            add(findings, "error", "NO_QUALIFIED_CONFLICT", "$.decision.outcome", "Qualified candidate exists, so NO_QUALIFIED_OPPORTUNITY is inconsistent")
    elif selected_id is not None:
        if selected_id not in opportunity_by_id:
            add(findings, "error", "SELECTED_UNKNOWN", "$.decision.selected_opportunity_id", "Selected opportunity does not exist")
        elif outcome != opportunity_by_id[selected_id].get("status"):
            add(findings, "error", "DECISION_STATUS_MISMATCH", "$.decision.outcome", "Decision outcome must match selected opportunity status")
    elif outcome in {"GO_PILOT", "GO_SCALE", "TEST_NEXT", "WATCH"}:
        add(findings, "error", "SELECTED_REQUIRED", "$.decision.selected_opportunity_id", f"{outcome} requires a selected opportunity")

    # High-stakes selected source gate.
    if meta.get("high_stakes") is True and selected_id in opportunity_by_id:
        selected_claims = [
            claim_by_id[claim_id]
            for claim_id in opportunity_by_id[selected_id].get("claim_ids", [])
            if claim_id in claim_by_id and claim_by_id[claim_id].get("importance") == "core"
        ]
        has_official = any(
            source_by_id[source_id].get("source_type") in {"official", "primary_research"}
            for claim in selected_claims
            for source_id in claim.get("source_ids", [])
            if source_id in source_by_id
        )
        if not has_official:
            add(findings, "error", "HIGH_STAKES_SOURCE", "$.claims", "High-stakes selected opportunity requires official or primary research for core claims")

    # Optional content activation.
    content = payload.get("content_activation") if is_mapping(payload.get("content_activation")) else {}
    if not is_mapping(payload.get("content_activation")):
        add(findings, "error", "CONTENT_TYPE", "$.content_activation", "content_activation must be an object")
    if not isinstance(content.get("enabled"), bool):
        add(findings, "error", "CONTENT_ENABLED", "$.content_activation.enabled", "Must be boolean")
    if content.get("enabled") is True:
        _required_fields(findings, content, ("audience", "format", "claim_ids", "maturity_disclosure"), "$.content_activation")
        for field in ("audience", "format", "maturity_disclosure"):
            if not nonempty_string(content.get(field)):
                add(findings, "error", "CONTENT_TEXT", f"$.content_activation.{field}", "Must be non-empty")
        content_claim_ids = content.get("claim_ids")
        if not isinstance(content_claim_ids, list) or not content_claim_ids:
            add(findings, "error", "CONTENT_CLAIMS", "$.content_activation.claim_ids", "Enabled content requires claim_ids")
        else:
            for claim_id in content_claim_ids:
                if claim_id not in claim_by_id:
                    add(findings, "error", "UNKNOWN_CLAIM", "$.content_activation.claim_ids", f"Unknown claim id: {claim_id}")

    # URL allowlist and guarantee scans.
    for path, text_value in walk_strings(payload):
        if not path.endswith(".url"):
            for match in URL_RE.findall(text_value):
                candidate = match.rstrip(".,;:!?")
                if candidate not in allowed_urls:
                    add(findings, "error", "UNREGISTERED_URL", path, f"URL is not in the source register: {candidate}")
        for pattern in GUARANTEE_PATTERNS:
            if pattern.search(text_value):
                add(findings, "error", "GUARANTEE_LANGUAGE", path, f"Prohibited guarantee language matched: {pattern.pattern}")
                break

    return findings


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ContractError(f"input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ContractError(
            f"invalid JSON: line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Structured deliverable JSON")
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failures")
    parser.add_argument("--json", action="store_true", help="Emit machine-readable findings")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = load_json(args.input)
    except ContractError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    findings = validate(payload)
    errors = [finding for finding in findings if finding.severity == "error"]
    warnings = [finding for finding in findings if finding.severity == "warning"]
    failed = bool(errors) or (args.strict and bool(warnings))

    if args.json:
        print(
            json.dumps(
                {
                    "status": "FAIL" if failed else "PASS",
                    "errors": len(errors),
                    "warnings": len(warnings),
                    "findings": [finding.as_dict() for finding in findings],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        for finding in findings:
            print(
                f"{finding.severity.upper()} {finding.code} {finding.path}: {finding.message}"
            )
        print(f"{'FAIL' if failed else 'PASS'}: {len(errors)} error(s), {len(warnings)} warning(s)")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
