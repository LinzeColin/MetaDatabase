#!/usr/bin/env python3
"""Score commercial opportunities without hiding evidence maturity.

The standard-library-only script keeps attractiveness, risk, evidence
confidence, and evidence maturity separate. It is a decision-aid gate, not a
success predictor.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Sequence

ATTRACTIVENESS_WEIGHTS: Dict[str, float] = {
    "problem_severity_frequency": 16.0,
    "buyer_budget_wtp": 14.0,
    "reachability_distribution": 14.0,
    "alternative_inadequacy": 10.0,
    "value_capture_margin": 10.0,
    "structural_timing": 8.0,
    "operator_advantage": 8.0,
    "speed_to_evidence": 8.0,
    "delivery_feasibility": 7.0,
    "strategic_optionality": 5.0,
}

RISK_MAX_DEDUCTIONS: Dict[str, float] = {
    "evidence_gap": 8.0,
    "adoption_switching_friction": 6.0,
    "regulatory_liability": 6.0,
    "capital_access": 5.0,
    "competitive_response": 4.0,
    "concentration_dependency": 4.0,
    "delivery_complexity": 4.0,
    "freshness_decay": 3.0,
}

CONFIDENCE_WEIGHTS: Dict[str, float] = {
    "claim_coverage": 25.0,
    "source_quality": 20.0,
    "source_diversity": 15.0,
    "evidence_directness": 20.0,
    "recency": 10.0,
    "contradiction_resolution": 10.0,
}

ROI_FIELDS = ("learning", "customer", "commercial", "execution")
EVIDENCE_SIGNAL_FIELDS = (
    "desk_source_families",
    "customer_interviews",
    "observed_problem_instances",
    "commitments",
    "paid_transactions",
    "successful_deliveries",
    "repeat_customers",
)

MATURITY_LABELS = {
    "M0": "Hypothesis",
    "M1": "Desk-qualified",
    "M2": "Problem-evidenced",
    "M3": "Demand-evidenced",
    "M4": "Delivery-evidenced",
    "M5": "Scale-evidenced",
}
MATURITY_RANK = {code: rank for rank, code in enumerate(MATURITY_LABELS)}


class InputError(ValueError):
    """Raised when scoring input violates the contract."""


def _mapping(value: Any, path: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise InputError(f"{path} must be an object")
    return value


def _score(value: Any, path: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise InputError(f"{path} must be a number between 0 and 10")
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 10.0:
        raise InputError(f"{path} must be between 0 and 10; got {value!r}")
    return number


def _count(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise InputError(f"{path} must be a non-negative integer")
    return value


def _exact_scores(
    container: Mapping[str, Any], required: Mapping[str, float], path: str
) -> Dict[str, float]:
    missing = sorted(set(required) - set(container))
    unknown = sorted(set(container) - set(required))
    if missing:
        raise InputError(f"{path} missing fields: {', '.join(missing)}")
    if unknown:
        raise InputError(f"{path} has unknown fields: {', '.join(unknown)}")
    return {key: _score(container[key], f"{path}.{key}") for key in required}


def _evidence_signals(value: Any, path: str) -> Dict[str, int]:
    signals = _mapping(value, path)
    missing = sorted(set(EVIDENCE_SIGNAL_FIELDS) - set(signals))
    unknown = sorted(set(signals) - set(EVIDENCE_SIGNAL_FIELDS))
    if missing:
        raise InputError(f"{path} missing fields: {', '.join(missing)}")
    if unknown:
        raise InputError(f"{path} has unknown fields: {', '.join(unknown)}")
    return {key: _count(signals[key], f"{path}.{key}") for key in EVIDENCE_SIGNAL_FIELDS}


def validate_payload(payload: Any) -> List[Mapping[str, Any]]:
    root = _mapping(payload, "root")
    opportunities = root.get("opportunities")
    if not isinstance(opportunities, list):
        raise InputError("root.opportunities must be an array")

    seen_ids = set()
    validated: List[Mapping[str, Any]] = []
    for index, item in enumerate(opportunities):
        path = f"root.opportunities[{index}]"
        opportunity = _mapping(item, path)
        opportunity_id = opportunity.get("id")
        title = opportunity.get("title")
        if not isinstance(opportunity_id, str) or not opportunity_id.strip():
            raise InputError(f"{path}.id must be a non-empty string")
        if opportunity_id in seen_ids:
            raise InputError(f"duplicate opportunity id: {opportunity_id}")
        seen_ids.add(opportunity_id)
        if not isinstance(title, str) or not title.strip():
            raise InputError(f"{path}.title must be a non-empty string")
        if "thesis" in opportunity and not isinstance(opportunity["thesis"], str):
            raise InputError(f"{path}.thesis must be a string")

        _exact_scores(
            _mapping(opportunity.get("dimensions"), f"{path}.dimensions"),
            ATTRACTIVENESS_WEIGHTS,
            f"{path}.dimensions",
        )
        _exact_scores(
            _mapping(opportunity.get("risks"), f"{path}.risks"),
            RISK_MAX_DEDUCTIONS,
            f"{path}.risks",
        )
        _exact_scores(
            _mapping(opportunity.get("confidence"), f"{path}.confidence"),
            CONFIDENCE_WEIGHTS,
            f"{path}.confidence",
        )

        roi = _mapping(opportunity.get("roi"), f"{path}.roi")
        missing_roi = sorted(set(ROI_FIELDS) - set(roi))
        unknown_roi = sorted(set(roi) - set(ROI_FIELDS))
        if missing_roi:
            raise InputError(f"{path}.roi missing fields: {', '.join(missing_roi)}")
        if unknown_roi:
            raise InputError(f"{path}.roi has unknown fields: {', '.join(unknown_roi)}")
        for key in ROI_FIELDS:
            _score(roi[key], f"{path}.roi.{key}")

        _evidence_signals(opportunity.get("evidence_signals"), f"{path}.evidence_signals")
        hard_stops = opportunity.get("hard_stops", [])
        if not isinstance(hard_stops, list) or any(
            not isinstance(stop, str) or not stop.strip() for stop in hard_stops
        ):
            raise InputError(f"{path}.hard_stops must be an array of non-empty strings")
        validated.append(opportunity)
    return validated


def evidence_maturity(signals: Mapping[str, int]) -> str:
    if (
        signals["paid_transactions"] >= 3
        and signals["successful_deliveries"] >= 3
        and signals["repeat_customers"] >= 1
    ):
        return "M5"
    if signals["paid_transactions"] >= 1 and signals["successful_deliveries"] >= 1:
        return "M4"

    problem_evidenced = (
        signals["customer_interviews"] >= 3
        and signals["observed_problem_instances"] >= 2
    )
    if problem_evidenced and (
        signals["commitments"] >= 2 or signals["paid_transactions"] >= 1
    ):
        return "M3"
    if problem_evidenced:
        return "M2"
    if signals["desk_source_families"] >= 3:
        return "M1"
    return "M0"


def next_maturity_gate(code: str) -> str:
    gates = {
        "M0": "open at least 3 independent source families",
        "M1": "3 real interviews plus 2 observed problem instances",
        "M2": "2 resource commitments or 1 real paid transaction",
        "M3": "1 successful paid delivery with measured value",
        "M4": "repeatable paid delivery, repeat customer, and unit economics",
        "M5": "maintain evidence freshness and portfolio guardrails",
    }
    return gates[code]


def decision_status(
    score: float, confidence: float, maturity: str, hard_stops: Sequence[str]
) -> str:
    if hard_stops or score < 45.0:
        return "STOP"
    if score < 60.0:
        return "WATCH"
    if maturity == "M5" and score >= 80.0 and confidence >= 70.0:
        return "GO_SCALE"
    if MATURITY_RANK[maturity] >= MATURITY_RANK["M3"] and score >= 75.0 and confidence >= 65.0:
        return "GO_PILOT"
    return "TEST_NEXT"


def score_opportunity(opportunity: Mapping[str, Any]) -> Dict[str, Any]:
    dimensions = opportunity["dimensions"]
    risks = opportunity["risks"]
    confidence_parts = opportunity["confidence"]
    roi = opportunity["roi"]
    signals = opportunity["evidence_signals"]
    hard_stops = opportunity.get("hard_stops", [])

    base_score = sum(
        float(dimensions[key]) / 10.0 * weight
        for key, weight in ATTRACTIVENESS_WEIGHTS.items()
    )
    risk_deduction = sum(
        float(risks[key]) / 10.0 * maximum
        for key, maximum in RISK_MAX_DEDUCTIONS.items()
    )
    confidence = sum(
        float(confidence_parts[key]) / 10.0 * weight
        for key, weight in CONFIDENCE_WEIGHTS.items()
    )
    uncertainty_penalty = (100.0 - confidence) * 0.15
    final_score = max(0.0, min(100.0, base_score - risk_deduction - uncertainty_penalty))
    maturity = evidence_maturity(signals)
    status = decision_status(final_score, confidence, maturity, hard_stops)

    return {
        "id": opportunity["id"],
        "title": opportunity["title"],
        "thesis": opportunity.get("thesis", ""),
        "learning_roi": round(float(roi["learning"]), 1),
        "customer_roi": round(float(roi["customer"]), 1),
        "commercial_roi": round(float(roi["commercial"]), 1),
        "execution_roi": round(float(roi["execution"]), 1),
        "base_score": round(base_score, 2),
        "risk_deduction": round(risk_deduction, 2),
        "confidence": round(confidence, 2),
        "uncertainty_penalty": round(uncertainty_penalty, 2),
        "decision_score": round(final_score, 2),
        "maturity_code": maturity,
        "maturity": MATURITY_LABELS[maturity],
        "status": status,
        "hard_stop_count": len(hard_stops),
        "hard_stops": list(hard_stops),
        "next_maturity_gate": next_maturity_gate(maturity),
    }


def score_payload(payload: Any) -> List[Dict[str, Any]]:
    opportunities = validate_payload(payload)
    rows = [score_opportunity(opportunity) for opportunity in opportunities]
    rows.sort(
        key=lambda row: (
            row["status"] == "STOP",
            -row["decision_score"],
            -row["confidence"],
            row["id"],
        )
    )
    for rank, row in enumerate(rows, start=1):
        row["rank"] = rank
    return rows


def format_markdown(rows: Sequence[Mapping[str, Any]]) -> str:
    if not rows:
        return "NO_QUALIFIED_OPPORTUNITY: input contained no opportunity candidates."
    headers = [
        "排名", "ID", "机会", "R1", "R2", "R3", "R4", "基础分",
        "风险扣分", "置信度", "决策分", "成熟度", "状态", "下一门禁",
    ]
    keys = [
        "rank", "id", "title", "learning_roi", "customer_roi",
        "commercial_roi", "execution_roi", "base_score", "risk_deduction",
        "confidence", "decision_score", "maturity_code", "status",
        "next_maturity_gate",
    ]
    lines = [
        "| " + " | ".join(headers) + " |",
        "|" + "|".join(["---"] * len(headers)) + "|",
    ]
    for row in rows:
        values = [str(row[key]).replace("|", "\\|").replace("\n", " ") for key in keys]
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def format_csv(rows: Sequence[Mapping[str, Any]]) -> str:
    output = io.StringIO()
    fields = [
        "rank", "id", "title", "thesis", "learning_roi", "customer_roi",
        "commercial_roi", "execution_roi", "base_score", "risk_deduction",
        "confidence", "uncertainty_penalty", "decision_score", "maturity_code",
        "maturity", "status", "hard_stop_count", "next_maturity_gate",
    ]
    writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue().rstrip("\r\n")


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise InputError(f"input file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise InputError(
            f"invalid JSON in {path}: line {exc.lineno}, column {exc.colno}: {exc.msg}"
        ) from exc


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path, help="Input JSON file")
    parser.add_argument("--format", choices=("markdown", "json", "csv"), default="markdown")
    parser.add_argument("--output", type=Path, help="Optional output path; stdout when omitted")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        rows = score_payload(load_json(args.input))
    except InputError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if args.format == "json":
        rendered = json.dumps({"opportunities": rows}, ensure_ascii=False, indent=2)
    elif args.format == "csv":
        rendered = format_csv(rows)
    else:
        rendered = format_markdown(rows)

    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    else:
        print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
