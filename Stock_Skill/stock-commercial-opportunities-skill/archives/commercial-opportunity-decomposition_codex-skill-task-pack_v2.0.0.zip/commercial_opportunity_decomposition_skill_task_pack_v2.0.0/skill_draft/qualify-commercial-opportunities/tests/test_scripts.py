from __future__ import annotations

import copy
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.dont_write_bytecode = True

SKILL_DIR = Path(__file__).resolve().parents[1]
SCRIPTS = SKILL_DIR / "scripts"
ASSETS = SKILL_DIR / "assets"


def remove_caches() -> None:
    for cache in SKILL_DIR.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    for compiled in SKILL_DIR.rglob("*.py[co]"):
        try:
            compiled.unlink()
        except FileNotFoundError:
            pass


def setUpModule() -> None:
    remove_caches()


def tearDownModule() -> None:
    remove_caches()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


score_opportunities = load_module(
    "score_opportunities", SCRIPTS / "score_opportunities.py"
)
validate_deliverable = load_module(
    "validate_deliverable", SCRIPTS / "validate_deliverable.py"
)
validate_skill = load_module("validate_skill", SCRIPTS / "validate_skill.py")


class ScoreOpportunityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.payload = json.loads(
            (ASSETS / "opportunity-score-input.example.json").read_text(encoding="utf-8")
        )

    def test_example_separates_attractiveness_from_maturity(self) -> None:
        rows = score_opportunities.score_payload(self.payload)
        by_id = {row["id"]: row for row in rows}
        self.assertEqual([row["id"] for row in rows], ["O001", "O002", "O003"])
        self.assertEqual(by_id["O001"]["maturity_code"], "M3")
        self.assertEqual(by_id["O001"]["status"], "GO_PILOT")
        self.assertEqual(by_id["O002"]["maturity_code"], "M2")
        self.assertEqual(by_id["O002"]["status"], "TEST_NEXT")
        self.assertEqual(by_id["O003"]["status"], "STOP")
        self.assertGreater(by_id["O002"]["base_score"], 80)

    def test_hard_stop_overrides_score(self) -> None:
        candidate = self.payload["opportunities"][0]
        candidate["hard_stops"] = ["缺少合法授权"]
        row = score_opportunities.score_payload({"opportunities": [candidate]})[0]
        self.assertEqual(row["status"], "STOP")

    def test_empty_candidate_set_is_valid(self) -> None:
        rows = score_opportunities.score_payload({"opportunities": []})
        self.assertEqual(rows, [])
        self.assertIn("NO_QUALIFIED_OPPORTUNITY", score_opportunities.format_markdown(rows))

    def test_invalid_score_is_rejected(self) -> None:
        self.payload["opportunities"][0]["dimensions"]["buyer_budget_wtp"] = 11
        with self.assertRaises(score_opportunities.InputError):
            score_opportunities.score_payload(self.payload)

    def test_missing_dimension_is_rejected(self) -> None:
        del self.payload["opportunities"][0]["dimensions"]["reachability_distribution"]
        with self.assertRaises(score_opportunities.InputError):
            score_opportunities.score_payload(self.payload)

    def test_missing_evidence_signal_is_rejected(self) -> None:
        del self.payload["opportunities"][0]["evidence_signals"]["commitments"]
        with self.assertRaises(score_opportunities.InputError):
            score_opportunities.score_payload(self.payload)

    def test_markdown_exposes_risk_confidence_and_gate(self) -> None:
        rendered = score_opportunities.format_markdown(
            score_opportunities.score_payload(self.payload)
        )
        for token in ("风险扣分", "置信度", "成熟度", "下一门禁", "GO_PILOT"):
            self.assertIn(token, rendered)


class DeliverableValidatorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.payload = json.loads(
            (ASSETS / "deliverable.example.json").read_text(encoding="utf-8")
        )

    def findings(self):
        return validate_deliverable.validate(copy.deepcopy(self.payload))

    def assert_has(self, code: str, severity: str = "error") -> None:
        findings = self.findings()
        self.assertTrue(
            any(f.code == code and f.severity == severity for f in findings),
            msg="\n".join(f"{f.severity} {f.code} {f.path}: {f.message}" for f in findings),
        )

    def test_example_passes_without_findings(self) -> None:
        self.assertEqual(self.findings(), [])

    def test_zero_qualified_opportunity_is_a_valid_decision(self) -> None:
        self.payload["opportunities"] = []
        self.payload["assumptions"] = []
        self.payload["experiments"] = []
        self.payload["decision"].update(
            outcome="NO_QUALIFIED_OPPORTUNITY",
            selected_opportunity_id=None,
            reason="当前没有候选跨过资格门禁。",
            next_action="保留重开条件并在 review date 复核。",
        )
        self.assertEqual(self.findings(), [])

    def test_unsupported_fact_fails(self) -> None:
        self.payload["claims"][0]["source_ids"] = []
        self.assert_has("UNSUPPORTED_CLAIM")

    def test_unregistered_url_fails(self) -> None:
        self.payload["decision"]["next_action"] += " https://example.com/not-registered"
        self.assert_has("UNREGISTERED_URL")

    def test_snippet_only_cannot_support_core_claim(self) -> None:
        self.payload["sources"][0]["access_level"] = "snippet_only"
        self.assert_has("CORE_WEAK_ACCESS")

    def test_synthetic_only_cannot_support_core_claim(self) -> None:
        source = self.payload["sources"][0]
        source.update(
            source_type="synthetic_simulation",
            origin="synthetic",
            access_level="synthetic",
            evidence_class="desk",
        )
        self.assert_has("CORE_SYNTHETIC_ONLY")

    def test_declared_maturity_must_match_conservative_signals(self) -> None:
        self.payload["opportunities"][0]["maturity_code"] = "M3"
        self.assert_has("MATURITY_MISMATCH")

    def test_high_score_does_not_bypass_maturity_gate(self) -> None:
        self.payload["opportunities"][0]["status"] = "GO_PILOT"
        self.payload["decision"]["outcome"] = "GO_PILOT"
        self.assert_has("GO_PILOT_GATE")

    def test_private_source_in_public_output_requires_redaction(self) -> None:
        self.payload["meta"]["output_visibility"] = "public"
        source = self.payload["sources"][0]
        source.update(origin="private", access_level="internal_private", redacted=False)
        self.assert_has("PRIVATE_NOT_REDACTED")

    def test_completed_experiment_requires_evidence(self) -> None:
        self.payload["experiments"][0]["status"] = "passed"
        self.assert_has("UNRUN_EXPERIMENT")

    def test_guarantee_language_fails(self) -> None:
        self.payload["decision"]["reason"] += " 保证收入。"
        self.assert_has("GUARANTEE_LANGUAGE")

    def test_legitimate_100_percent_field_coverage_is_not_blocked(self) -> None:
        self.payload["meta"]["assumptions"].append("示例字段覆盖率为 100%，不代表商业成功。")
        self.assertFalse(any(f.code == "GUARANTEE_LANGUAGE" for f in self.findings()))

    def test_exact_creator_imitation_fails(self) -> None:
        self.payload["meta"]["style_reference"]["exact_creator_imitation"] = True
        self.assert_has("EXACT_IMITATION")

    def test_high_stakes_requires_boundary_and_primary_evidence(self) -> None:
        self.payload["meta"]["high_stakes"] = True
        for source in self.payload["sources"]:
            source["source_type"] = "media"
        codes = {finding.code for finding in self.findings()}
        self.assertIn("HIGH_STAKES_BOUNDARY", codes)
        self.assertIn("HIGH_STAKES_SOURCE", codes)


class SkillValidatorTests(unittest.TestCase):
    def test_current_skill_passes_strictly(self) -> None:
        remove_caches()
        self.assertEqual(validate_skill.validate_skill(SKILL_DIR), [])

    def test_extra_frontmatter_field_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            temp_skill = Path(tmp) / "demo-skill"
            temp_skill.mkdir()
            (temp_skill / "SKILL.md").write_text(
                "---\nname: demo-skill\ndescription: Use for testing. Do not use elsewhere.\nversion: 1\n---\n# Demo\n",
                encoding="utf-8",
            )
            findings = validate_skill.validate_skill(temp_skill)
            self.assertTrue(any("Unsupported frontmatter" in f.message for f in findings))


class CliSmokeTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [sys.executable, *args],
            cwd=SKILL_DIR,
            text=True,
            capture_output=True,
            check=False,
        )

    def test_score_cli(self) -> None:
        result = self.run_cli(
            str(SCRIPTS / "score_opportunities.py"),
            "--input",
            str(ASSETS / "opportunity-score-input.example.json"),
            "--format",
            "markdown",
        )
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertIn("GO_PILOT", result.stdout)

    def test_deliverable_cli_strict(self) -> None:
        result = self.run_cli(
            str(SCRIPTS / "validate_deliverable.py"),
            "--input",
            str(ASSETS / "deliverable.example.json"),
            "--strict",
        )
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("PASS", result.stdout)

    def test_skill_cli_strict(self) -> None:
        remove_caches()
        result = self.run_cli(
            str(SCRIPTS / "validate_skill.py"), str(SKILL_DIR), "--strict"
        )
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("PASS", result.stdout)


if __name__ == "__main__":
    unittest.main()
