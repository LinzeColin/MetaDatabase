---
name: qualify-commercial-opportunities
description: Research, deconstruct, qualify, and plan validation for commercial opportunities using traceable evidence, buyer economics, alternatives, distribution, assumptions, and fail-closed decision gates. Use for 商业机会拆解、赛道/需求/产品或服务机会研究、市场进入判断、痛点与付费方分析、竞争替代、机会评分、Go/No-Go、最小验证实验，或把已验证机会转成内容/咨询/产品化资产. Do not use for generic writing, unsupported startup-idea validation, investment recommendations, synthetic-customer claims presented as real demand, automatic outreach/publishing, or claims that public desk research proves product-market fit.
---

# Qualify Commercial Opportunities

Turn a vague trend, problem, capability, product idea, source pack, or existing business into a traceable opportunity decision and the cheapest useful next test.

## Preserve the core distinction

Keep two axes separate:

1. **Opportunity attractiveness** — problem economics, buyer and budget, alternatives, value capture, distribution reach, timing, operator advantage, delivery feasibility, and risk.
2. **Evidence maturity** — `M0 Hypothesis` → `M1 Desk-qualified` → `M2 Problem-evidenced` → `M3 Demand-evidenced` → `M4 Delivery-evidenced` → `M5 Scale-evidenced`.

A high attractiveness score never upgrades evidence maturity. Public research can qualify a hypothesis; it cannot prove willingness to pay, delivery value, repeatability, or product-market fit.

## Preserve these invariants

- Research before recommendation. Do not invent facts, sources, customers, quotes, prices, market sizes, or results.
- Distinguish user, payer, budget owner, influencer, blocker, channel partner, and cost bearer.
- Include direct competitors, adjacent substitutes, manual workarounds, internal build, non-consumption, and doing nothing.
- Treat reach and distribution as first-class opportunity risks, not a footnote.
- Label every important statement as Fact, Inference, Estimate, Opinion, or Unverified.
- Open source pages before using them. Search snippets and synthetic respondents may generate hypotheses but cannot independently support core claims.
- Prefer a valid zero-result outcome over filler. Do not force a fixed number of opportunities or sources.
- Make every next step reversible, time-boxed, measurable, and tied to the riskiest assumption.
- Never guarantee revenue, returns, traffic, conversion, market share, product-market fit, or ranking.

## Choose one lane

- **SCOUT** — fast public scan for one decision; usually 3–6 source families and up to 5 candidates.
- **QUALIFY** — default; two research passes, contradiction check, adaptive candidate count, and Top 1–3 dossiers.
- **VALIDATE** — design or assess real customer/behavior/commitment/delivery experiments; public research alone cannot complete this lane.

Read [workflow.md](references/workflow.md) for lane budgets, stage gates, and stop rules.

## Execute this sequence

1. **Normalize the decision.** Identify the decision object (`product`, `service`, `market_entry`, `partnership`, `internal_capability`, or `content_activation`), actor, geography, horizon, constraints, decision owner, and maximum acceptable test cost. Ask at most three numbered questions only when missing input changes scope, law, or acceptance.
2. **Map the job and current behavior.** State the struggling moment, desired progress, frequency/severity, current workaround, switching forces, and non-consumption. Separate observed behavior from assumed need. Read [opportunity-model.md](references/opportunity-model.md).
3. **Map commercial mechanics.** Identify user/payer/budget owner, trigger event, buying criteria, decision chain, value capture, delivery cost, distribution path, adoption friction, liability, and why now.
4. **Build a source and claim register.** Follow [evidence-protocol.md](references/evidence-protocol.md). Record source access state and evidence class. Do not cite an unopened page or allow a snippet-only source to support a core claim.
5. **Generate and prune candidates.** Use a candidate cap, not a quota. Stop at saturation; allow `NO_QUALIFIED_OPPORTUNITY`. Reject candidates with no specific buyer/problem, unreachable distribution, inaccessible proof, hard safety conflict, or no reversible test.
6. **Create the assumption map.** For each survivor, list desirability, viability, feasibility, reachability, and risk assumptions. Prioritize by `decision impact × uncertainty ÷ test cost and time`.
7. **Score without laundering uncertainty.** Use [scoring-and-maturity.md](references/scoring-and-maturity.md) and `scripts/score_opportunities.py`. Keep attractiveness, risk, confidence, and maturity separate. Never manually promote maturity to make a recommendation look stronger.
8. **Choose the next gate.** Use [validation-experiments.md](references/validation-experiments.md). M0–M2 can normally produce `TEST_NEXT`, not `GO_PILOT`; `GO_SCALE` requires M5 evidence.
9. **Produce one decision contract.** Use [output-contracts.md](references/output-contracts.md): Radar, Opportunity Dossier, Validation Sprint, Go/No-Go Memo, Evidence Audit, or optional Content Activation.
10. **Run final gates.** Validate structured deliverables with `scripts/validate_deliverable.py`. Report unknowns, strongest countercase, evidence that would change the decision, owner, review date, and one highest-ROI next action.

## Fail closed

- If web access is unavailable, current facts are missing, a core source cannot be opened, or private evidence is inaccessible, stop at a research/validation plan and label the gap.
- If a request concerns personalized finance, medicine, law, tax, regulation, employment rights, safety, or another high-stakes domain, follow [safety-and-boundaries.md](references/safety-and-boundaries.md); do not provide personalized professional action.
- If the only demand evidence is an LLM persona, synthetic survey, community anecdote, search trend, or market-size estimate, maturity cannot exceed M1.
- If customer statements exist but no observed behavior or commitment exists, do not call demand validated.
- If no opportunity survives, return why, what was searched, and the smallest evidence that could reopen the decision.

## Use resources selectively

| Need | Read or run |
|---|---|
| Lanes, stages, budgets, saturation | [workflow.md](references/workflow.md) |
| Actors, jobs, alternatives, distribution, assumptions | [opportunity-model.md](references/opportunity-model.md) |
| Sources, claims, provenance, contradictions | [evidence-protocol.md](references/evidence-protocol.md) |
| Attractiveness, risk, confidence, maturity | [scoring-and-maturity.md](references/scoring-and-maturity.md) |
| Experiments, thresholds, stop rules | [validation-experiments.md](references/validation-experiments.md) |
| Deliverable shapes and JSON contract | [output-contracts.md](references/output-contracts.md) |
| Privacy, high-stakes, access, copyright | [safety-and-boundaries.md](references/safety-and-boundaries.md) |
| Optional opportunity-to-content conversion | [content-activation.md](references/content-activation.md) |
| Trigger, quality, calibration, and cost evals | [evaluation.md](references/evaluation.md) |
| Deterministic opportunity ranking | `python3 scripts/score_opportunities.py --help` |
| Structured evidence and decision gates | `python3 scripts/validate_deliverable.py --help` |
| Local package invariants | `python3 scripts/validate_skill.py .` |

End with a compact decision: current maturity, current status, why it is not stronger, the evidence that could change it, and the single next test with the best value of information.
