# Validation Card — {ID}

- Opportunity ID:
- Assumption ID/category:
- We believe:
- Target segment and actor:
- Current evidence/maturity:
- Why this is the highest-VOI unknown:

## Test

- Method:
- Observed behavior/event:
- Primary metric and denominator:
- Pass threshold:
- Fail/stop threshold:
- Timebox:
- Cash/coordination cap:
- Data/privacy boundary:
- Owner:

## Decision branches

- If pass:
- If fail:
- If inconclusive:
- Harm/safety stop:

## Result — fill only after run

- Status: planned / running / passed / failed / inconclusive / stopped
- Evidence source IDs:
- Deviations from protocol:
- Result and denominator:
- Assumption change:
- Maturity change:
- Decision change:
