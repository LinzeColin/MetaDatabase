# 商业机会拆解 Intake

## 决策合同

- Decision object: product / service / market_entry / partnership / internal_capability / content_activation
- Decision to change:
- Decision owner:
- Target actor/segment:
- Geography/jurisdiction:
- Horizon/as-of:
- Lane: SCOUT / QUALIFY / VALIDATE
- Max test time/cash/coordination:
- Output visibility: private / public

## 初始假设

- Struggling moment:
- Desired progress:
- Current alternatives/non-consumption:
- User / problem owner / payer / budget owner / veto:
- Economic consequence:
- Proposed value capture:
- Distribution path:
- Why now:
- Operator advantage/constraints:

## 可用证据

- Public sources:
- Customer interviews/support/sales:
- Behavioral/usage data:
- Commitments/transactions/delivery:
- Private or regulated data boundary:
- Known contradictions:

## 权限与非目标

- Allowed read actions:
- Allowed write/external actions:
- Explicit non-goals:
- Hard safety/compliance constraints:

## 验收与停止

- Decision threshold:
- Kill criteria:
- Source/time/cost cap:
- Evidence that would change the decision:
- Review date:
