# Opportunity Card — {ID}

## 一句话决定

- Status:
- Evidence maturity:
- Why not stronger:

## Problem

- Actor/segment:
- Struggling moment and past behavior:
- Frequency/severity/economic consequence:
- Desired progress:

## Commercial mechanics

- User / payer / budget owner / veto:
- Trigger and buying criteria:
- Current alternative / workaround / non-consumption:
- Push / Pull / Anxiety / Habit:
- Value delivered / price logic / delivery cost:
- Distribution and procurement path:
- Why now / window decay:

## Evidence

| Claim ID | Statement | Type | Source IDs | Access/evidence class | Freshness | Confidence |
|---|---|---|---|---|---|---:|

## Assumptions

| ID | Category | Statement | Impact | Uncertainty | Status | Fatal if false? |
|---|---|---|---:|---:|---|---|

## Scoring

- R1 Learning / R2 Customer / R3 Commercial / R4 Execution:
- Base score / risk deduction / evidence confidence / decision score:
- Sensitivity and evidence that changes ranking:

## Next gate

- Highest-VOI assumption:
- Validation Card ID:
- Owner / review date:
- Kill criteria:
