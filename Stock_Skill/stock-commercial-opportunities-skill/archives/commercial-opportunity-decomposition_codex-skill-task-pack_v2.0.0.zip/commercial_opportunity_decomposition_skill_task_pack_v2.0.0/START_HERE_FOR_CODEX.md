# Codex 起点

本任务包包含一个可验证但尚未安装的 Codex Skill 草案：`qualify-commercial-opportunities`，中文名“商业机会拆解”。它把产品、服务、市场进入、合作或内部能力方向转成证据校准的决策与下一验证，而不是直接生成“看起来合理”的 Top 3。

## 最小读取顺序

1. `AGENTS.md`
2. `CODEX_MASTER_TASK.md`
3. `DECISIONS_AND_DEFAULTS.md`
4. `skill_draft/qualify-commercial-opportunities/SKILL.md`

仅按当前阶段追加读取：

| 阶段 | 文件 | 退出条件 |
|---|---|---|
| 需求/研究复核 | `USER_REQUIREMENTS.md`, `RESEARCH_REPORT.md`, `REFERENCE_PROJECT_MATRIX.md` | 定位和差异有证据 |
| 设计/实现 | `TARGET_ARCHITECTURE.md`, `IMPLEMENTATION_PLAN.md` | 一个 Run Contract 范围确定 |
| 验证 | `ACCEPTANCE_CHECKLIST.md`, Skill 内 `references/evaluation.md` | 阻断检查有真实结果 |
| 交付 | `VALIDATION_REPORT.md`, `BLIND_SPOTS_AND_SURPRISES.md` | 未完成项和下一步明确 |

## 当前状态

| 项目 | 状态 |
|---|---|
| v2 公开研究与架构 | COMPLETE |
| Skill 草案、资产、脚本、确定性测试 | COMPLETE |
| 当前机器安装 | NOT_RUN（未获本请求授权） |
| 新鲜线程隐式触发评估 | NOT_RUN |
| 无 Skill / 有 Skill 模型 A/B | NOT_RUN |
| 真实客户需求与付费验证 | NOT_RUN；公开研究最高仅 M1 |

## 当前建议

先审阅 v2 的名称迁移与产品边界；确认后才运行安装与新鲜线程前向评估，不把“任务包通过”误写成“商业机会已验证”。
