# 公开研究报告：商业机会拆解 Skill

> 研究日期：2026-07-19；范围：公开可访问的官方方法、GitHub 项目/Issues 与产品页面。仓库热度和产品功能会变化，使用时应同次复核。本文只抽象模式，没有复制第三方代码。

## 1. 研究问题与方法

研究不是寻找一个可直接 fork 的“万能商业机会 Agent”，而是验证六个设计问题：

1. 现有深度研究项目如何保证来源可追溯与研究终止？
2. 产品发现方法如何把客户问题连接到机会与实验？
3. 市场/趋势工具如何组织 signal → insight → opportunity？
4. AI persona 或合成研究能证明到什么程度？
5. 独立产品项目真实失败在哪里？
6. 什么必须留在 Skill，什么应是更重的平台能力？

检索分四轮：官方方法与规范；高相关 GitHub 仓库；已知研究质量 Issues；反证/失败案例。只把打开过的页面作为证据，搜索摘要不单独支撑核心结论。

## 2. 核心结论

### 2.0 当前 Codex 规范支持轻量 Skill，而不是为此强制构建插件

[OpenAI 当前 Build Skills 指引](https://learn.chatgpt.com/docs/build-skills.md)将 Skill 定义为以 `SKILL.md` 为入口、可含 scripts/references/assets 的渐进披露包；用户级常用根为 `$HOME/.agents/skills`，仓库级为 `.agents/skills`，`agents/openai.yaml` 可提供界面元数据。插件更适合分发一组 Skills、apps 或 MCP，而本任务当前只需一个可审计的个人 Skill。

决策：保持单 Skill、标准库脚本和本地任务包；不为“看起来完整”引入插件、MCP 或平台依赖。实际安装前重新核验发现机制，必要时按当前文档刷新或重启。

### 2.1 原任务包解决了“内容研究”，没有完整解决“商业机会资格”

v1 的 12 个选题、Top 3 和叙事结构擅长内容生产，但没有硬性区分：真实问题、买方与付款人、分发/采购、资源承诺、交易、交付与复购。因此“商业机会拆解”若沿用旧 ID 和输出，会把用户的核心 job 缩窄成内容选题。

决策：v2 使用 `qualify-commercial-opportunities`，内容下沉为可选激活层。

### 2.2 Opportunity Tree 需要真实输入，不能从桌研凭空长出来

[Product Talk 的 Opportunity Solution Tree 指引](https://www.producttalk.org/2016/08/opportunity-solution-tree/)把目标客户/价值主张理论、明确 outcome 和故事型客户访谈作为重要前置。树本身是组织证据的模型，不是需求证据生成器。

决策：公开桌面来源最高 `M1 Desk-qualified`；升级 `M2` 至少需要真实访谈与观察到的问题实例。

### 2.3 验证必须在运行前写下可裁决门槛

[Strategyzer Test Card](https://www.strategyzer.com/library/validate-your-ideas-with-the-test-card)的关键价值是把假设、测试、度量和成功阈值显式化。只写“找 5 个用户聊聊”无法判定机会应升级、降级还是停止。

决策：Validation Card 必含行为/事件、分母、pass、fail/stop、timebox、cash/coordination cap 与三条决定分支。

### 2.4 “重要且未满足”比市场热度更接近机会，但仍不等于可进入业务

[Strategyn 的 Outcome-Driven Innovation](https://strategyn.com/outcome-driven-innovation-process/)将机会聚焦于重要且未被充分满足的需求，并区分需求与解决方案。它改善了问题筛选，但个人/小团队仍需验证付款人、价值捕获、分发和交付。

决策：吸引力轴加入 alternative inadequacy、buyer budget/WTP、reachability/distribution、value capture 和 delivery feasibility。

### 2.5 机会管理产品的共同价值是“反馈—洞察—机会—决定”的可追溯关系

[Productboard Insights](https://www.productboard.com/product/insights/)与 [Dovetail Customer Insights](https://dovetail.com/customer-insights/)体现了把客户证据连接到产品决定的产品形态；[ITONICS](https://www.itonics-innovation.com/), [FIBRES](https://www.fibresonline.com/) 和 [Qmarkets](https://www.qmarkets.net/)则偏向 signal/trend/opportunity pipeline。

决策：Skill 不复制这些平台，但采用 source → claim → opportunity → assumption → experiment → decision 的 ID 关系。持久数据库、权限、去重和团队协作留给未来产品层。

### 2.6 深度研究系统的主要风险不是“不会写长文”，而是来源访问与引用完整性

[STORM](https://github.com/stanford-oval/storm)、[Open Deep Research](https://github.com/langchain-ai/open_deep_research) 与 [GPT Researcher](https://github.com/assafelovic/gpt-researcher)提供多阶段研究与引用模式；但真实 Issues 显示质量门禁仍不可省略：

- [GPT Researcher #1572](https://github.com/assafelovic/gpt-researcher/issues/1572)：报告生成可能在缺失上下文时产出看似合理的来源。
- [GPT Researcher #1727](https://github.com/assafelovic/gpt-researcher/issues/1727)：用户明确要求研究质量/来源可靠性评分。
- [GPT Researcher #1892](https://github.com/assafelovic/gpt-researcher/issues/1892)：搜索摘要可能被当成足够内容，抓取静默跳过。
- [Open Deep Research #232](https://github.com/langchain-ai/open_deep_research/issues/232)：引用格式契约冲突会破坏可用性。

决策：记录 `opened_fulltext / opened_partial / snippet_only`；core claim 不得只靠 snippet 或 synthetic；所有输出 URL 必须在 Source Register。

### 2.7 合成人格适合预试研究协议，不代表真实客户

[Expected Parrot EDSL](https://github.com/expectedparrot/edsl)明确提示模拟响应反映模型训练数据中的统计模式，不是实际人口意见，并应由真实人类数据验证。

决策：synthetic evidence 只用于找措辞、协议缺陷或分支覆盖；不能升级真实需求成熟度，也不能独立支持 core claim。

### 2.8 最大 Surprise：产品能工作，仍可能没有 PMF；分发必须是一等公民

[Emotix OSS](https://github.com/agshinrajabov/emotix-oss)的作者复盘称产品管线能够工作，但没有找到 product-market fit，并把 distribution 视为核心教训。这是对“功能完整 = 商业机会”的直接反证。

决策：`reachability_distribution` 权重与 buyer budget 并列为 14%；每张机会卡必须写渠道、采购路径、转换摩擦和成本假设。

## 3. GitHub 模式扫描

2026-07-19 GitHub API/仓库页快照覆盖：

- [openai/skills](https://github.com/openai/skills)：官方 Skill 示例与打包边界。
- [deanpeters/Product-Manager-Skills](https://github.com/deanpeters/Product-Manager-Skills)：opportunity solution tree、TAM/SAM/SOM、市场扫描等分工。
- [phuryn/pm-skills](https://github.com/phuryn/pm-skills)：discovery、assumption、market research、GTM 分离。
- [wondelai/skills](https://github.com/wondelai/skills)：continuous discovery、JTBD、non-consumption、push/pull/anxiety/habit。
- [crshdn/mission-control](https://github.com/crshdn/mission-control)：research → ideation → human selection → build/test/review，强调 cost cap 与分发自动化。
- [every-app/open-seo](https://github.com/every-app/open-seo)：聚焦式 SEO workflow、关键词与竞品 landscape。
- [Agentra-Labs/paper2product](https://github.com/Agentra-Labs/paper2product)：pain scanner、infrastructure inversion、temporal arbitrage、red-team destroyer 等 surprise lenses。
- [sansan0/TrendRadar](https://github.com/sansan0/TrendRadar)：多来源趋势聚合和雷达输出。
- [wnstify/tubeflow](https://github.com/wnstify/tubeflow)：视频研究/选题流水线的较窄实现。

这些项目证明“研究、发现、市场、GTM、交付”最好分层，而不是放进一个巨型提示。它们没有共同提供从证据成熟度到商业 Go gate 的完整、轻量、标准库可验证契约，因而 v2 采用组合抽象而非项目复制。

## 4. 对 Skill 设计的直接映射

| 研究发现 | 实现 |
|---|---|
| 真实机会树依赖客户输入 | `M1` 桌研上限、`M2` 真实 problem evidence |
| 实验要预注册阈值 | `validation-card-template.md` |
| 重要/未满足不等于可售 | buyer/payer/distribution/value capture/delivery 维度 |
| 研究工具会伪造/弱化来源 | access levels、URL allowlist、core claim 门禁 |
| AI personas 非真实意见 | synthetic-only 阻断与 maturity 上限 |
| 分发可导致有产品无 PMF | 14% 一级权重与必填 distribution path |
| 固定候选数诱发填充 | 0–N、饱和停止、`NO_QUALIFIED_OPPORTUNITY` |
| 平台有持久洞察能力 | Skill 保持轻量；数据库/权限/集成列为产品扩展 |

## 5. 研究边界

- 这是工具与方法设计研究，不是任何具体行业的市场尽调。
- GitHub stars 只表示公开关注度，不代表质量、采用或商业可行性；本 Skill 不把它用于机会评分。
- SaaS 产品页用于理解产品形态，不证明客户结果。
- 未运行真实买方访谈、行为、承诺、交易或交付，因此本报告不能把任何商业方向升级到 `M2+`。
- 法律、政策、价格、软件行为和产品功能在实际运行时必须同次复核。
