# Project instructions for Codex

## Scope

- Work on one bounded issue: review, install, or evolve `qualify-commercial-opportunities`.
- Start with this task pack and the exact destination directory; do not scan unrelated repositories or skills.
- Treat the bundled draft as the implementation baseline.
- Do not install, replace an existing skill, contact customers, publish content, or change external systems without matching user authority.

## Evidence-first workflow

1. Read `START_HERE_FOR_CODEX.md`, then the current Run Contract in `CODEX_MASTER_TASK.md`.
2. Verify current official Codex Skill authoring guidance before relying on paths or metadata.
3. Inspect the target path and collision state read-only.
4. Execute only one Run Contract at a time.
5. Run deterministic validation before semantic forward evaluation.
6. Report `PASS`, `FAIL`, `BLOCKED`, or `NOT_RUN`; missing evidence is never PASS.

## Integrity and safety

- Never fabricate sources, customers, interviews, transactions, experiments, market sizes, ROI, quotes, dates or validation results.
- Keep facts, inferences, estimates, assumptions and synthetic evidence distinguishable.
- Public desk research cannot establish real demand beyond `M1 Desk-qualified`.
- Synthetic personas are for protocol pretesting only and cannot support customer-demand maturity.
- Preserve private evidence boundaries; public output must not expose raw customer/internal material.
- No exact imitation of a living creator, access-control bypass, automatic outreach/publication, result guarantees, or personalized regulated advice.
- Do not copy third-party source code; independently implement attributed patterns.

## Engineering constraints

- Keep `SKILL.md` concise and use one-level progressive disclosure.
- Deterministic rules belong in standard-library-only scripts and tests.
- Prefer caps and saturation stops over fixed filler counts; zero qualified opportunities is valid.
- Keep one writer for synthesis. Parallel agents are optional only when explicitly authorized and independent read-only work clearly lowers elapsed time.
- Preserve clean packaging: no caches, logs, temp files, secrets, raw private data or generated benchmark claims.

## Handoff

Report exact files changed, commands and results, unrun semantic checks, install/rollback state, current maturity limits and the single highest-ROI next action.
