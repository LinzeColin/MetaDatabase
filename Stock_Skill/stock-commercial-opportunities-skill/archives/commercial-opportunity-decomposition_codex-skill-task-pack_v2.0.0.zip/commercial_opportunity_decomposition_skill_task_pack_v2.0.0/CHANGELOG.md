# Changelog

## 2.0.0 — 2026-07-19

Breaking redesign from “高 ROI 内容研究” to “商业机会拆解”。

- Stable invocation ID changed from `research-high-roi-content` to `qualify-commercial-opportunities`.
- Content creation moved to an optional downstream activation layer.
- Added separate opportunity attractiveness and evidence-maturity axes (`M0`–`M5`).
- Added buyer/payer/budget owner/veto, distribution, value capture, alternatives and delivery gates.
- Added `STOP / WATCH / TEST_NEXT / GO_PILOT / GO_SCALE` and valid zero-result output.
- Added assumption registry and thresholded Validation Cards with fail/stop branches.
- Added source access levels, synthetic-evidence limits, private/public boundaries and URL allowlisting.
- Replaced topic scorer with opportunity scorer; rewrote deliverable and package validators.
- Expanded deterministic tests, trigger cases and semantic quality cases.

## 1.0.0 — 2026-07-18

- Initial high-ROI content research task pack.
