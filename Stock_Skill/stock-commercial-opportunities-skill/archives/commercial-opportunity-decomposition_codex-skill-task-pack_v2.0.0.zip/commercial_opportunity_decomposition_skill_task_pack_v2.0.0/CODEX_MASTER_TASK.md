# Codex Master Task：商业机会拆解 Skill v2

## 目标

将本任务包中的 `qualify-commercial-opportunities` 审计、验证并在用户授权后安全安装，使 Codex 能把商业方向转化为可追溯的机会资格、证据成熟度、决策门禁和最便宜的决定性验证。

## 当前真实状态

| Gate | 状态 | 说明 |
|---|---|---|
| G0 需求与公开研究 | PASS | v2 定位和差异已写入任务包 |
| G1 草案架构与实现 | PASS | 当前 task-pack 已完成改写 |
| G2 确定性验收 | 见 `VALIDATION_REPORT.md` | 必须以同次命令结果为准 |
| G3 隐式触发 | NOT_RUN | 需新鲜任务/独立前向样本 |
| G4 质量 A/B | NOT_RUN | 不得用静态自评代替 |
| G5 全局安装与发现 | NOT_RUN | 当前请求未授权安装 |
| G6 商业需求验证 | NOT_RUN | 公开研究不超过 M1 |

## 完成定义

“任务包优化完成”要求 G0–G2 PASS、文档/manifest/zip 完整、G3–G6 明确保留状态。“Skill 已上线”则还要求 G3、G4、G5 有证据。任何情况下都不能把它写成“商业机会已验证”；真实机会还需 G6。

## 执行顺序

1. 根据 `IMPLEMENTATION_PLAN.md` 选择一个 Run Contract。
2. 输出 compact execution contract：目标、最小范围、检查/修改文件、验证、风险/回滚、停止条件。
3. 只做该 Run；失败时保留真实错误，不跨 Gate 宣布完成。
4. 更新 `VALIDATION_REPORT.md` 与必要 handoff。
5. 若下一 Run 涉及安装、外联或外部副作用，先核对授权。

## RC-1 当前推荐 Run：确定性验收

### 输入

- `skill_draft/qualify-commercial-opportunities/**`
- 当前官方 Skill authoring 指引
- `ACCEPTANCE_CHECKLIST.md`

### 允许修改

- 本任务包内直接相关文件。

### 禁止修改

- `~/.agents/skills/**`、`~/.codex/skills/**`。
- 其他 Skill、仓库或外部平台。
- 用户私有客户/财务/账户数据。

### 验收

- Package validator、deliverable validator、scorer 和 26 个单测通过。
- 官方 quick validator 通过或如实 `NOT_AVAILABLE`。
- JSON/JSONL 可解析；脚本无第三方依赖；无缓存/临时文件。
- `RESEARCH_REPORT`, `REFERENCE_PROJECT_MATRIX`, `BLIND_SPOTS_AND_SURPRISES` 与实现一致。

### 停止条件

- 草案或测试存在阻断失败。
- 当前官方规范与草案冲突且修改会扩大核心定位。
- 发现同名已安装 Skill 需要破坏性迁移。

## 后续 Run

- RC-2：新鲜线程触发与 3 个质量案例 A/B，记录原始输出和成本。
- RC-3：用户明确授权后 staging、备份、原子安装、发现 smoke 和回滚。
- 商业 VALIDATE：用户提供真实 segment、访谈/行为/承诺或允许设计并执行实验后，才升级某个机会成熟度。

## 最终报告格式

1. Outcome 与版本/路径。
2. 完成的 Gate 及原始命令结果。
3. 未完成 Gate 与原因。
4. Breaking changes 和迁移选择。
5. 盲点/Surprise Top 3。
6. 唯一下一步。
