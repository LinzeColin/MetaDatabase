# 用户需求与痛点定义

## 1. 重述后的核心任务

用户说的是“商业机会拆解”，因此核心工作不应是批量生成高 ROI 内容题，而应回答：

> 对一个产品、服务、市场进入、合作或内部能力方向，谁在什么情境下遭遇什么有经济后果的问题，谁会用哪笔预算付费，为什么现有替代不足，如何触达与交付，当前证据成熟到哪一步，以及最便宜的决定性下一测试是什么？

内容、脚本或系列只是资格审查后的可选激活层，不能替代真实客户、行为、承诺、交易或交付证据。

## 2. 痛点—失败—验收映射

| 痛点 | 常见失败 | v2 必须做到 | 可验证信号 |
|---|---|---|---|
| 把趋势当机会 | 热度/TAM 高就推荐 | 写清 problem actor、struggling moment、经济后果 | Opportunity Card 字段完整 |
| 把用户当付款人 | 只写 persona | 分开 user/problem owner/payer/budget owner/veto | 五角色缺失会降级 |
| 桌研冒充需求 | 公开报告后直接 GO | 独立给出 `M0`–`M5` 成熟度 | 仅 desk signals 导出最高 `M1` |
| 分数伪确定 | 87 分即“已验证” | 吸引力、风险、置信度、成熟度分列 | GO 状态需通过成熟度门禁 |
| 忽略分发 | 产品逻辑好就做 | reachability/distribution 为一级维度 | 具体渠道、采购路径和成本 |
| 固定 Top N 造填充 | 强行 12 个、Top 3 | 用上限与饱和停止，允许零结果 | `NO_QUALIFIED_OPPORTUNITY` |
| 实验不可裁决 | “去访谈一下” | 假设、方法、分母、阈值、时限、停止和分支 | Validation Card 可预注册 |
| AI 人格冒充市场 | 合成受访者证明需求 | 合成数据只做协议预试 | 不得升级真实需求成熟度 |
| 私有证据泄漏 | 工单/访谈原文进入公开物 | source origin、visibility、redaction 门禁 | public + private 未脱敏被阻断 |
| 内容先于商业 | 先做 30 条脚本 | 先资格审查，再可选 content activation | 上游状态与成熟度必须披露 |
| 自动化越权 | 自动外联/发布/购买 | 默认只读和本地交付 | 外部副作用需单独授权 |
| 研究成本失控 | 无限搜索、多 agent 堆上下文 | SCOUT/QUALIFY/VALIDATE 三条 lane + 饱和停止 | 时间/来源/协调 cap |

## 3. 目标用户与决策对象

- 默认操作者：个人创业者、产品负责人、顾问、创新团队或小团队。
- 默认约束：无重资产、无特殊牌照、无特权数据、时间和预算有限。
- 决策对象：`product / service / market_entry / partnership / internal_capability / content_activation`。
- 默认语言：中文；代码、字段、来源标题可保留英文。
- 默认产出：Decision Contract、证据台账、0–N 个 Opportunity Cards、Assumption Register、1 个最高 VOI Validation Card、Decision Memo。

## 4. 必须保持的业务区分

### 机会吸引力

问题严重度与频率、买方预算/支付意愿、分发可达性、替代不足、价值捕获、结构性时机、操作者优势、证据速度、交付可行性、战略可选性。

### 证据成熟度

- `M0 Hypothesis`：只有假设。
- `M1 Desk-qualified`：至少三类独立桌面来源，仍无真实需求证明。
- `M2 Problem-evidenced`：真实访谈和可观察问题实例。
- `M3 Demand-evidenced`：可核验资源承诺或交易。
- `M4 Delivery-evidenced`：有付费交付和测量价值。
- `M5 Scale-evidenced`：重复交付、复购与单位经济证据。

两轴不得合并成一个“成功概率”。高吸引力 `M1` 仍只能 `TEST_NEXT`。

## 5. 成功与非目标

成功是让用户更快停止坏机会、识别关键未知、运行较便宜且可裁决的验证，并保留证据链；不是保证收入、PMF、融资、增长、流量或市场成功。

明确不做：完整 CRM/洞察 SaaS、平台爬虫、自动销售、自动发布、个性化金融/医疗/法律意见、第三方代码复制、现实创作者精确模仿、未经授权处理私有系统。
