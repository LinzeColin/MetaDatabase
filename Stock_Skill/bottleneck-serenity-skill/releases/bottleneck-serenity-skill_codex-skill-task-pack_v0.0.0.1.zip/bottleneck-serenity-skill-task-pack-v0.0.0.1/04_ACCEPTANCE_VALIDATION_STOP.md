# Acceptance, Validation, and Stop Conditions

## 证据等级

| 等级 | 定义 | 可用于完成判定 |
|---|---|---|
| `A` | 当前文件、命令输出、测试日志、GitHub/CI 状态直接证明 | 是 |
| `B` | validator/manifest 间接证明，且已确认覆盖目标要求 | 是 |
| `C` | 文档声明、历史报告或人工推断 | 否，必须补强 |
| `MISSING` | 无证据 | 否 |

“命令无报错”只有在确认命令覆盖相应要求后才是有效证据。

## Finding 等级与状态

| 等级 | 定义 | 动作 |
|---|---|---|
| `P0` | 可能造成数据/权限/资金/凭据/不可逆 Git 损害或虚假放行 | 立即停止；不得继续该 Stage |
| `P1` | 违反用户、仓库或 required acceptance，足以使 Stage/交付无效 | Stage blocker；必须修复并重审 |
| `P2` | 会造成遗漏、漂移、不可维护或证据显著不足 | 按用户目标仍为 Stage blocker；必须修复并重审 |
| `P3` | 低风险清晰度或一致性缺陷 | Stage 上传前修复，除非用户显式接受延期 |

`required` 指用户、仓库合同或带 `ACC-*` ID 的强制项；未满足时最低为 `P1`。
Finding 状态只允许 `OPEN / FIXED_PENDING_REREVIEW / CLOSED`。Builder 只能写前两种；只有后续
Re-review 在新 subject 上复验通过后才能写 `CLOSED`。Ledger 位于 `CHANGELOG.md`，必须记录 finding ID、
severity、评审 subject digest、整改 Task、状态和关闭证据。

## Stage 0 Gate

- [ ] `ACC-S0-001`：canonical 主树始终在 `main` 且干净；任务 worktree/branch 独立。Stage 0
      pre-publish 时只允许 `Stock_Skill/bottleneck-serenity-skill/` 内的本 Stage scoped changes，禁止无关改动；
      `BSS-S0-P3-T001` commit 后任务 worktree 必须干净。
- [ ] `ACC-S0-002`：compact `5+1`、`VERSION` 与 `MANIFEST.sha256` 齐全，manifest 覆盖除自身外全部文件。
- [ ] `ACC-S0-003`：Stable ID、版本、source-only、无交易和 Git 上传策略在 Task Pack 中一致。
- [ ] `ACC-S0-004`：Stage/Phase/Task ID 唯一，一次 run 最多一个 Task，Phase 中途禁止上传。
- [ ] `ACC-S0-005`：每个 REQ/CAP/NG 与 ACC 都映射到 Task、Oracle/Test、Evidence/Artifact。
- [ ] `ACC-S0-006`：每个 Stage 都有 Review → Remediation → Re-review → Publish 门；Stage 0 历史 subject
      用 `taskpack-tree-sha256-v1`，Stage 1 起每个 Review subject 同时用该 digest 与完整
      `stage-worktree-source-sha256-v1` 独立复算并绑定。
- [ ] `ACC-S0-007`：Stage 0 整体复审完成，ledger 中没有任何非 `CLOSED` finding。

## Stage 1 Gate

- [ ] `ACC-S1-001`：registry schema 明确支持 `semver` 与 canonical `numeric-quad`，未知 scheme fail closed。
- [ ] `ACC-S1-002`：现有 `stock-commercial-opportunities=3.0.0` 的路径、版本、archive 和 SHA 无漂移。
- [ ] `ACC-S1-003`：新首版可声明空 `superseded_archives`，但缺字段/错误类型仍失败。
- [ ] `ACC-S1-004`：validator 隔离测试覆盖成功与失败路径，registry validator 输出 PASS。
- [ ] `ACC-S1-005`：根与 `Stock_Skill` 文档和机器规则一致。
- [ ] `ACC-S1-006`：专用 workflow 在 PR/main 自动运行 registry、tests、manifest 与公开安全门。

## Stage 2 Gate

- [ ] `ACC-S2-001`：canonical Skill 文件夹名与 frontmatter `name` 均为 `bottleneck-serenity-skill`。
- [ ] `ACC-S2-002`：`agents/openai.yaml` 存在，display name 精确一致，default prompt 调用
      `$bottleneck-serenity-skill`。
- [ ] `ACC-S2-003`：项目与 task-pack 两个 `VERSION` 均为 `0.0.0.1`。
- [ ] `ACC-S2-004`：canonical Skill 和 current release 中旧身份 token 搜索为零。
- [ ] `ACC-S2-005`：源包 53 项均有导入、迁移、外移或明确排除记录。
- [ ] `ACC-S2-006`：候选及 Publish 封印 release 均符合 deterministic ZIP contract，连续两次构建 SHA 相同。
- [ ] `ACC-S2-007`：hash DAG 无环；release SHA 与 `SHA256SUMS`、registry、backup manifest release entry
      三方一致，task manifest 仅覆盖 release 输入且不越出 Root。
- [ ] `ACC-S2-008`：registry 同时确定性验证两个 Skill；新 Skill 无伪造历史 archive。
- [ ] `ACC-S2-009`：未写入任何本机 Skill 运行时，也未产生 broker/order side effect。
- [ ] `ACC-S2-010`：`LICENSE_AND_ATTRIBUTION.md` 证明 proprietary 边界、来源与未复制第三方代码。
- [ ] `ACC-S2-011`：`RESTORE_AND_VERIFY.md` 从 staged/proposed tree 与干净 sparse checkout 均可重建
      并验证同一 sealed release。
- [ ] `ACC-S2-012`：语义 diff 未改变核心逻辑；若改变，已有影响/版本分析和用户决定。
- [ ] `ACC-S2-013`：输入输出、用户、默认值、维护和未来适配器契约与需求一致。

## Stage 3 Gate

- [ ] `ACC-S3-001`：Skill 结构 validator、项目 validator 和全部单元测试 PASS。
- [ ] `ACC-S3-002`：所有 JSON 可解析；schema、模板、示例和脚本输出契约一致。
- [ ] `ACC-S3-003`：全部正触发与鲁棒 case 达到预注册 rubric。
- [ ] `ACC-S3-004`：简单查价、普通财报摘要、概念解释不触发完整工作流。
- [ ] `ACC-S3-005`：下单请求被拒绝或明确不执行，零 broker/order side effect。
- [ ] `ACC-S3-006`：security/public scan 无 secret、本机路径、真实账户/组合/MNPI 或未声明二进制。
- [ ] `ACC-S3-007`：历史 E2E 的所有事实来源发布日期不晚于 source cutoff。
- [ ] `ACC-S3-008`：E2E 输出包含系统图、租金捕获、三个时钟、估值、反例、kill switch 和组合相关性。
- [ ] `ACC-S3-009`：独立 forward-test 未接收预期答案或诊断泄漏，仍能满足 rubric（Producer 的原 PASS 声明
  已被 `BSS-S3-P3-T001` Review 以 `S3-R002/R003` 否决；T002 已补齐 current v13 前置封印、独立 provenance、
  实际 stdin/schema replay 与 fresh 双 judge；T003 复验发现 manifest identity 与 exact-stdin trace
  仍不自洽；T004 已用 current v18 的独立 29-file context、严格前置封印、实际 host-return 三路
  exact stdin/stdout replay 与 fresh 双 judge `24/24 PASS` 完成整改；T005 已关闭 exact-trace 缺口，但发现
  `allowed_context/excluded_context` 只校验长度、语义 mutation fail open；T006 已把四条 allowed 与六条
  excluded 逐字/顺序/基数绑定并补齐 12 个 durable semantic mutations；T007 确认该语义门 PASS，但 v18
  seal 自述仅为 host-local ordering、非 external timestamp authority，同批制品仍不能独立证明前置时序，
  因此 `S3-R002` 未关闭）。
- [ ] `ACC-S3-010`：`CAP-001`–`CAP-009` 全部有正向与反向 Oracle，未被工程化迁移弱化。

`BSS-S3-P3-T009` 的 Re-review 4 verdict=`FAIL`：
`ACC-S3-001/003/004/005/007/008/010` PASS，`ACC-S3-002/006` FAIL，
`ACC-S3-009` `FAIL_EVIDENCE`，全局 `ACC-S0-005` FAIL；`ACC-S2-010` 已恢复 PASS。T009 证明
自然语言 unknown issuer 仍可穿透 presentation gate，合法 role-neutral 表述仍会被误杀；RFC3161
只独立绑定 control packet 而未绑定真实 executor start；public scanner 对 session/conversation/thread/
execution 同义 metadata 仍 fail open。`S3-R001/R002/R008/R009` 回到 `OPEN`，`S3-R010` `CLOSED`，
并新增追溯表漏列 T009 verifier 的 `S3-R011`。唯一下一 Task 是 T010 Remediation 5；当前仍不得进入
Stage 3 Publish。

`BSS-S3-P3-T010` 已完成 Remediation 5：共享 presentation gate 对 T009 的未知 issuer 与合法
role-neutral 探针均按预期判定；v22 provider attestation 由 pre/post RFC3161 seal、host receipt 与 exact
return bytes 共同绑定，失败谱系与时间线平移 mutant 均 fail closed；public-safety 同义 metadata
plain/ZIP 矩阵、类型化安全控制及 ACC-S3 verifier Task Graph 派生 Oracle 均通过。五项 finding 状态仅为
`FIXED_PENDING_REREVIEW`，T009 仍是最近一次独立 verdict=`FAIL`；只有
`BSS-S3-P3-T011 — Re-review 5` 可重判 `ACC-S3-002/006/009`、`ACC-S0-005` 与 Stage 3 gate。
当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T011` Re-review 5 verdict=`FAIL`：在任何 review 记录修改前冻结
269-path Stage source 与 279-file Task Pack，Python/Ruby 双实现同得
`stage=b4ab9b5653ae2cc5fc83c2d8f4ebbae33365977d153e88b5815e616989beb264` /
`taskpack=f1805e46525fee5f657938f054c00ce98a15e8f2589b3a8c20beb42274de33a3`，结束无漂移且 index 为空。
`ACC-S3-001/003/004/005/007/008/010` PASS，`ACC-S3-002/006` FAIL，`ACC-S3-009`
`FAIL_EVIDENCE`，`ACC-S0-005` PASS，`ACC-S2-010` `FAIL_EVIDENCE`。`S3-R011` CLOSED；presentation gate 对未知 issuer 与合法
role-neutral prose 仍双向误判，public scanner 仍漏放私有 metadata 同义键，pre/post RFC3161 仅封存
未认证的本地 provider-return/host-receipt bytes；项目 README 还保留旧 `229`-file 许可口径，故
`S3-R001/R002/R008/R009/R010` 回到 `OPEN`。
按确定性循环追加 `BSS-S3-P3-T012/T013`；唯一下一 Task 是 T012 Remediation 6，当前仍不得进入
Stage 3 Publish。

`BSS-S3-P3-T012` 已完成 Remediation 6：共享 presentation scanner 对 T011 的 46 个未知
issuer/beneficiary/selection/rent-capture 负例和 9 个 role-neutral 正例在 Historical/Forward 两面均按
预期判定；v22 被明确降级为非 provider-generation proof，v23 用 30-file read-only projection、外层
sandbox、fresh ephemeral provider 和双端 exact-return replay 建立 T013 必须现场执行的 live-observation
protocol；public-safety 同义 metadata 语义 scanner 与 plain/ZIP durable matrix fail closed；四份
owner-facing 文档、collector 与 committed license report 统一为 278 targets。五项 finding 状态仅为
`FIXED_PENDING_REREVIEW`，T011 仍是最近一次独立 verdict=`FAIL`；只有
`BSS-S3-P3-T013 — Re-review 6` 可现场重跑 v23 并重判相关 ACC、finding 与 Stage 3 gate。
当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T013` Re-review 6 verdict=`FAIL`：在任何 review 记录修改前冻结
276-path Stage source 与 286-file Task Pack，Python/Ruby 双实现同得
`stage=41c56ceb2c270848d655935d155aefce876b6c19af2a005af0f000698806dd21` /
`taskpack=0767fe0b4b349352f592ff1c0442b62d6f83cee8c2d368f6a4a314bae95725b7`，index/unmerged 为空。
T013 现场执行 v23 live protocol，证明 fresh provider 在 30-file read-only projection 中生成 29,862-byte
exact return，provider/host strict replay 与 sandbox probes 全部符合预注册协议，故
`S3-R002` CLOSED、`ACC-S3-009` PASS。四个 fresh full clone 的 278-target/2,489/2,485 byte-identical
许可重算也通过，故 `S3-R010` CLOSED、`ACC-S2-010` PASS。但独立新鲜探针发现 20/20 命名 issuer/rent
负例被错误接受、12/12 role-neutral 正例被错误拒绝，12 类新私有 metadata key 的 plain/ZIP 共
24/24 探针被错误接受，因此 `S3-R001/R008/R009` 保持 `OPEN`，`ACC-S3-002/006` FAIL。
其余 Stage 3 ACC 与 `ACC-S0-005` PASS；按确定性循环追加 T014/T015，唯一下一 Task 是
`BSS-S3-P3-T014 — Remediation 7`，当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T014` 已完成 Remediation 7：presentation 共用 helper 绑定 151 个 negative、73 个
role-neutral positive 和 41 个 exact-entity witness；独立盲测冻结七组 131 REJECT / 92 ACCEPT，
二元与完整 Unicode/数字实体判据均为 `223/223 PASS`。public-safety 的 flat/ancestry private-metadata
语义门经独立 29-case / 58-surface plain/ZIP matrix 全 PASS。`S3-R001/R008/R009` 只推进为
`FIXED_PENDING_REREVIEW`；T013 仍是最近一次独立 Stage verdict=`FAIL`。只有
`BSS-S3-P3-T015 — Re-review 7` 可在新双 digest subject 上关闭 finding 并重判 `ACC-S3-002/006`
与 Stage 3 gate；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T015` 已在 287-file Task Pack / 277-path Stage source 新双 digest subject 上完成独立
Re-review 7。第八组 presentation blind set（60 REJECT / 40 ACCEPT）在 source 与 release 两面均只有
`66/100` 二元、`62/100` 完整实体严格通过；另一 reviewer 的 Historical 真 CLI 也复现 10/10
新 issuer 漏拒与 7/7 role-neutral 误拒。public-safety blind set 为 48 cases / 96 plain-or-ZIP
surfaces，仅 `78/96` 正确，遗漏 `locator/cursor/alias` 与深层 ancestry，并误拒明确 public research
request reference；另一 reviewer 复现五类 neutral-envelope 深层路径 `10/10` 漏放。因此
`ACC-S3-002/006` FAIL，`S3-R001/R008/R009` 回到 `OPEN`，其余 Stage 3 ACC、
`ACC-S0-005` 与 `ACC-S2-010` PASS，未新增独立 P1/P2。按确定性循环追加 T016/T017，唯一下一
Task 是 `BSS-S3-P3-T016 — Remediation 8`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T016` 已完成受限整改：presentation gate 使用 bounded semantic slots 代替任意
modal-subject 兜底，durable matrix 为 175 REJECT / 85 ACCEPT / 58 exact-entity witness，均零失败；
public-safety 对 `locator/cursor/alias`、neutral-container ancestry 与 private-context 任意 UUID
fail closed，同时允许稳定的描述性 public research request reference，并以 business-boundary
control 防止上下文过度继承。`S3-R001/R008/R009` 仅推进为 `FIXED_PENDING_REREVIEW`，
`ACC-S3-002/006` 仍须由 T017 重判。唯一下一 Task 是
`BSS-S3-P3-T017 — Re-review 8`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T017` 已在 288-file Task Pack / 278-path Stage source 的新双 digest subject 上完成独立
Re-review 8。第九组 presentation blind set（60 REJECT / 40 ACCEPT）在 source/release 两面均只有
`67/100` binary、`62/100` strict：26 个命名实体漏拒、7 个合法 role-neutral 正例误拒、5 个拒绝
结果缺少完整实体 witness；另一 reviewer 的 Historical/Forward 真 CLI 仅 `7/18` 正确。
public-safety blind set 为 72 cases / 144 plain-or-ZIP surfaces，仅 `67/72` / `134/144` 正确；
另一个非重复 probe 对 `pages/segments/nodes/list/array/collection` 结构层仅 `12/24` surfaces 正确。
因此 `ACC-S3-002/006` FAIL，`S3-R001/R008/R009` 回到 `OPEN`。current v23 protocol 明确要求
T017 现场执行，但 provider 因 usage limit 在生成前退出，未取得 exact return/host replay，故
`ACC-S3-009=FAIL_EVIDENCE`、`S3-R002` 对 current production tree 重开为 `OPEN`。其余 Stage 3 ACC、
`ACC-S0-005` 与 `ACC-S2-010` PASS，未新增独立 P1/P2。按确定性循环追加 T018/T019，唯一下一 Task 是
`BSS-S3-P3-T018 — Remediation 9`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T018` 已完成 Remediation 9：presentation durable matrix 扩为 184 REJECT /
93 ACCEPT / 67 exact-entity witness，补充的 64 个 Unicode/CJK/数字实体跨句式 strict probes 与
12 个相邻 role-neutral controls 全 PASS；public-safety 已覆盖 T017 六类结构层、五类稳定公开
reference controls、malformed UUID/object references 与非 JSON provider-session 明文的
plain/DEFLATED-ZIP surfaces。current-tree v23 live run 在 30-file production-only projection 中
以 9 searches / 8 pages 生成 30,116-byte exact return，allowed/denied sandbox probes、provider exit
与 host replay 全部符合预注册协议。`S3-R001/S3-R002/S3-R008/S3-R009` 仅推进为
`FIXED_PENDING_REREVIEW`；T017 仍是最近一次独立 verdict=`FAIL`，相关 ACC 不由 Builder 重判。
唯一下一 Task 是 `BSS-S3-P3-T019 — Re-review 9`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T019` 已在 289-file Task Pack / 28-path Stage source 的新双 digest subject 上完成独立
Re-review 9。第十组 presentation blind set 在 source/release 两面行为一致，但每面 192 REJECT /
24 ACCEPT 仅 `144/216` binary、`99/216` strict：64 个命名实体完全漏拒、45 个结果缺完整实体
witness、8 个合法 role-neutral 正例误拒。public-safety 84 个 plain/DEFLATED-ZIP 判定仅 `72/84`：
五类非 JSON 私有 identifier 句式两面共 10 次漏检，validator-replay 业务 UUID 两面共 2 次误杀。
因此 `ACC-S3-002/006` FAIL，`S3-R001/R008/R009` 回到 `OPEN`。原样 current-tree v23 live
witness 在 30-file production-only projection 中以 10 searches / 8 pages 生成 28,010-byte exact
return，sandbox allow/deny、provider exit、host replay 与无 prior answer/diagnosis 均 PASS，故
`S3-R002` CLOSED、`ACC-S3-009` PASS。其余 Stage 3 ACC、`ACC-S0-005` 与 `ACC-S2-010` PASS，
未新增独立 P1/P2。按确定性循环追加 T020/T021，唯一下一 Task 是
`BSS-S3-P3-T020 — Remediation 10`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T020` 已完成 Remediation 10：T019 的 12×16 presentation REJECT / 24 ACCEPT
已进入 Historical/Forward 共用 durable Oracle，限定 Unicode/数字 contextual slots 在 source 上
`216/216 PASS`，两个 rollback mutants 分别产生 145 个 REJECT 与 3 个 ACCEPT failures。
public-safety 的六类明文私有 identifier、五类分隔及两个显式 public-business ancestry boundary
在 T019 42-case × plain/DEFLATED-ZIP=`84/84 PASS`；旧 matcher 漏 5/6 家族，移除 boundary 会恢复
业务 UUID false positive。`S3-R001/R008/R009` 仅为 `FIXED_PENDING_REREVIEW`，T019 仍是最近一次
独立 Stage verdict=`FAIL`；只有 `BSS-S3-P3-T021 — Re-review 10` 可在新双 digest subject 上关闭
finding 并重判 `ACC-S3-002/006` 与 Stage 3 gate。当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T021` 已在 290-file Task Pack / 30-path Stage source 的新双 digest subject 上完成独立
Re-review 10。第十一组 presentation blind set（14 个多语种/数字实体 × 18 个 REJECT 模板及
30 个 ACCEPT controls）在 source/release 两面行为一致，但每面仅 `214/282` binary、
`144/282` strict：67 个负例漏拒、70 个拒绝结果缺完整实体 witness，并有 1 个 role-neutral
正例误拒；双面共 276 个 strict failure rows。public-safety 的 32-case ×
plain/DEFLATED-ZIP=`64` surfaces 仅 `50/64`：`inference/invocation/span/job/task/pipeline`
上下文中的私有 identifier 共 14 个 surface 漏检，全部正例通过。因此 `ACC-S3-002/006` FAIL，
`S3-R001/R008/R009` 回到 `OPEN`。完整许可重审另确认 canonical report/marker 均为 282 targets，
但 README 与 `LICENSE_AND_ATTRIBUTION.md` 各仍声明 280-file payload，故既有 `S3-R010` 重开、
`ACC-S2-010` FAIL。其余 Stage 3 ACC 与 `ACC-S0-005` PASS；未新增 finding ID。按确定性循环追加
T022/T023，唯一下一 Task 是
`BSS-S3-P3-T022 — Remediation 11`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T022` 已只整改上述四项 finding：T021 冻结 presentation set 在 source/release 每面
`282/282` strict，public-safety set 为 `64/64` plain/DEFLATED-ZIP，owner-facing/current
license claims、collector 与 full-history report 统一为 283 targets；相应 rollback mutants 均被杀死。
`S3-R001/R008/R009/R010` 仅推进为 `FIXED_PENDING_REREVIEW`，不由 Builder 关闭。T021 仍是最近一次
独立 verdict=`FAIL`，`ACC-S3-002/006` 与 `ACC-S2-010` 也仍等待独立重判；只有
`BSS-S3-P3-T023 — Re-review 11` 可以关闭 finding、重判 ACC 与决定 Stage 3 gate，当前仍不得进入
Stage 3 Publish。

`BSS-S3-P3-T023` 已在 291-file Task Pack / 32-path Stage source 的新双 digest subject 上完成独立
Re-review 11。presentation fresh set 在 source/release 每面仅 `286/408` binary，360 个 REJECT 的
exact/normalized complete witness 仅 `7/360` / `87/360`，并误拒 8/48 role-neutral controls；
public-safety fresh set 的 108 个 plain/DEFLATED-ZIP surfaces 仅 `84/108`，12 个 ancestry 或
非 UUID opaque identifier/handle case 两面均 fail open。因此 `S3-R001/R008/R009` 保持
`OPEN`、`ACC-S3-002/006` FAIL。stored Forward/current binding 虽 PASS，但 current-tree v23 live
host exact replay exit=`1`，历史 live 证据又绑定不同 production tree，故 `S3-R002` 重开、
`ACC-S3-009=FAIL_EVIDENCE`。283-target owner-facing/collector/report/exact set 与四仓 full-history
复算一致，故 `S3-R010` `CLOSED`、`ACC-S2-010` PASS。其余 Stage 3 ACC 与 `ACC-S0-005` PASS，
未新增 finding ID；Stage 3 verdict=`FAIL`。按确定性循环追加 T024/T025，唯一下一 Task 是
`BSS-S3-P3-T024 — Remediation 12`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T024` 已只整改上述四项 finding。presentation 对 18 个实体 × 31 个句法模板得到
`558/558` exact witness，5 个特殊 legal-name case 与 16 个 role-neutral controls 全 PASS；
public-safety 的 T023 frozen replay 为 `172/172` plain/ZIP，T024 fresh matrix 为 `44/44`。
current binding、stored Forward 与 T023 exact output 的 current presentation/host replay 全 PASS；
fresh live 两次尝试均按 1,800 秒合同 fail-closed timeout，未被冒充为 closure evidence。license
current target/report/markers 为 284，四仓 full-history 重算口径保持 2,489/2,485 与 `0/5/1`。
`S3-R001/R002/R008/R009` 仅推进为 `FIXED_PENDING_REREVIEW`，T023 仍是最近一次独立
verdict=`FAIL`，其 `ACC-S3-002/006` FAIL 与 `ACC-S3-009=FAIL_EVIDENCE` 保持不变。唯一下一
Task 是 `BSS-S3-P3-T025 — Re-review 12`；当前仍不得进入 Stage 3 Publish。

`BSS-S3-P3-T025` 按当前 pursuing goal 的“不进行复审、避免 live time-soak”用户指令改为一次机械
Acceptance closure，不启用独立 reviewer、不修改功能实现，也不把两次 1,800 秒 live timeout 写成
PASS。pre-closure subject 为 292-file Task Pack
`f7b8ceec7cffe3729f4ecf7ed463d3aecf55250a475e25ae1b78cd5d3f7de5cb` 与 33-path
Stage source `e5442f108d2d62b21b57f00c86aec289d1d845a837bfa5800267b34b6f2b8b0c`。
T024 原失败样本、current source、stored independent Forward `23/24`、current binding、
witness deny-default controls、presentation/public-safety durable matrices 与完整自动门共同作为
A级/B级关闭证据；fresh provider observation 被用户显式豁免并保留为非阻塞诊断入口。
`S3-R001/R002/R008/R009` 因此关闭，其余 finding 保持关闭；
`ACC-S3-001`–`ACC-S3-010`、`ACC-S0-005` 与 `ACC-S2-010` 全部 PASS，Stage 3 acceptance
verdict=`PASS`。唯一下一 Task 是 `BSS-S3-P4-T001 — Publish`；本 Task 未执行上传。

`BSS-S3-P4-T001` 按用户“中间 phase 完成不需要上传”的当前指令执行 local-seal Publish：
冻结 accepted pre-publish subject（base `b3ff184bd9a7f0e66a7fde6cd6656f11dd982177`，
33-path Stage digest `b47a38d16377eac197930937300dc269eddbc145aad1a6027140ef369ac92f22`，
292-file Task Pack digest `59f16112fb998134117a89525dc799142e6b37337e321a7f069498e0d2c47b78`），
重建 license/manifest/release/registry/backup DAG，并要求 staged proposed tree 与全新 clean replay
在 release SHA、manifest、registry、public-safety、235 tests 和全部 validator 上一致后才允许本地
seal commit。该 Task 不上传、不生成远端 PR/CI/merge 证据；唯一下一 Task 是
`BSS-S4-P1-T001 — Audit`，最终上传仍由 `BSS-S4-P3-T001` 负责。

## Stage 4 / Final Gate

- [ ] `ACC-S4-001`：全部 REQ/CAP/NG、仓库强制规则和 Task Pack 条目均有 A/B 级证据。
- [ ] `ACC-S4-002`：所有 Stage 复审和整改闭环，ledger 中没有非 `CLOSED` finding。
- [ ] `ACC-S4-003`：最终 release、manifest、registry 和 canonical source 在干净 checkout 可恢复并复验。
- [ ] `ACC-S4-004`：draft PR diff 只包含本项目与必要 registry/发现/CI 变更。
- [ ] `ACC-S4-005`：GitHub CI/required checks 全绿，PR 已合并/关闭。
- [ ] `ACC-S4-006`：canonical 主树为最新 `main` 且干净。
- [ ] `ACC-S4-007`：本任务 worktree、本地/远端 branch、PR 和 worktree metadata 均完成清理。
- [ ] `ACC-S4-008`：运行安全 `git gc`，明确未使用 `--prune=now`。

## Requirement → Acceptance → Task → Test/Evidence 追溯

追溯规则：每个 `ACC-*` 必须且只能出现一行；Source IDs、Producer 与 Verifier 均写完整稳定 ID，禁止范围或
通配符。Producer 是**首次建立该 ACC 完整验收能力与主制品集合**的稳定 Owner，而不是最早创建其中任一
组件的 Task；后续 Task 在未改变验收定义、协议或主制品集合时，只例行刷新派生 hash/manifest，不转移
Producer。只有后续 Task 改变上述任一项并接管该 ACC 时才同步 Producer。Verifier 按列中顺序执行，分号后的条件 Re-review
仅在被启用时接管最终 verdict。Oracle 与 Evidence 必须同时存在；计划文件尚未产生、命令尚未运行或
Evidence 缺失时，该 ACC 只能判未完成。每次 Stage review 必须机械校验：44 个 ACC 集合精确相等、
23 个 REQ/9 个 CAP/7 个 NG 均至少覆盖一次、所有引用 Task ID 均在 Task Graph 中存在。

| Acceptance ID | Source IDs | Producer Task ID | Verifier Task ID(s) | Oracle / Test | Evidence / Artifact |
|---|---|---|---|---|---|
| `ACC-S0-001` | `REQ-005,REQ-018,NG-007` | `BSS-S0-P0-T001` | `BSS-S0-P2-T005`; `BSS-S0-P2-T011`; `BSS-S0-P3-T001` | Pre-publish：main=`main` 且 porcelain 为空，任务分支正确且所有 changed path 都在本项目；post-commit：任务 porcelain 为空 | T005/T011 与 Publish 的 `git branch --show-current`、`git status --porcelain`、`git worktree list --porcelain` 输出 |
| `ACC-S0-002` | `REQ-001,REQ-014` | `BSS-S0-P2-T002` | `BSS-S0-P2-T005`; `BSS-S0-P2-T011` | 文件集合精确等于 compact 5+1、`VERSION`、manifest，逐项 SHA-256 相等 | `task-pack/VERSION`、`task-pack/MANIFEST.sha256`、T005/T011 manifest 校验输出 |
| `ACC-S0-003` | `REQ-002,REQ-003,REQ-007,REQ-012` | `BSS-S0-P1-T001` | `BSS-S0-P2-T005`; `BSS-S0-P2-T011` | 对 00–04/CHANGELOG/VERSION 做身份、版本、source-only、禁止安装/交易的一致性断言 | Task Pack 文件与 T005/T011 一致性检查输出 |
| `ACC-S0-004` | `REQ-001,REQ-014,REQ-016` | `BSS-S0-P1-T001` | `BSS-S0-P2-T005`; `BSS-S0-P2-T011` | Task 定义 ID 唯一、`ACTIVE<=1`、单 Task run、ledger 未闭合时 Publish 不可执行 | `03_STAGE_PHASE_TASKS.md` 与 T005/T011 Task Graph parser 输出 |
| `ACC-S0-005` | `REQ-013,REQ-014` | `BSS-S0-P2-T010` | `BSS-S0-P2-T011` | 本表恰有 44 个唯一 ACC 行；Source 集合覆盖 23/9/7；Producer/Verifier 均引用已定义 Task；每行 Oracle/Evidence 非空且可执行 | 本追溯表、T011 traceability parser 与 Oracle 可执行性审计输出；T009 FAIL 保留为历史 finding 证据 |
| `ACC-S0-006` | `REQ-014` | `BSS-S1-P3-T002` | `BSS-S1-P3-T003`; `BSS-S1-P3-T005`; `BSS-S1-P3-T007`; `BSS-S1-P3-T009` | 五个 Stage 均有 Review/Remediation/Re-review/Publish；失败循环按最大 suffix+1/+2 分配且禁同 run 整改；Stage 0 历史 Task Pack digest 保持，Stage 1 起两个独立实现同时复算 Task Pack 与完整 Git worktree Stage source digest；byte/Git owner-execute mode/delete/untracked 改变结果，group-only execute 映射仍与 Git staged mode 一致，empty/index（包括 intent-to-add）/symlink 非零失败 | `00_RUN_CONTRACT.md` 双 digest 协议、`scripts/digest_stage_source.py`、`test_stage_source_digest.py`、`03_STAGE_PHASE_TASKS.md` 路由与 T003/T005/T007/T009 重审输出 |
| `ACC-S0-007` | `REQ-014` | `BSS-S0-P2-T011` | `BSS-S0-P3-T001` | T011 在新 digest 上复验后 ledger 的状态集合只能为 `CLOSED`，Publish 再检查零未关闭 finding | `CHANGELOG.md` ledger、T011 verdict 与 Publish 前置检查输出 |
| `ACC-S1-001` | `REQ-003,REQ-010` | `BSS-S1-P1-T002` | `BSS-S1-P2-T001` | fixture 证明 `semver`、无前导零 `numeric-quad` 通过，未知 scheme 非零失败 | `REGISTRY.json`、`scripts/validate_registry.py`、registry fixture test 输出 |
| `ACC-S1-002` | `REQ-010,REQ-013` | `BSS-S1-P1-T002` | `BSS-S1-P2-T001` | 现有条目的路径、`3.0.0`、archive 与 SHA 在修改前后逐字段相等 | 锁定的 registry before/after fixture 与回归输出 |
| `ACC-S1-003` | `REQ-003,REQ-010` | `BSS-S1-P1-T002` | `BSS-S1-P2-T001` | 空数组首版 fixture 通过；缺字段、非数组、错误 major/scheme fixture 均失败 | registry fixture 集与 unittest 输出 |
| `ACC-S1-004` | `REQ-013` | `BSS-S1-P3-T002` | `BSS-S1-P3-T003` | 隔离测试覆盖声明的成功/失败分支，包括 archive list 中非 object 项；registry validator 返回 0 与 `PASS`，删除对应拒绝逻辑的 mutant 必须被杀死 | `Stock_Skill/tests/test_validate_registry.py`、validator stdout、mutation 输出与 Stage 1 re-review 记录 |
| `ACC-S1-005` | `REQ-017` | `BSS-S1-P2-T002` | `BSS-S1-P3-T001`; `BSS-S1-P3-T003` | 根与 Stock Skill 文档中的 scheme、当前版本、fail-closed 术语逐项一致 | 根/`Stock_Skill` 的 README、AGENTS 及文档一致性 diff |
| `ACC-S1-006` | `REQ-013,REQ-016,REQ-022` | `BSS-S1-P3-T002` | `BSS-S1-P3-T003`; `BSS-S1-P3-T005`; `BSS-S1-P3-T007`; `BSS-S1-P3-T009`; `BSS-S1-P4-T001` | workflow 语法与原始 run blocks 通过；测试门按实际 case 数拒绝 zero-case suite；安全门拒绝普通文件/ZIP 内 `github_pat_`、当前 `ghs_APPID_JWT`、case/Unicode 变体及无尾分隔符 user-home、反斜杠/drive ZIP path 与非空目录 payload；历史路径只允许精确反引号 token，closing backtick 后 continuation 不得获得豁免；push 后真实 PR check 覆盖 registry/tests/manifest/security | workflow、`scripts/run_unittests.py`、`scripts/validate_public_safety.py`、durable CI tests、T003/T005/T007/T009 本地日志与 GitHub check URL/结论 |
| `ACC-S2-001` | `REQ-002,REQ-008` | `BSS-S2-P1-T001` | `BSS-S2-P3-T001` | 目录 basename 与 YAML frontmatter `name` 精确等于稳定 ID | canonical `SKILL.md` 与结构 validator 输出 |
| `ACC-S2-002` | `REQ-002,REQ-008` | `BSS-S2-P2-T001` | `BSS-S2-P3-T001` | metadata 文件存在，display name 精确相等，default prompt 含精确 `$bottleneck-serenity-skill` | canonical `agents/openai.yaml` 与 skill-creator validator 输出 |
| `ACC-S2-003` | `REQ-003` | `BSS-S2-P2-T002` | `BSS-S2-P3-T001` | 项目和 Task Pack `VERSION` 均逐字等于 `0.0.0.1` | 两个 `VERSION` 文件与版本断言输出 |
| `ACC-S2-004` | `REQ-002` | `BSS-S2-P1-T003` | `BSS-S2-P3-T001` | canonical source 与 current release 解包树中旧身份 token 命中数均为零 | old-identity scan 命令、文件清单与输出 |
| `ACC-S2-005` | `REQ-005,REQ-008` | `BSS-S2-P1-T002` | `BSS-S2-P4-T001`; `BSS-S2-P4-T003`; `BSS-S2-P4-T005` | 53 个 ZIP entry 各有且仅有一个 import/migrate/exclude 决定，集合与归档清单精确相等 | `SOURCE_INVENTORY.md`、ZIP listing 与集合差异输出 |
| `ACC-S2-006` | `REQ-021` | `BSS-S2-P2-T004` | `BSS-S2-P3-T001`; `BSS-S2-P5-T001` | 候选与 frozen Publish subject 均连续 clean build 两次且 ZIP SHA 相等；entry root/order/time/mode/type/duplicate 及 file set=task manifest entries+manifest 自身全通过 | 候选/sealed release、四次 SHA-256、ZIP verifier 与 Publish replay 输出 |
| `ACC-S2-007` | `REQ-010,REQ-021` | `BSS-S2-P2-T004` | `BSS-S2-P3-T001`; `BSS-S2-P5-T001` | DAG 精确为 task files→task manifest→release→release SHA→sums/registry，outer project→backup manifest；release SHA 与 sums/registry/backup release entry 相等，task manifest 无 Root 外 entry | release、`SHA256SUMS`、`REGISTRY.json`、两个 manifest、DAG cycle check 与 hash 输出 |
| `ACC-S2-008` | `REQ-003,REQ-010,REQ-016` | `BSS-S2-P2-T004` | `BSS-S2-P3-T001`; `BSS-S2-P5-T001` | T003 fixture 先验证全部 entry 字段但不激活；T004/Publish 仅在真实 release SHA 存在后原子写入，registry validator 同时验证两个项目，新条目 archive 数组为空且无占位/虚构文件 | registry fixture、`REGISTRY.json`、filesystem/hash 检查、validator 与 Publish replay 输出 |
| `ACC-S2-009` | `REQ-007,REQ-009,REQ-012,NG-001,NG-002,NG-004` | `BSS-S2-P2-T002` | `BSS-S2-P3-T001` | 用户级 Skill 目录无写入；静态/动态测试无 broker/order/network side effect；无 daemon/scheduler | Git/filesystem before-after、capability scan 与相关测试输出 |
| `ACC-S2-010` | `REQ-020` | `BSS-S2-P4-T002` | `BSS-S2-P4-T001`; `BSS-S2-P4-T003`; `BSS-S2-P4-T005` | proprietary 边界与每个来源/复制/再分发决定齐全；审计器验证完整 clone/origin/commit/license history，覆盖 current exact target 集（计数必须等于 `LICENSE_SIMILARITY_AUDIT.summary.target_file_count`）与全部可达 blob；eligibility/normalization/pair count/report 任一漂移非零，未知许可即失败 | `LICENSE_AND_ATTRIBUTION.md`、`SOURCE_INVENTORY.md`、`scripts/audit_license_similarity.py`、`LICENSE_SIMILARITY_AUDIT.json`、仓级 fixture/mutation/full-history byte-identical 重算输出与 review 结论 |
| `ACC-S2-011` | `REQ-018,REQ-021` | `BSS-S2-P2-T004` | `BSS-S2-P3-T001`; `BSS-S2-P5-T001` | 从 staged/proposed tree 与新建干净 sparse checkout 按文档重建，均得到 sealed release SHA 并运行 registry/测试全门 | `RESTORE_AND_VERIFY.md`、两类临时 checkout transcript 与 SHA 对比 |
| `ACC-S2-012` | `REQ-023` | `BSS-S2-P1-T004` | `BSS-S2-P4-T001`; `BSS-S2-P4-T003`; `BSS-S2-P4-T005` | 源/迁移后核心逻辑语义 diff 为零；若非零，必须存在影响、版本分析和用户决定，否则停止 | semantic parity diff、影响分析和必要时的用户决定证据 |
| `ACC-S2-013` | `REQ-004,REQ-017,REQ-019,NG-002` | `BSS-S2-P4-T004` | `BSS-S2-P4-T001`; `BSS-S2-P4-T003`; `BSS-S2-P4-T005` | README/Task Pack/canonical input+completion projection 精确相等；五字段 runtime artifact envelope 在 schema/template/example/scaffold/script output 一致，missing/rename/version/cutoff mutant fail closed；默认值、Owner 与适配器边界和 01/02 一致 | 项目 README/AGENTS、canonical integration/output contract、三 schema、templates/examples/scripts、cross-doc 与 canonical durable tests、review checklist |
| `ACC-S3-001` | `REQ-013` | `BSS-S3-P1-T001` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | skill-creator、项目 validator 与全部 unittest 均返回 0 | 完整命令、stdout/stderr、测试数与退出码 |
| `ACC-S3-002` | `REQ-008,REQ-013,CAP-009` | `BSS-S3-P1-T001` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 每个 JSON 可解析；schema 对模板、示例和真实脚本输出均验证通过 | JSON 清单、schema validator 与逐文件结果 |
| `ACC-S3-003` | `REQ-013,NG-005` | `BSS-S3-P1-T002` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 预注册正触发/鲁棒 case 逐例符合 rubric，输出不声称保证 Alpha | eval case、预期、原始输出与评分结果 |
| `ACC-S3-004` | `REQ-009,NG-002` | `BSS-S3-P1-T002` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 查价、普通摘要、概念解释三个负控制均不启动完整工作流 | negative cases、原始响应与逐例 verdict |
| `ACC-S3-005` | `REQ-012,NG-004` | `BSS-S3-P1-T003` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 下单/撤单/登录请求被拒绝或明确不执行，broker/order side-effect 计数为零 | adversarial prompts、响应、capability/filesystem/network 观察结果 |
| `ACC-S3-006` | `REQ-006,REQ-007,REQ-011,REQ-015,NG-001,NG-003,NG-006` | `BSS-S3-P1-T003` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | tracked/release 扫描无 secret、本机路径、账户/组合/MNPI、未声明二进制或治理复制 | public-safety scan 命令、命中清单和零高风险结论 |
| `ACC-S3-007` | `REQ-006,REQ-011` | `BSS-S3-P2-T001` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | claim ledger 每条事实的发布日期均 `<= source_cutoff`，缺日期/来源即失败 | 历史案例 claim ledger、source metadata 与 cutoff validator 输出 |
| `ACC-S3-008` | `REQ-008,CAP-001,CAP-002,CAP-003,CAP-004,CAP-005,CAP-006,CAP-007,CAP-008,CAP-009` | `BSS-S3-P2-T001` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 历史 E2E schema/rubric 必含系统图、租金桥、三个时钟、估值、反例、kill switch、相关性及机器层 | 历史案例输入、memo、decision、evidence 与 rubric 结果 |
| `ACC-S3-009` | `REQ-013` | `BSS-S3-P2-T002` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 独立执行上下文不含预期答案/诊断，原始输出仍逐项满足预注册 rubric | 最小 prompt、上下文清单、原始 output/trace 与评分 |
| `ACC-S3-010` | `CAP-001,CAP-002,CAP-003,CAP-004,CAP-005,CAP-006,CAP-007,CAP-008,CAP-009` | `BSS-S3-P1-T002` | `BSS-S3-P3-T001`; `BSS-S3-P3-T003`; `BSS-S3-P3-T005`; `BSS-S3-P3-T007`; `BSS-S3-P3-T009`; `BSS-S3-P3-T011`; `BSS-S3-P3-T013`; `BSS-S3-P3-T015`; `BSS-S3-P3-T017`; `BSS-S3-P3-T019`; `BSS-S3-P3-T021`; `BSS-S3-P3-T023`; `BSS-S3-P3-T025` | 每个 CAP 至少一项 positive 和一项 negative Oracle，18 个 Oracle 全部有 verdict | capability-to-case matrix、原始输出与逐 Oracle 结果 |
| `ACC-S4-001` | `REQ-001,REQ-002,REQ-003,REQ-004,REQ-005,REQ-006,REQ-007,REQ-008,REQ-009,REQ-010,REQ-011,REQ-012,REQ-013,REQ-014,REQ-015,REQ-016,REQ-017,REQ-018,REQ-019,REQ-020,REQ-021,REQ-022,REQ-023,CAP-001,CAP-002,CAP-003,CAP-004,CAP-005,CAP-006,CAP-007,CAP-008,CAP-009,NG-001,NG-002,NG-003,NG-004,NG-005,NG-006,NG-007` | `BSS-S4-P1-T001` | `BSS-S4-P2-T001`; `BSS-S4-P2-T003`（若启用） | completion audit 对 39 个 Source ID 与 44 个 ACC 逐项要求 A/B 证据；集合缺项、C/MISSING 即失败 | completion audit matrix、证据链接/哈希与 final review 结论 |
| `ACC-S4-002` | `REQ-014` | `BSS-S4-P2-T001` | `BSS-S4-P3-T001` | 所有 Stage review 已 PASS，所有 ledger 状态集合精确为 `CLOSED` | 各 Stage digest/verdict、ledger parser 与 Publish 前置检查 |
| `ACC-S4-003` | `REQ-010,REQ-018,REQ-021` | `BSS-S4-P1-T002` | `BSS-S4-P2-T001`; `BSS-S4-P2-T003`（若启用）; `BSS-S4-P3-T001` | Review 验证候选；Publish 从 frozen source 重建最终 release/hash DAG，staged tree 与最终 clean checkout 的 release、manifest、registry、canonical source hash 全相等且全门通过 | candidate review、Publish staged-tree/clean-restore transcript、最终 hashes 与测试日志 |
| `ACC-S4-004` | `REQ-005,NG-006,NG-007` | `BSS-S4-P1-T001` | `BSS-S4-P2-T001`; `BSS-S4-P2-T003`（若启用） | `origin/main...HEAD` changed paths 集合仅含本项目与已列出的 registry/discovery/CI 文件 | PR diff、path allowlist 与逐文件解释 |
| `ACC-S4-005` | `REQ-001,REQ-013,REQ-016` | `BSS-S4-P3-T001` | `BSS-S4-P3-T001` | PR required checks 全绿，GitHub 显示 merged/closed，远端 main 包含 merge commit | PR URL、checks、merge commit 与远端 API/gh 输出 |
| `ACC-S4-006` | `REQ-016,REQ-018` | `BSS-S4-P3-T001` | `BSS-S4-P3-T002` | canonical 主树 fast-forward 到远端最新 main，branch=`main`、porcelain 为空 | main fetch/pull、rev-parse、branch/status 输出 |
| `ACC-S4-007` | `REQ-005,REQ-018,NG-007` | `BSS-S4-P3-T002` | `BSS-S4-P3-T002` | 任务 worktree 不在 list，本地/远端任务 branch 不存在，PR closed，metadata 已 prune | worktree/branch/ls-remote/PR/prune 输出 |
| `ACC-S4-008` | `REQ-018` | `BSS-S4-P3-T002` | `BSS-S4-P3-T002` | 安全 `git gc` 返回 0，实际命令参数不含 `--prune=now` | 执行命令、退出码与 cleanup 记录 |

## 计划验证命令

以下命令在对应文件出现后执行；不得把“文件尚不存在”误报为通过。

```bash
python3 Stock_Skill/scripts/validate_registry.py
python3 -m unittest discover -s Stock_Skill/tests -v
python3 Stock_Skill/bottleneck-serenity-skill/task-pack/skill_draft/bottleneck-serenity-skill/scripts/validate_skill.py \
  Stock_Skill/bottleneck-serenity-skill/task-pack/skill_draft/bottleneck-serenity-skill
python3 -m unittest discover \
  -s Stock_Skill/bottleneck-serenity-skill/task-pack/skill_draft/bottleneck-serenity-skill/tests -v
```

还必须执行：

- skill-creator `quick_validate.py`；
- 全部 JSON 解析和 schema/example 一致性检查；
- trigger/negative/robust eval；
- current release `unzip -t`、内容清单和 SHA-256 重算；
- backup/task manifest 完整性检查；
- 专用 Stock Skill workflow 的本地等价命令和 GitHub check；
- old-identity、secret、绝对路径、broker/order/network capability 扫描；
- 历史 E2E 的 source-date cutoff 校验；
- 干净 checkout 恢复演练；
- Git diff、PR、CI 和最终清理检查。

## 通用停止条件

立即停止当前 Task 并报告，不跨 Task 修补：

- 工作目录、branch、Task ID 或允许修改文件与 Run Contract 不一致；
- 发现无关脏改动或可能覆盖其他线程的 worktree/branch；
- 身份、版本格式、source-only 边界或验收口径出现冲突；
- 需要付费服务、外部写入、凭据、账户或生产系统权限；
- 关键源文件缺失、哈希变化、许可/归属不清；
- 验证不能覆盖声明，或只能依赖历史报告/推断；
- Stage review 尚未 PASS、ledger 仍有非 `CLOSED` finding，却准备 commit/push。

## 回滚原则

- 未提交 Task：只撤销该 Task 明确列出的文件；保留用户和其他线程变更。
- 已上传 Stage：使用普通 revert PR/commit，不做破坏性 reset。
- release/manifest：一起回滚，禁止留下 registry 指向不存在或哈希不符的制品。
- Git 清理：只清理由本任务创建/接管的资源；`git gc` 不加 `--prune=now`。
