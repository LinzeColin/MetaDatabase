# PFI v0.2.5 Production Truth & Human Workflow Completion

中文名：**PFI v0.2.5 真实财务智能与人类工作流完成版**  
版本：`v0.2.5`  
生成日期：`2026-07-10`（Australia/Sydney）  
对象：`LinzeColin/CodexProject/PFI`

## 1. 任务总目标

把 PFI 从“文档和合同看起来完成，但真实入口、真实数据、真实分析和真实工作流仍未充分贯通”的状态，推进为一个可长期使用的个人财务管理与分析系统。

最终用户应能够：

- 从 Finder App 或 localhost 打开同一最新亮色 UI；
- 看清真实净资产、现金、投资、消费和数据缺口，不被假零误导；
- 使用 10 个固定一级入口和差异化二级页面完成真实任务；
- 上传真实数据、解析、复核、入账、编辑持仓并在 SQLite 长期保存；
- 查看公式、参数、Interconnection、分析结论、敏感性和报告；
- 知道每个结论基于哪些数据、时间、公式和版本；
- 在失败、过期、断网、重启和恢复时获得人类可读反馈。

## 2. 当前 GitHub 审计结论

状态：`BLOCKED_FOR_V025_PRODUCTION_ACCEPTANCE`。

### 2.1 已经存在但只算部分基础

- `PFI/` 是当前产品根；README 声称 v0.2.4 Stage 0–9 和 overall review 已完成。
- 正式页面顶部已有 10 个入口，含“市场与研究”。
- v0.2.4 已定义 no-false-zero 状态机、报告类型、亮色设计 marker 和若干 Evidence。
- `MetaDatabase/PFI` 被记录为 ready，含 8815 条记录、4 个原始文件、截至 2026-06-03。

### 2.2 阻止验收的事实

1. README 明确写明 `App bundle reinstall: not executed`、`Data logic changes: none`、`Financial data changes: none`。
2. 同一 README 明确写明净资产、现金和投资仍为 `source_missing`，等待真实账户/持仓 Read Model。
3. `web/index.html` 仍混合 `PFI v0.2.3 Repair` 与 v0.2.4 identity，并显示硬编码感的旧 FX 文案。
4. 首页核心指标仍是“暂无真实数据”，页面仍保留“PFI 处理入口、任务已准备、页面说明、依据、参数、记录链路”等机械化壳层。
5. 页面源码/辅助区仍出现 10 个正式入口加 6 个旧标签的 16 项堆叠，必须检查 rendered DOM、accessibility tree 和 no-JS fallback。
6. README/HANDOFF 宣称 v0.2.4 overall pass，而 `开发记录.md` 当前元数据仍写 `v0.2.2 数据库治理 Stage 4 / CF-L2 / 100%`，状态真相分裂。
7. `web/cloudflare-public` 已存在，但它是脱敏 public surface，不能成为第二活动 UI或证明本地私有产品已完成。
8. Web 无法证明当前 `shell.js`、SQLite、App bundle、真实持仓持久化和目标 Mac 生命周期；必须在本机真实运行。

完整证据见 `docs/CURRENT_GITHUB_AUDIT_2026-07-10.md`。

## 3. 最新不可变产品合同

### 3.1 产品与系统边界

- 主体只有 PFI。
- Alpha 独立，只读读取版本化 PFI Context；不是 PFI 一级入口。
- 不存在 Ralpha。
- Serenity-Alipay 完全排除。
- `系统与开发` 不是一级入口。
- PFI OS 历史线程只提供架构/可靠性参考；不得把 `PFI_OS/` 变为第二产品根。
- Cloudflare public shell 必须隔离，不能读取 PRIVATE_USER/PRIVATE_DERIVED，不能作为本地 App 的替代。

### 3.2 正式一级入口

正好 10 个：

1. 首页总览
2. 账户与资产
3. 账本流水
4. 投资管理
5. 消费管理
6. 数据源与上传
7. 建议与复盘
8. 报告与洞察
9. 市场与研究
10. 设置

旧 `首页、市场、研究、持仓、策略实验室、数据与系统` 只能是 alias/二级 route。策略实验室唯一 canonical route 是 `/market-research/strategy-lab`。

### 3.3 人类产品体验

- 体验工作占 v0.2.5 约 50–60%。
- 默认明亮、高级、克制；暗色仅可选。
- 一级/二级入口都必须像真实页面：URL、title、breadcrumb、主内容、主操作、状态、前进/后退和刷新都正确。
- 组件可复用，页面不能模板克隆。
- 不显示 AI 正在思考、Task Pack、运行边界、反馈控制台、手机样机、开发解释卡。
- 动效与触感服务真实状态；不支持时静默降级；设置页可关闭。

### 3.4 真实数据与禁止假数据

- 产品验收只使用真实数据的只读副本/隔离快照；真实数据不要求固定三年，但必须记录实际 coverage。
- 禁止 mock/sample/demo/synthetic/fixture/fake 财务数据参与财务功能、图表、压力或 E2E 验收。
- 若真实输入不可用，测试状态是 `blocked/not_run`，不能 pass 或 fallback。
- Evidence 只能保存 hash、计数、日期范围、脱敏 ID，不提交私密值。

### 3.5 CNY、FX 与双消费口径

- 全局主币种 CNY。
- `AUD/CNY=4.81` 只说明语义：1 AUD = 4.81 CNY；生产值必须来自有效 FX snapshot，不能硬编码 4.81。
- Australia/Sydney 每日 06:00 读取一次；06:00 前/周末/NSW 假日使用上一有效发布日；普通运行不联网。
- 主 UI、消费页和报告必须显示：
  - `消费总流出金额（用户定义活动口径）`
  - `生活消费金额`
  - `投资资金流出/配置金额`
- 投资入金、基金申购、黄金申购、投资买入进入用户定义的消费总流出，但不进入生活消费；报告必须说明该口径不等于净资产损失。
- Source record 去重、Economic Event lineage 和公式规则共同防止无意重复。

### 3.6 v0.2.2 需要保留的业务规则

- source/account 角色不写死，允许多角色和生效期。
- 分类：L1 ≤ 12、每个 L1 的 L2 ≤ 5、总 L2 ≤ 50；每笔交易一个主分类。
- 标签：默认/自定义、增删改停用、历史、持久化、视图筛选。
- 记录分类置信度：字段完整度 30、金额方向 10、规则命中 20、商户/对手方 15、Interconnection 15、历史一致性 10，统一阈值 70。
- 现金流窗口：7/21/30/60/90/180/360。
- 参数中心和 Interconnection Map 必须是正式主 UI 二级页面。

## 4. 关键架构决定

### 4.1 单一真相与数据层

建议目标：

```text
Immutable Raw Store
→ Parse / Normalize / Entity Resolution
→ Interconnection Group / Economic Event
→ Unified Ledger
→ Operational SQLite + optional DuckDB/Parquet analytics
→ Versioned Read Models
→ API / Formal UI / Reports / PFI Context Export
```

UI 不得直接读取 provider、原始 JSON、旧 bridge 或旁路 HTML。

### 4.2 时间真相

每条记录/指标应按适用范围保留：

```text
transaction_time
posted_at
effective_at
imported_at
reconciled_at
valued_at
fx_effective_at
report_as_of
```

这使系统能区分“真实为零、未加载、过期、尚未估值、过滤为空、对账失败”。

### 4.3 Metric State

非 `ready/confirmed_zero` 状态不得显示财务 0。`confirmed_zero` 必须有 source、record_count、coverage、as_of、formula、read_model_hash、confidence/coverage 证据。

可信度拆成：记录分类、来源覆盖、对账覆盖、估值覆盖、模型验证和报告完整度，不能只给一个总分。

### 4.4 发布身份

必须同时验证：

1. macOS `CFBundleShortVersionString/CFBundleVersion`
2. launcher URL/query
3. backend release manifest
4. frontend embedded manifest + asset hash

四方不一致时必须 fail-visible。只写 README 或换 query 参数不算重装。

### 4.5 Evidence

每个 Phase：

```text
evidence.json
terminal.log
changed_files.txt
risk_and_rollback.md
```

涉及 UI：截图、DOM/a11y tree、Playwright trace。  
涉及数据库：before/after、migration、integrity/foreign-key check。  
涉及 App：plist、bundle hash、Finder launch。  
涉及财务：source/data/formula/parameter/read-model/report hash 和脱敏 coverage。

## 5. Codex 执行协议

### 5.1 每次开始前

```bash
git status --short
git branch --show-current
git rev-parse HEAD
git rev-parse origin/main
git log -5 --oneline
```

输出：当前状态、读取文件、修改文件、明确不修改范围、命令、迁移、风险、回滚。

### 5.2 每次最大范围

- 最多一个 Phase。
- 不能自动进入下一个 Phase。
- Stage 完成后必须经过用户验收。
- 发现需要越界修改：停止，说明原因和建议路径。

### 5.3 完成声明

允许：`Phase X.Y candidate pass，等待用户验收/下一阶段指令`。  
禁止：`整体完成、全部通过、用户已验收、closeout 完成`，除非 human_acceptance.json 绑定当前 release/evidence 并获用户明确接受。

## 6. Roadmap

正式 Roadmap 见 `ROADMAP_COPY.md`，共 13 个 Stage（0–12），每个 Stage ≤3 个 Phase，每个 Phase ≤4 个 Task，满足用户给出的结构和上限。

## 7. 最低修复 Gate

详见 `checklists/MINIMUM_REPAIR_GATES.md`。任何 Gate 未通过，v0.2.5 都不得声明完成。

## 8. 包内容

- `00_READ_FIRST.md`
- `TASK_PACK.md`
- `ROADMAP_COPY.md`
- `docs/`：审计、需求、历史、架构、数据、公式、报告、可靠性、研究、风险、Surprise
- `prompts/`：Pre Stage 0、Stage 0、单 Phase 执行模板
- `schemas/`：需求、发布、来源、时间、指标、lineage、公式、报告、Evidence、验收
- `checklists/`：最低 Gate、产品 UAT、数据真相、入口发布、Stage closeout
- `html/`：已获方向认可的 v0.2.3 亮色体验 HTML，仅参考
- `reference/`：历史材料使用说明
