# PFI v0.2.5 真实财务智能与人类工作流完成版 — 先读这里

## 结论

当前 GitHub `main` **不满足 v0.2.5 生产验收**。现有 v0.2.4 文档和 Evidence 证明了若干合同、UI 状态和测试门禁，但仓库自己同时写明：App bundle 没有真实重装、数据逻辑没有变化、财务数据没有变化；真实来源只有部分交易数据可用，净资产、现金和投资仍缺账户/持仓 Read Model。

v0.2.5 的任务不是继续堆功能，而是完成 **真实发布入口、真实数据挂链、财务真相、差异化人类工作流、报告可验证性和本地可靠性**。

## 执行顺序

1. 先执行 `prompts/PRE_STAGE0_READ_ONLY_REBASELINE.md`，只读，不改代码。
2. 用户接受只读基线后，才执行 `prompts/STAGE0_ONLY_CODEX_PROMPT.md`。
3. 后续每次只执行 Roadmap 中一个 Phase。
4. 每个 Stage 完成后停下，等待用户验收。

## 禁止

- 不得直接执行完整 Roadmap。
- 不得继承 8/9/6 入口历史约束；当前唯一合同是 10 个一级入口。
- 不得把旧 HTML、Task Pack HTML、旁路 review page 当正式产品。
- 不得用 mock/sample/demo/synthetic/fixture/fake 财务数据验收。
- 不得用 README、关键词测试、toast、截图路径或用户回复单个数字冒充完成。
- 不得启用第二套活动 UI、第二产品根或把 Cloudflare public shell 当本地私有产品。
