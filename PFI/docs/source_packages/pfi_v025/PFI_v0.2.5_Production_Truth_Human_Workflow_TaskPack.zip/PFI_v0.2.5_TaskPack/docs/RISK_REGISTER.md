# v0.2.5 Risk Register

| ID | 风险 | 级别 | Gate |
|---|---|---:|---|
| R-01 | Finder 打开旧 App/旧缓存 | P0 | Stage 1 |
| R-02 | 有交易无余额/持仓却显示 0 | P0 | Stage 2–4 |
| R-03 | 双消费口径被解释为净资产损失 | P0 | Stage 5 |
| R-04 | 10 入口视觉通过但 a11y/fallback 仍 16 | P0 | Stage 6 |
| R-05 | toast/localStorage 冒充保存 | P0 | Stage 7 |
| R-06 | 页面模板克隆、机械壳未消失 | P0 | Stage 6–8 |
| R-07 | 报告无公式/样本/来源 | P0 | Stage 9 |
| R-08 | 假任务/假进度 | P1 | Stage 10 |
| R-09 | SQLite WAL 版本风险 | P0 | Stage 11 |
| R-10 | backup 不是一致快照/restore 不原子 | P0 | Stage 11 |
| R-11 | public shell 成为第二活动 UI | P1 | Stage 11 |
| R-12 | README/HANDOFF/开发记录状态分裂 | P0 | Stage 0/12 |
| R-13 | 私密值进入 Git/Evidence | P0 | 全程 |
| R-14 | 用户模糊回复被套成验收 | P0 | Stage 12 |
| R-15 | v0.2.5 途中扩展 LLM/高级模型 | P1 | Scope Gate |
