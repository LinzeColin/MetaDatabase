# Surprise：容易被忽略但会决定 v0.2.5 成败的发现

## 1. 8815 条数据不等于净资产可计算

交易流水能做消费分析，却不能自动给出当前余额、持仓、负债和净资产。必须补 opening/closing balance、账户 snapshot、持仓、价格、FX 与对账。

## 2. 旧 UI 是四层发布身份问题，不是“再复制一次 App”

App plist、launcher URL、backend manifest、frontend bundle 必须握手；Service Worker、HTTP cache、bfcache 和 Streamlit cache 都可能保留旧状态。仅 `no-cache` 也不能保证历史导航重验证。

## 3. 当前状态有三套真相

README/HANDOFF 的 v0.2.4 pass、开发记录的 v0.2.2 CF-L2、index 的 v0.2.3 Repair/v0.2.4 marker 同时存在。需要机器 release manifest，README 不再充当 Stage 日志数据库。

## 4. 一个置信度分数会误导

分类准确不代表来源完整；来源完整不代表对账完成；持仓存在不代表估值新鲜；公式能跑不代表模型有效。必须拆分六类可信度/coverage。

## 5. 用户双消费口径有 gross activity 风险

投资入金和投资买入都进入总流出时，同一资本链可能出现多个活动事件。必须展示组件、经济边界和 lineage，不能把总流出解释成损失或生活消费。

## 6. “什么时候”与“多少钱”同等重要

缺少 transaction/posted/effective/imported/reconciled/valued/fx/report 时间，系统无法判断 0、过期、未估值和过滤空。

## 7. 视觉 10 入口不等于真正 10 入口

隐藏 fallback、accessibility tree、footer 或 source 可能仍暴露 16 个入口。必须测 rendered DOM、a11y tree 和 no-JS。

## 8. Public Cloudflare shell 不能是第二活动产品

它的安全目标与私有本地 PFI 相反。应隔离，不得用其 PASS 证明本地账户/持仓/报告已完成。

## 9. 用户回复“1”不能单独构成通用验收

验收必须绑定 version、build、commit、evidence hash、时间、缺陷和范围，防止其他线程的数字回复被错误套用。

## 10. 不用假数据仍然可以自动测试

财务 E2E、压力和极限测试使用真实数据只读副本/快照；无数据就 blocked。纯 schema 测试可用非财务 sentinel，但不能计入财务验收。

## 11. SQLite 版本本身是生产 Gate

2026 年披露的 WAL-reset bug 影响很长版本区间。只写“启用 WAL”不够，必须记录 runtime SQLite version 并 Gate。

## 12. 4.81 是语义示例，不是永远的汇率

当前官方数据会变化；生产必须展示 snapshot rate/source/as-of/hash。硬编码 4.69 或 4.81 都不符合要求。
