# 运行可靠性、SQLite 与备份恢复

## SQLite

- 记录 Python sqlite3 与 SQLite runtime version。
- 若使用 WAL 并有并发，必须避开 SQLite 3.7.0–3.51.2 的 WAL-reset 风险，使用 3.51.3+ 或官方安全 backport 3.44.6/3.50.7。
- foreign_keys=ON、busy_timeout、显式 transaction/rollback、migration version。
- integrity_check 不检查 foreign key；必须另跑 foreign_key_check。

## Backup/Restore

- 在线 DB 使用 Online Backup API 或 VACUUM INTO 生成一致快照。
- restore 先到隔离副本，运行 integrity、foreign-key、应用不变量、schema/migration 检查。
- 验证后原子替换，失败回滚。

## Durable Jobs

支持 claim/lease/heartbeat/revision/retry/cancel/dead-letter/recovery；UI 进度来自真实任务事件。

## 可观测性

每个 import/reconcile/recompute/report job 传播 trace_id/span_id，日志脱敏并记录 source/data/formula/parameter/read-model hash。
