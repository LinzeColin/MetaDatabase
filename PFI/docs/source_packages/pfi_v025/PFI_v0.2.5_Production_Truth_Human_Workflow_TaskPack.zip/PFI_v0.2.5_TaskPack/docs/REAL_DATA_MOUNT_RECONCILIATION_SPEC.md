# 真实数据挂链、对账与 Metric State

## 挂链状态

`ready / confirmed_zero / partial_coverage / not_loaded / source_missing / path_error / parse_failed / outdated_snapshot / permission_denied / calculation_failed / reconciliation_failed / valuation_missing / filtered_empty`

## Metric 必填证据

- metric_id/value/currency/status
- source_ids/record_count/coverage_start/coverage_end
- data_as_of/valued_at/fx_snapshot_id
- formula_id/version/hash
- parameter_hash/data_hash/read_model_hash
- classification_confidence
- source_coverage/reconciliation_coverage/valuation_coverage/model_validation/report_completeness
- blocking_reason_zh/calculation_state

## 零值规则

只有 `confirmed_zero` 且来源、时间、记录数、公式、coverage 与 hash 完整时显示 CNY 0.00。其他状态显示中文状态和修复入口。

## 对账不变量

- assets - liabilities = net worth
- opening cash + confirmed flows + adjustments = closing cash
- own-account transfer does not change net worth
- investment purchase changes composition, not net worth except fees/taxes
- linked refund reverses linked living consumption
- same economic event counted once per metric according to formula policy
- all pages/reports for same snapshot share read_model_hash
