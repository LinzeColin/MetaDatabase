# 历史约束去影响与参考政策

## 已废弃，不得驱动 v0.2.5

- 8 个、9 个或 6 个一级入口合同。
- “市场与研究不得作为一级入口”。
- 把旧首页/市场/研究/持仓/策略实验室/数据与系统并列为一级入口。
- 旧暗色 AI Dashboard、Task Pack HTML、长页锚点、手机样机。
- “v0.2.1.1 / v0.2.2 / v0.2.3 / v0.2.4 已完成”文字本身。
- PFI_OS 作为当前产品根或六工作区导航。
- 旁路 review HTML 作为正式主 UI。
- 旧 demo/sample/fixture 作为财务验收基线。

## 仅作失败证据

- 旧 HTML 原型及截图。
- 曾经的 shell.js/测试损坏记录。
- README/HANDOFF 的历史 Stage 日志和 closeout 文案。

## 可保留的参考原则

- 一个活动用户界面、一个启动入口、单一真相源。
- 真实点击、路由、API、SQLite、刷新/重启和 DB Evidence。
- Immutable raw、统一账本、read model、provenance、时间点。
- Durable job、retry、quarantine、backup/restore、doctor/status。
- LLM 失败不影响确定性核心；不自动交易。
- Fast/Deep Path 可作为未来性能架构参考，不是 v0.2.5 新功能目标。

## 已批准但不照搬的 HTML

`html/pfi_v023_phase1_human_product_experience_preview.html` 仅代表亮色、正常软件感、真实数据门禁和交互方向。禁止直接复制成生产页；必须基于当前代码和真实数据重新实现得更好。
