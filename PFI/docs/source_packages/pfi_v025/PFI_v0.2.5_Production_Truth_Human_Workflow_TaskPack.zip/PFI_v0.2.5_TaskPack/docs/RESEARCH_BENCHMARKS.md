# 外部研究与实现基准（官方/一手来源）

本清单用于解释 v0.2.5 的设计决策。Codex 在实现前应核对当前版本，但不得因为研究而扩大范围。

| 主题 | 官方来源 | 对 PFI 的要求 |
|---|---|---|
| WCAG 2.2 | https://www.w3.org/TR/WCAG22/ | 以 AA 为 Gate；金融/数据错误预防、焦点、target size、status messages |
| History API | https://developer.mozilla.org/en-US/docs/Web/API/History_API/Working_with_the_History_API | pushState/replaceState/popstate，真实 back/forward |
| View Transition | https://developer.mozilla.org/en-US/docs/Web/API/View_Transition_API/Using | 渐进增强，fallback 正常 |
| Service Worker | https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API/Using_Service_Workers | 旧 worker 生命周期、skipWaiting/clients.claim、旧 cache 清理 |
| HTTP caching | https://developer.mozilla.org/en-US/docs/Web/HTTP/Guides/Caching | hash asset、HTML revalidate、bfcache 额外检测 |
| Apple bundle versions | https://developer.apple.com/documentation/bundleresources/information-property-list/cfbundleversion | App build identity |
| Apple short version | https://developer.apple.com/documentation/bundleresources/information-property-list/cfbundleshortversionstring | App product version |
| SQLite WAL | https://www.sqlite.org/wal.html | Gate WAL-reset bug 修复版本 |
| SQLite integrity | https://www.sqlite.org/pragma.html#pragma_integrity_check | integrity_check + foreign_key_check |
| SQLite Backup API | https://www.sqlite.org/backup.html | 一致在线备份 |
| W3C PROV-O | https://www.w3.org/TR/prov-o/ | 轻量 Entity/Activity/Agent/derivation lineage |
| OpenTelemetry traces | https://opentelemetry.io/docs/concepts/signals/traces/ | trace_id/span_id 贯穿任务 |
| Playwright traces | https://playwright.dev/docs/trace-viewer-intro | 失败 trace 证据 |
| Playwright a11y | https://playwright.dev/docs/accessibility-testing | axe 自动检查 + 人工测试 |
| Streamlit caching | https://docs.streamlit.io/develop/concepts/architecture/caching | data/resource 分离、TTL、thread safety、版本化 key |
| RBA FX | https://www.rba.gov.au/statistics/frequency/exchange-rates.html | 实际 AUD/CNY snapshot，日频、NSW 假日处理 |

## 研究结论摘要

- WCAG 2.2 是 2024-12-12 的 W3C Recommendation，建议使用当前版本。
- History API 支持 SPA 模拟真实页面历史；初始页需要 replaceState 才能正确恢复。
- Service Worker 新版本默认等待旧受控页面关闭；旧 UI 复发可能来自生命周期而非文件复制失败。
- `Cache-Control: no-cache` 不保证 bfcache 历史导航重验证，因此需要 runtime manifest handshake。
- SQLite WAL-reset bug 在 3.51.3 修复，并有部分 backport。
- RBA 每日发布 AUD 兑外币，NSW 公共/银行假日除外；rate 不能硬编码。
