# 数据治理与时间真相

## 数据层

```text
D0 Source Registry / Policy
D1 Immutable Raw Capture
D2 Parse / Normalize / Entity Resolution
D3 Interconnection / Economic Event / Unified Ledger
D4 Accounts / Holdings / Valuation / Features
D5 Read Models / Reports / Decisions / Context Export
```

## 数据域

- PUBLIC_SHARED_RAW/CANONICAL：只允许 schema 与小型脱敏非财务示例进入 Git。
- PRIVATE_USER：账户、持仓、交易、私有文档。
- PRIVATE_DERIVED：私人分析、报告、建议。
- SECRET：Key/Cookie/Token。
- EPHEMERAL：cache/temp/rebuildable logs。

## 时间真相

每个对象按适用范围保存：transaction_time、posted_at、effective_at、imported_at、reconciled_at、valued_at、fx_effective_at、report_as_of。

## Source Manifest

必须包含 source_id、label、type、capabilities、path_alias、parser_version、record_count、coverage_start/end、as_of、hash、status、blocking_reason。

## Data Available ≠ Metric Computable

交易流水可以支持消费分类，但当前净资产还需要账户余额/负债；投资市值还需要持仓、价格、FX；现金还需要 opening/closing balance 和转账对账。Metric computability 必须单独建矩阵。

## 真实数据测试

- 使用只读副本/快照/临时隔离 DB。
- 不修改 production 数据。
- 不复制私密值到 Git/Evidence。
- 无真实输入时 blocked，不使用财务 fixture。
