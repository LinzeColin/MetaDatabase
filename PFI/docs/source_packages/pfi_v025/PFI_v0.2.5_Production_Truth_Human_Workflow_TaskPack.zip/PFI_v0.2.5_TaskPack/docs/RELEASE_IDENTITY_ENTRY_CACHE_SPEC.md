# 发布身份、App 入口与缓存规范

## 四方身份

```json
{
  "product_version": "v0.2.5",
  "build_id": "...",
  "git_commit": "...",
  "frontend_bundle_hash": "...",
  "backend_build_hash": "...",
  "app_short_version": "...",
  "app_build_version": "...",
  "data_schema_version": "...",
  "formula_version": "...",
  "parameter_version": "..."
}
```

App plist、launcher、backend API、frontend embedded manifest 必须一致。不一致时显示中文版本冲突页，提供重启/重装/清缓存动作，不能继续渲染旧 UI。

## 缓存

- HTML：`Cache-Control: no-cache, private` + ETag/Last-Modified。
- 静态 JS/CSS：内容 hash URL + `immutable`。
- Service Worker：显式 version、activate 清旧 cache、必要时 skipWaiting/clients.claim；若不用则明确禁用并清旧注册。
- bfcache：`pageshow` 检查 `event.persisted` 和 runtime manifest。
- Streamlit：data cache key 包含 build/data/parameter/formula/fx/read-model hash；TTL 与 invalidation 明确。

## Finder App 验收

- 重装前备份旧 bundle/hash。
- 确认 canonical 安装位置。
- 从 Finder 点击启动，不仅执行 URL。
- 记录 plist、launcher、PID、端口、最终 URL、frontend/backend manifest。
- `/Applications`、Desktop、Downloads 的非 canonical copy 必须识别或移除/隔离，不能误打开旧版本。
