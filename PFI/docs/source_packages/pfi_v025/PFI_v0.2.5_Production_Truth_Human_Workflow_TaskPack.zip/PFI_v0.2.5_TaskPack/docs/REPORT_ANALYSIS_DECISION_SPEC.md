# 分析、报告与决策复盘规范

## 报告最小结构

1. 一句话结论。
2. data freshness / evidence / completeness。
3. 关键指标与组件。
4. 图表/表格。
5. 影响、风险、反方证据。
6. 公式、参数、来源、lineage。
7. 异常和复核入口。
8. 局限与下一步。

## 报告状态

- complete：所有关键依赖 ready。
- partial：部分结论可算，缺口明确。
- blocked：关键依赖缺失，只能生成数据质量报告。

## 模型验证页

展示不变量、误差/偏差、敏感性、参数影响、coverage、验证数据范围和未验证部分。

## 建议对象

必须带 action、horizon、status、confidence dimensions、thesis、catalysts、counter_evidence、invalidation_conditions、risks、portfolio_effect、model_versions、source_ids、human_review_required。

不自动交易。建议必须人工接受/拒绝/延后/失效，并保留复盘历史。
