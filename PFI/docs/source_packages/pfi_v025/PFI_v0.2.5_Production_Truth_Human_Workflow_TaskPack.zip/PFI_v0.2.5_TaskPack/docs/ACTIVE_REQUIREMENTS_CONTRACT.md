# v0.2.5 Active Requirements Contract

## 优先级

1. 本对话中用户最新明确决定。
2. 本 v0.2.5 Task Pack 与 Roadmap。
3. 当前仓库真实代码/数据/运行证据。
4. 历史 Task Pack/Handoff 中不冲突的风险与架构参考。
5. 历史完成声明、旧 HTML 和旧导航规则不具约束力。

## 10 个一级入口

固定顺序：

1. 首页总览
2. 账户与资产
3. 账本流水
4. 投资管理
5. 消费管理
6. 数据源与上传
7. 建议与复盘
8. 报告与洞察
9. 市场与研究
10. 设置

## 产品边界

- PFI 是唯一主体。
- Alpha 只读读取 PFI Context，独立运行。
- 不存在 Ralpha。
- Serenity-Alipay 排除。
- 系统与开发不是一级入口。
- PFI OS 历史架构仅参考，不创建第二根/第二 UI。
- Cloudflare public shell 隔离，不读取私有财务数据。

## 体验合同

- 默认亮色、高级、克制、中文。
- 二级入口是独立页面语义，不是模板换标题。
- 真实 URL、browser history、深链、刷新、焦点和错误状态。
- 设置/反馈只在设置页。
- 动效/触感可关闭、可降级、尊重 reduced motion。

## 数据合同

- 财务验收只用真实数据只读副本/隔离快照。
- 无真实输入 = blocked/not_run，不 fallback。
- 非 ready 不显示财务 0。
- 每个指标有 source/coverage/as_of/formula/parameter/read_model hash。

## 财务口径合同

- CNY 主展示。
- AUD/CNY 方向：1 AUD = X CNY；4.81 是示例。
- FX 每日 06:00 Australia/Sydney 刷新一次；普通运行不联网。
- 双消费口径和投资流出组件必须同屏、同源、可解释。
- 投资活动口径不得等同于净资产损失。

## Codex 合同

- 每次最多一个 Phase。
- Stage 完成后等待用户验收。
- 不写内部审查过程。
- 不用文档、toast、字符串测试、假截图或单数字回复冒充完成。
