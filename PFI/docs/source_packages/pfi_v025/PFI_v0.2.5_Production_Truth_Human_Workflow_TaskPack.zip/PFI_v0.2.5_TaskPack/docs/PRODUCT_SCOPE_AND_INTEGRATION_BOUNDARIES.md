# 产品范围与系统集成边界

## PFI

PFI 管理个人账户、资产负债、账本、投资、消费、数据接入、建议复盘、报告洞察、市场研究和设置。

## Alpha

Alpha 是独立系统。唯一允许集成是读取版本化、只读、最小化 PFI Context：

- net_worth_state
- investable_cash_state
- cashflow_pressure
- asset_allocation
- risk_budget
- investment_behavior_tags
- consumption_pressure_summary
- data_freshness

PFI Context 必须有 schema_version、as_of、source/read_model hash、privacy classification。Alpha 不可回写 PFI 账本/持仓/交易。

## 排除

- Ralpha：不存在。
- Serenity-Alipay：完全排除。
- 系统与开发：不作为一级入口。
- QBVS/QuantLab：若保留，只能是内部/独立能力；PFI 用户只有一个策略实验室 canonical route。
- 自动交易/支付：不授权。

## Cloudflare public surface

只提供定性、脱敏、公开安全信息；不读取真实账户、持仓、私有报告、SQLite、凭证或绝对路径。它不能作为第二活动 UI，不能替代本机 PFI 验收。
