# Codex Prompt — Pre Stage 0 只读重基线

你正在接手 PFI v0.2.5。**本轮只做只读重基线，不修改任何文件，不启动开发。**

## 必读

1. `00_READ_FIRST.md`
2. `TASK_PACK.md`
3. `ROADMAP_COPY.md` 的 Stage 0
4. `docs/ACTIVE_REQUIREMENTS_CONTRACT.md`
5. `docs/HISTORY_DEPRECATION_POLICY.md`
6. `docs/CURRENT_GITHUB_AUDIT_2026-07-10.md`

## 本轮输出

1. 当前分支、HEAD、origin/main、工作树。
2. 将读取的有限目录和文件。
3. 当前活动 UI、启动脚本、App bundle、端口、release identity 来源。
4. 当前数据根目录、数据库、raw/source/read-model 状态；只输出脱敏 count/range/hash。
5. 当前 P0/P1/P2 差距；历史发现标记 StillPresent/Fixed/Regressed/N/A/New。
6. 计划运行的只读命令和停止条件。

## 必须运行

```bash
git status --short
git branch --show-current
git rev-parse HEAD
git rev-parse origin/main
git log -5 --oneline
python3 --version
node --version
python3 -c "import sqlite3; print(sqlite3.sqlite_version)"
node --check PFI/web/app/shell.js
python3 -m pytest PFI/tests -q --collect-only
```

## 禁止

- 禁止修改文件、安装依赖、迁移数据、重装 App、启动完整测试或全仓重构。
- 禁止读取/输出真实财务明细、凭证或密钥。
- 禁止把 README 的完成声明当运行事实。
- 禁止执行 Stage 0 或后续 Stage。

回复结尾必须写：`已停止在 Pre Stage 0，只读基线等待用户验收。`
