# 单 Phase 执行模板

```text
本轮只执行：v0.2.5 Stage <N> / Phase <N.M> - <名称>
不执行下一 Phase 或下一 Stage。

Pursuing Goal：
<复制 Roadmap>

将读取：
<有限文件>

将修改/创建：
<Allowed Files 子集>

明确不修改：
<业务/数据/系统边界>

测试命令：
<精确命令>

数据与迁移影响：
<无/具体说明>

风险与停止条件：
<具体>

回滚：
<具体>

完成输出：
- diff summary
- 命令、exit code、真实摘要
- Evidence Pack
- 剩余风险
- 用户验收点

结尾：
已停止在 Stage <N> / Phase <N.M>，等待用户验收或明确指令。
```
