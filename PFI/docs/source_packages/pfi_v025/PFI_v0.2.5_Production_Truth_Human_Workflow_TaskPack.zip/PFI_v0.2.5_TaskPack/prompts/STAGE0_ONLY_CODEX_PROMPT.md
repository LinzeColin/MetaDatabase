# Codex Prompt — v0.2.5 Stage 0 only

前提：用户已经明确接受 Pre Stage 0 只读基线。

**本轮最多执行 Stage 0 的一个 Phase。不要执行完整 Stage 0，不要进入 Stage 1。**

开始前先输出：

- 当前状态和目标 Phase；
- 读取文件；
- 修改/创建文件；
- 明确不修改范围；
- 验证命令；
- 数据/迁移影响；
- 风险和回滚。

严格遵守 `ROADMAP_COPY.md` Stage 0 和 `docs/ACTIVE_REQUIREMENTS_CONTRACT.md`。

不得：

- 修改业务 UI、财务逻辑、真实数据或 App bundle；
- 引用 8/9/6 入口作为当前合同；
- 写内部审查过程；
- 用 README/文档声明作为完成证据；
- 自动进入下一 Phase/Stage。

完成后只输出：

1. diff summary；
2. 真实命令和 exit code；
3. Evidence 路径；
4. 剩余风险；
5. 回滚方式。

结尾：`本轮已停止在 Stage 0 / Phase X，等待用户验收或明确指令。`
