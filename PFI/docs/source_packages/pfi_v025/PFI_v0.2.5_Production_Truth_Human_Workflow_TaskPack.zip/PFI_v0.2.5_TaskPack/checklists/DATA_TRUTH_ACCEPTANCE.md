# 数据真相验收

- [ ] canonical private data root 已确定。
- [ ] source manifest 有 count/range/as-of/hash/status。
- [ ] 数据可用与指标可计算分开判断。
- [ ] 时间字段/时区完整。
- [ ] FX snapshot 有 source/effective date/hash/stale。
- [ ] 普通运行不联网。
- [ ] raw→normalized→interconnection→economic_event→ledger lineage 可追溯。
- [ ] 重复导入幂等。
- [ ] 转账/退款/投资链路不误算。
- [ ] 账户/持仓/估值 coverage 明确。
- [ ] confirmed_zero 有完整证据；其他状态不显示 0。
- [ ] 双消费和投资流出组件对账。
- [ ] 所有 finance E2E 使用真实只读数据；无 fallback。
- [ ] Evidence 不含私密值。
