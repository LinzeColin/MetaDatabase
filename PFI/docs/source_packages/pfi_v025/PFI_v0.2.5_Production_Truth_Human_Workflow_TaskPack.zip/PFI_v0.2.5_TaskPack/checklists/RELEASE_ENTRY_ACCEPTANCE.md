# 发布入口验收

- [ ] CFBundleShortVersionString。
- [ ] CFBundleVersion。
- [ ] launcher canonical URL。
- [ ] backend manifest。
- [ ] frontend manifest。
- [ ] frontend asset hash。
- [ ] backend build hash。
- [ ] git commit。
- [ ] HTML cache headers/ETag。
- [ ] hashed immutable assets。
- [ ] Service Worker 状态/旧 cache。
- [ ] bfcache pageshow manifest check。
- [ ] Streamlit cache key/TTL/invalidation。
- [ ] Finder screenshot 与 browser trace。
- [ ] 非 canonical App copies 处理。
