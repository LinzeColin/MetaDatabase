# Stage Closeout 清单

- [ ] 只执行了本 Phase/Stage allowed files。
- [ ] 未自动进入下一 Phase/Stage。
- [ ] diff summary 完整。
- [ ] 真实命令、exit code 和失败记录完整。
- [ ] evidence.json/terminal.log/changed_files/risk_and_rollback 存在。
- [ ] UI 有截图/trace/a11y tree；DB 有 before/after/integrity；App 有 plist/hash/Finder 证据。
- [ ] 没有 mock/sample/demo/synthetic/fixture/fake 财务数据。
- [ ] 没有真实私密值进入 Git/Evidence。
- [ ] README/状态文档没有过度声明。
- [ ] 剩余风险和阻断明确。
- [ ] 用户验收对象和问题明确。
