# v0.2.5 最低修复 Gate

- [ ] Finder App、localhost、frontend、backend 四方 release identity 一致。
- [ ] App bundle 真实重装并从 Finder 点击验证。
- [ ] Source Manifest、data root、coverage、as-of、hash 可审计。
- [ ] 净资产/现金/投资非 ready 时不显示 0。
- [ ] 10 个一级入口在视觉、DOM、a11y tree、no-JS 中一致。
- [ ] 二级页有独立 URL/页面结构/主操作/状态。
- [ ] 上传→解析→复核→账本闭环。
- [ ] 持仓写 SQLite，刷新/重启仍存在。
- [ ] 双消费、FX、公式、参数、Interconnection、报告同源。
- [ ] 参数中心和 Interconnection Map 在正式主 UI。
- [ ] 默认亮色、动效/触感可降级、WCAG 2.2 AA。
- [ ] Durable job 真实进度、失败恢复、无普通运行联网。
- [ ] SQLite version/WAL/迁移/backup/restore/integrity 通过。
- [ ] Playwright trace、截图、DB、hash、命令 Evidence 完整。
- [ ] 用户验收绑定具体 release/evidence。
