# Reference-only Notice

本目录和 `html/` 中的历史/原型材料不构成 v0.2.5 代码基线或产品验收。

允许参考：

- 亮色、正常软件感、稳定导航、数据门禁、报告/公式入口方向。
- 旧审计暴露的风险、失败模式和验证命令。
- PFI OS 的单一 UI、durable job、provenance、backup/restore 等架构思想。

禁止：

- 复制旧 HTML 作为生产 UI。
- 恢复旧 6/8/9 入口合同。
- 将旧 closeout、截图或审查报告当作当前完成证据。
- 把 PFI_OS/、Cloudflare public、Alpha 或 QBVS 变成 PFI 第二活动产品面。
