#!/usr/bin/env python3
"""Render the formal verifier v2.1 run from locked local and external evidence."""

from __future__ import annotations

import argparse
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


SUBJECT_COMMIT = "e1af471c4d3dab0044aa47122647c16701d9d095"
SUBJECT_TREE = "de8cfcfbd5b9304409f29250a1e657aa27958dfc"
SUBJECT_ARCHIVE_SHA256 = "5673abfe6ed5bbe02cbc2694294444258bb45212c09cc09549c997ec8d5b219f"
BASE_COMMIT = "7fd0768002081f27c070561fa855a08713d1bc00"
RUN_STARTED_AT = "2026-07-20T03:29:42.574998+00:00"


def result(test_id, gate, status, blocking, expected, actual="", reason="", evidence=None):
    return {
        "test_id": test_id,
        "gate": gate,
        "status": status,
        "blocking": blocking,
        "expected": expected,
        "actual": actual,
        "reason": reason,
        "attempts": 1 if status in {"PASS", "FAIL"} else 0,
        "evidence_paths": evidence or [],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--external-gate", required=True)
    args = parser.parse_args()
    run_dir = args.run_dir.resolve()
    external_path = run_dir / args.external_gate
    external = json.loads(external_path.read_text(encoding="utf-8"))
    external_pass = external.get("status") == "PASS"
    verdict = "PASS" if external_pass else "BLOCKED"
    action = "NONE" if external_pass else "ESCALATE"
    external_blockers = external.get("blockers", [])
    external_summary = (
        "四个 policy checks（dual-plane + 三个 runtime classifier）全部 SUCCESS；Stage1/live heavy jobs SUCCESS；real-backfill heavy job 因锁定 diff 无 runtime 路径而按合同 SKIPPED；PR 已合并且 merge tree/main 身份闭合。"
        if external_pass
        else "外部门尚未闭合：" + "; ".join(external_blockers)
    )
    ended_at = datetime.now(timezone.utc).isoformat()

    results = [
        result(
            "SID-001", "subject_identity", "PASS", True,
            "detached clean commit/tree 与 git archive SHA-256 被独立锁定",
            f"commit={SUBJECT_COMMIT}; tree={SUBJECT_TREE}; archive_sha256={SUBJECT_ARCHIVE_SHA256}",
            evidence=[
                "logs/I-001-subject-oids.stdout.log",
                "logs/I-002-subject-status.stdout.log",
                "logs/I-009-subject-archive.command.json",
                "logs/I-010-archive-sha256.stdout.log",
            ],
        ),
        result(
            "BSH-001", "build_start_health", "NOT_APPLICABLE", True,
            "developer_check 对治理迁移不要求构建或启动新 runtime",
            reason="本 subject 不含 ADP src/Worker 变更且无部署意图；runtime 身份另由 WKR-001 只读核验。",
            evidence=["logs/I-008-no-src-worker-diff.command.json"],
        ),
        result(
            "CORE-001", "core_journey", "PASS", True,
            "canonical 路由、Owner 决策、下一 Run Contract 与兼容治理合同自洽",
            "静态合同审计 PASS；Python 3.12、双 baseline provenance 与 exact test-name-set 比较已锁定",
            evidence=[
                "raw-results/static-contract-audit.json",
                "raw-results/backfill-classifier-audit.json",
                "logs/G-001-adp-governance-65.command.json",
                "logs/G-001-adp-governance-65.stderr.log",
                "logs/I-006-delta-patch.stdout.log",
            ],
        ),
        result(
            "CLS-001", "runtime_change_classifier", "PASS", True,
            "运行时路径与非运行时路径分类精确，manual dispatch 仍强制执行，预期 skip 不放宽 replay/queue/safety 合同",
            "472 个实际变更路径 runtime matches=0；6/6 runtime 正向与 6/6 非 runtime 负向矩阵精确；5 个 focused replay tests 通过；real-backfill PR heavy job 为预期 SKIPPED",
            evidence=[
                "raw-results/backfill-classifier-audit.json",
                "logs/C-001-backfill-classifier-audit.command.json",
                "logs/C-002-focused-real-replay-5.command.json",
                "logs/C-002-focused-real-replay-5.stderr.log",
                "raw-results/external-gate-final-v2.json",
            ],
        ),
        result(
            "DATA-001", "data_or_output", "PASS", True,
            "30 bundles、424 manifests、前端 ZIP 与 Worker 内容身份不漂移",
            "30/424 数量和树摘要匹配；前端 ZIP 6106 bytes 且摘要匹配；Worker SHA-256 匹配",
            evidence=["raw-results/static-contract-audit.json"],
        ),
        result(
            "REG-001", "changed_scope_regression", "PASS", True,
            "Python 3.12 full suite 相对历史封存计数与可重放 7fd base 不新增 failure/error",
            "candidate=923/2F/11E/49S; 7fd replay=923/54F/50E/49S; candidate-only exact F/E set=0",
            evidence=[
                "logs/R-001-full-suite.command.json",
                "logs/R-001-full-suite.stderr.log",
                "logs/R-005-base-full-suite.command.json",
                "logs/R-005-base-full-suite.stderr.log",
                "raw-results/full-suite-differential.json",
            ],
        ),
        result(
            "SEC-001", "safety_security", "PASS", True,
            "安全边界、secret scan 与零生产副作用合同通过",
            "security 14/14；59410 added lines 高置信 secret findings=0；三条生产门保持 fail closed",
            evidence=[
                "logs/G-002-security-boundary.command.json",
                "logs/G-002-security-boundary.stderr.log",
                "raw-results/static-contract-audit.json",
                "logs/G-008-preflight-expected-exit.stdout.log",
            ],
        ),
        result(
            "COD-001", "codexproject_absence", "PASS", True,
            "CodexProject main 不重新出现 arxiv-daily-push，候选不恢复旧 src",
            "GitHub Contents API=404，local main ls-tree 为空，base→subject src diff 为空",
            evidence=[
                "logs/E-001-codexproject-main-sha.stdout.log",
                "logs/E-002-codexproject-path-absence.command.json",
                "logs/E-002-codexproject-path-absence.stdout.log",
                "logs/E-006-codexproject-absence-oracle.stdout.log",
                "logs/I-008-no-src-worker-diff.command.json",
            ],
        ),
        result(
            "WKR-001", "worker_identity", "PASS", True,
            "Worker source 零差异且 public live build.json 与锁定 Worker 自哈希一致",
            "base→subject Worker diff 为空；live build c2ccc1fd01ec 与 self-excluding SHA-256 一致",
            evidence=[
                "logs/I-008-no-src-worker-diff.command.json",
                "logs/E-008-live-build-readonly.stdout.log",
                "logs/E-009c-live-build-oracle.stdout.log",
            ],
        ),
        result(
            "ENV-001", "environment", "PASS", True,
            "精确 Python 3.12 环境可复现且依赖健康",
            "CPython 3.12.13 arm64；pip check clean；环境包清单已封存；系统 Python 3.9 不兼容事实已复现",
            evidence=[
                "logs/X-001-python312-version.stdout.log",
                "logs/X-002-pip-check.stdout.log",
                "logs/X-003-pip-list.stdout.log",
                "logs/X-004-system-python39-version.stdout.log",
                "logs/X-005-system-python39-incompatible.stdout.log",
            ],
        ),
        result(
            "NEG-001", "fail_closed_negative_controls", "PASS", True,
            "final-bundle、readiness、preflight 三个历史兼容入口均按合同内部 exit=2，shell assertion exit=0",
            "EXPECTED_BUNDLE_EXIT=2; EXPECTED_READINESS_EXIT=2; EXPECTED_PREFLIGHT_EXIT=2",
            evidence=[
                "logs/G-006-acceptance-bundle-expected-exit.command.json",
                "logs/G-006-acceptance-bundle-expected-exit.stdout.log",
                "logs/G-007-readiness-expected-exit.command.json",
                "logs/G-007-readiness-expected-exit.stdout.log",
                "logs/G-008-preflight-expected-exit.command.json",
                "logs/G-008-preflight-expected-exit.stdout.log",
            ],
        ),
        result(
            "EXT-001", "external_pr_gate", "PASS" if external_pass else "BLOCKED", True,
            "四个 policy checks 全 SUCCESS；两个适用 heavy jobs SUCCESS；real-backfill heavy job 仅在 runtime diff/manual dispatch 时运行且本次为预期 SKIPPED；PR merged，merge tree/main 身份闭合",
            external_summary if external_pass else "",
            reason="" if external_pass else external_summary,
            evidence=[args.external_gate],
        ),
    ]

    manifest = {
        "_format_note": "Strict JSON syntax; JSON is valid YAML.",
        "schema_version": "2.1",
        "run": {
            "id": "e1af471c_2026-07-20",
            "started_at": RUN_STARTED_AT,
            "ended_at": ended_at,
            "timezone": "UTC",
            "verifier_identity": "codex-subthread-independent-verifier-v2.1",
            "independence_evidence": "独立上下文、只读 detached subject、fresh git archive、fresh Python 3.12 tests、官方 GitHub API read-only 证据；未采用 builder 测试输出作为判定证据。",
            "independent_passes": 1,
            "independent_pass_records": [],
            "profile": "deep",
            "risk_level": "high",
            "risk_triggers": [
                "repository migration and governance routing",
                "historical compatibility artifacts and exact content hashes",
                "live production boundary with no-deploy requirement",
                "secret-bearing operational surface",
                "external CI merge and tree identity gate",
            ],
        },
        "scope": {
            "mode": "single-project",
            "verdict_scope": "target-project-only",
            "repository_read_scope": "whole-repository-read-only-as-needed",
            "target_project_name": "ADP_META_MIGRATION",
            "target_project_path": "/private/tmp/metadatabase-adp-verifier-e1af471c4d3d",
            "acceptance_closure": [
                "canonical ADP migration contract and Owner late decisions",
                "compatibility assets and hashes",
                "Python 3.12 governance/full-suite differential",
                "CodexProject absence and Worker zero-diff/live identity",
                "PR #68 four policy checks, semantic heavy-job contract, merge, merge-tree, and main identity",
            ],
            "closure_evidence": [
                "raw-results/static-contract-audit.json",
                "raw-results/full-suite-differential.json",
                "raw-results/backfill-classifier-audit.json",
                args.external_gate,
            ],
            "included_paths": [
                "arxiv-daily-push/",
                "tests/governance/test_adp_*.py",
                "FINAL_ACCEPTANCE_BUNDLE/",
                "governance/run_manifests/ADP-*",
                "tools/validate_task_pack.py and three verify_* compatibility tools",
                ".github/workflows ADP and dual-plane gates",
            ],
            "excluded_projects": ["EEI", "PFI", "Stock_Skill", "LinzeDatabase"],
            "excluded_scope_notes": "developer_check only; no live mutation, deployment, SMTP, scheduler, Release, restore, load test, active exploit, or product feature remediation.",
        },
        "taskpack": {
            "mode": "not-provided", "detected": False, "authoritative": False,
            "authorization_reference": "", "source_kind": "", "source_reference": "",
            "source_archive_sha256": "", "source_snapshot_path": "",
            "source_snapshot_sha256": "", "source_snapshot_size": 0,
            "source_file_count": 0, "declared_version": "", "pack_digest_sha256": "",
            "contract_digest_sha256": "", "authorized_pack_digest_sha256": "",
            "pursuing_goal": "", "files": [], "acceptance_ids": [], "task_ids": [],
            "integrity_status": "NOT_APPLICABLE",
            "compatibility_status": "NOT_APPLICABLE", "compatibility_reason": "",
            "drift_status": "NOT_APPLICABLE", "drift_items": [],
            "authorization_evidence_paths": [], "integrity_evidence_paths": [],
            "compatibility_evidence_paths": [], "drift_evidence_paths": [],
            "evidence_paths": [],
            "reason_if_absent": "Owner supplied an explicit Acceptance Contract in the verification request, not a Product-Design-Taskpack artifact.",
        },
        "traceability": {
            "matrix_path": "TRACEABILITY_MATRIX.json",
            "status": "PASS" if external_pass else "BLOCKED",
            "reason": "" if external_pass else external_summary,
            "evidence_paths": ["TRACEABILITY_MATRIX.json", args.external_gate],
        },
        "subject": {
            "repository": "git@github.com:LinzeColin/MetaDatabase.git",
            "repository_root": "/private/tmp/metadatabase-adp-verifier-e1af471c4d3d",
            "branch": "detached (PR head codex/adp-migration-closure)",
            "upstream": "origin/codex/adp-migration-closure",
            "git_head": SUBJECT_COMMIT,
            "git_status": "clean detached HEAD",
            "source_dirty": False,
            "source_snapshot_sha256": SUBJECT_ARCHIVE_SHA256,
            "source_snapshot_evidence_paths": [
                "logs/I-009-subject-archive.command.json",
                "logs/I-010-archive-sha256.stdout.log",
            ],
            "build_id": "c2ccc1fd01ec",
            "artifact_path": "", "artifact_sha256": "", "image_digest": "",
            "package_version": "0.23.1",
            "deployment_identity": "cloudflare-worker:adp-cloud:c2ccc1fd01ec",
            "source_to_artifact_mapping_evidence": [
                "logs/I-001-subject-oids.stdout.log",
                "logs/I-009-subject-archive.command.json",
                "logs/I-010-archive-sha256.stdout.log",
            ],
            "deployment_mapping_evidence_paths": [
                "logs/I-008-no-src-worker-diff.command.json",
                "logs/E-008-live-build-readonly.stdout.log",
                "logs/E-009c-live-build-oracle.stdout.log",
            ],
            "runtime_config_hash": "",
            "feature_flags": [
                "ADP_PRODUCTION_ENABLED=false", "ADP_SCHEDULED_RUN_ENABLED=false",
                "ADP_ALLOW_SMTP_SEND=false", "ADP_ALLOW_RELEASE_UPLOAD=false",
            ],
            "schema_or_migration_version": "cn_v0_3 / MetaDatabase ADP migration closure",
            "sbom_paths": [], "provenance_paths": [],
            "signature_verification": {
                "status": "NOT_APPLICABLE",
                "reason": "developer_check uses an exact git commit/tree and hashed git archive; no signed release artifact is in scope.",
                "evidence_paths": [],
            },
        },
        "baseline": {
            "reference": "historical sealed old-control 923/3F/11E/62S (non-replayable here); replayable MetaDatabase base 7fd0768 923/54F/50E/49S",
            "acceptance_pack_hash": "",
            "comparison_status": "PASS",
            "reason_if_absent": "",
            "evidence_paths": [
                "logs/R-002-base-archive.command.json",
                "logs/R-003-base-archive-sha256.stdout.log",
                "logs/R-005-base-full-suite.stderr.log",
                "raw-results/full-suite-differential.json",
            ],
        },
        "environment": {
            "class": "isolated local git-archive snapshot; external state read-only",
            "os_arch": "macOS arm64; CPython 3.12.13",
            "entrypoints": [
                "python -m unittest discover tests/governance test_adp_*.py",
                "python -m unittest discover arxiv-daily-push/tests",
                "check_dual_plane_ci.py", "validate_task_pack.py",
            ],
            "data_snapshot": f"git archive {SUBJECT_COMMIT}; sha256 {SUBJECT_ARCHIVE_SHA256}",
            "config_hash": "6e16f4796a7d2f66a83d5563ee47ee3bc85d251627f12f0d91470dd2cb54ae42",
            "feature_flags": ["production=false", "scheduled=false", "smtp=false", "release=false"],
            "external_dependencies": ["GitHub API read-only", "public ADP build.json", "GitHub Actions external gates"],
        },
        "release": {
            "decision_scope": "developer_check", "intent": "none", "strategy": "not-applicable",
            "candidate_version": "", "candidate_identity": "", "control_version": "",
            "rollout_groups": [], "health_signals": [], "business_invariants": [],
            "abort_conditions": ["any live mutation required", "subject OID drift", "policy check non-success", "unjustified heavy-job skip"],
            "rollback_or_rollforward": {
                "method": "", "tested": False, "status": "NOT_APPLICABLE",
                "reason": "no release or deployment authorized in developer_check", "evidence_paths": [],
            },
            "bake": {"required_seconds": 0, "observed_seconds": 0, "status": "NOT_APPLICABLE", "reason": "no staged release", "evidence_paths": []},
            "post_deploy": {"status": "NOT_APPLICABLE", "reason": "no deployment", "observation_start": "", "observation_end": "", "evidence_paths": []},
        },
        "operations": {
            "owner_or_oncall": "", "runbook_paths": [], "dashboard_or_query_refs": [],
            "alert_tests": [], "slo_or_health_objectives": [], "capacity_evidence_paths": [],
            "backup_restore": {"status": "NOT_APPLICABLE", "reason": "no runtime or data mutation", "evidence_paths": []},
        },
        "ai_system": {
            "applicable": False, "model_provider": "", "model_id": "", "model_snapshot": "",
            "model_snapshot_reason": "not an AI-system acceptance", "prompt_or_policy_hash": "",
            "toolset_or_harness_hash": "", "retrieval_snapshot": "",
            "sampling": {"temperature": None, "top_p": None, "seed": None},
            "trial_count": 0, "task_slices": [], "trial_records": [],
            "success_threshold": None, "observed_pass_rate": None, "outcome_grader": "",
            "judge_calibration": "", "evaluator_independence": {
                "primary_grader_type": "not-applicable", "generator_is_sole_judge": False,
                "cross_model_review": False, "blind_evaluation": False,
                "independent_evaluator_ids": [], "disagreement_policy": "", "evidence_paths": [],
            },
            "baseline_reference": "", "baseline_reason_if_absent": "not applicable",
            "safety_checks": [], "safety_gate_status": "NOT_APPLICABLE",
            "safety_evidence_paths": [], "cost_latency_evidence_paths": [], "trace_paths": [],
        },
        "tools": ["git", "Python 3.12 unittest", "gh CLI read-only", "curl read-only", "verifier v2.1"],
        "commands": [
            "PYTHONPATH=arxiv-daily-push/src python -B -m unittest discover -s tests/governance -p test_adp_*.py -q",
            "PYTHONPATH=arxiv-daily-push/src python -B -m unittest discover -s arxiv-daily-push/tests -q",
            "python -B arxiv-daily-push/machine/tools/check_dual_plane_ci.py --root . --projects arxiv-daily-push --require-projects",
            "python -B tools/validate_task_pack.py --root .",
            "PYTHONPATH=arxiv-daily-push/src python -B -m unittest discover -s arxiv-daily-push/tests -p test_stage1_real_replay.py -q",
        ],
        "inputs": [SUBJECT_COMMIT, SUBJECT_TREE, SUBJECT_ARCHIVE_SHA256, BASE_COMMIT, "PR #68"],
        "results": results,
        "findings": [], "waivers": [], "abort_or_incidents": [],
        "evidence": {
            "root": ".", "redaction_reviewed": True,
            "sensitive_evidence_external_refs": [], "retention_days": 30,
            "external_signature_ref": "",
        },
        "verdict": {
            "value": verdict, "action": action,
            "reason": (
                "锁定 subject 的本地深度验收、四个 policy checks、heavy-job 语义、PR 合并与 merge-tree/main 身份全部闭合。"
                if external_pass else
                "锁定 subject 的本地深度验收通过，但外部 CI/merge/tree 必要门尚未闭合。"
            ),
            "owner_next_action": (
                "接受 developer_check 结论；此结论不授权部署、SMTP、scheduler、Release 或 restore。"
                if external_pass else
                "只处理未通过的 policy/semantic gate；全部闭合后重新读取 merge commit tree 与 main 身份。"
            ),
            "report": "VERDICT.md",
        },
    }

    by_id = {item["test_id"]: item for item in results}
    def row(requirement_id, acceptance_id, oracle_id, test_ids, evidence):
        statuses = [by_id[test_id]["status"] for test_id in test_ids]
        status = "FAIL" if "FAIL" in statuses else "BLOCKED" if any(s in {"BLOCKED", "NOT_RUN"} for s in statuses) else "PASS"
        value = {
            "requirement_id": requirement_id, "acceptance_id": acceptance_id,
            "oracle_id": oracle_id, "blocking": True, "task_ids": [],
            "test_ids": test_ids, "status": status, "evidence_paths": evidence,
        }
        if status != "PASS":
            value["reason"] = external_summary
        return value

    rows = [
        row("REQ-ROUTE", "AC-ADP-001", "ORACLE-CANONICAL-CONTRACT", ["CORE-001"], ["raw-results/static-contract-audit.json"]),
        row("REQ-NO-RESTORE", "AC-ADP-002", "ORACLE-CODEXPROJECT-ABSENCE", ["COD-001"], ["logs/E-006-codexproject-absence-oracle.stdout.log"]),
        row("REQ-NO-LIVE-MUTATION", "AC-ADP-003", "ORACLE-WORKER-ZERO-DIFF-LIVE-ID", ["WKR-001"], ["logs/E-009c-live-build-oracle.stdout.log"]),
        row("REQ-PY312-GATES", "AC-ADP-004", "ORACLE-PY312-GOVERNANCE-FAIL-CLOSED", ["ENV-001", "CORE-001", "NEG-001"], ["logs/G-001-adp-governance-65.stderr.log", "logs/G-006-acceptance-bundle-expected-exit.stdout.log"]),
        row("REQ-FULL-DIFF", "AC-ADP-005", "ORACLE-EXACT-FE-SET-DIFFERENTIAL", ["REG-001"], ["raw-results/full-suite-differential.json"]),
        row("REQ-INTEGRITY-SAFETY", "AC-ADP-006", "ORACLE-HASH-SECRET-SAFETY", ["DATA-001", "SEC-001", "SID-001"], ["raw-results/static-contract-audit.json", "logs/I-010-archive-sha256.stdout.log"]),
        row("REQ-EXTERNAL-CLOSURE", "AC-ADP-007", "ORACLE-POLICY-CLASSIFIER-HEAVY-JOBS-MERGE-TREE", ["CLS-001", "EXT-001"], ["raw-results/backfill-classifier-audit.json", args.external_gate]),
    ]
    matrix = {
        "_format_note": "Strict JSON; Owner Acceptance Contract mapped without a Product-Design-Taskpack.",
        "schema_version": "2.1",
        "target_project_name": "ADP_META_MIGRATION",
        "subject_identity": SUBJECT_ARCHIVE_SHA256,
        "taskpack_digest_sha256": "",
        "rows": rows,
        "change_impact": [
            {
                "change_id": "CHG-ADP-MIGRATION-CLOSURE",
                "changed_paths": ["472 paths in 7fd0768..e1af471c; exact list in git evidence"],
                "impacted_acceptance_ids": [row["acceptance_id"] for row in rows],
                "test_ids": ["SID-001", "CORE-001", "CLS-001", "DATA-001", "REG-001", "SEC-001", "COD-001", "WKR-001", "ENV-001", "NEG-001", "EXT-001"],
                "evidence_paths": ["raw-results/static-contract-audit.json", "raw-results/full-suite-differential.json", "raw-results/backfill-classifier-audit.json", args.external_gate],
            },
            {
                "change_id": "CHG-RUNTIME-CLASSIFIER-CLOSURE",
                "changed_paths": [".github/workflows/arxiv-daily-push-real-backfill.yml", "arxiv-daily-push/docs/HANDOFF.md", "arxiv-daily-push/tests/test_stage1_real_replay.py", "tests/governance/test_adp_canonical_governance_oids.py"],
                "impacted_acceptance_ids": ["AC-ADP-001", "AC-ADP-004", "AC-ADP-005", "AC-ADP-007"],
                "test_ids": ["CORE-001", "CLS-001", "ENV-001", "REG-001", "EXT-001"],
                "evidence_paths": ["logs/I-005-delta-name-status.stdout.log", "logs/I-006-delta-patch.stdout.log"],
            },
        ],
    }

    status_counts = Counter(item["status"] for item in results)
    verdict_md = f"""ACTION: {action}

# ADP MetaDatabase 迁移独立验收 — {SUBJECT_COMMIT[:12]}

## 先看结论

- 决策范围：`developer_check`，高风险 deep profile。
- 不可变 subject：commit `{SUBJECT_COMMIT}`，tree `{SUBJECT_TREE}`，archive SHA-256 `{SUBJECT_ARCHIVE_SHA256}`。
- machine verdict：`{verdict}`。
- 本地结论：65/65 governance、14/14 security、双平面、V7.2、root compatibility 与三条 fail-closed 合同通过。
- 全量差分：candidate `923 / 2F / 11E / 49S`；可重放 7fd base `923 / 54F / 50E / 49S`；candidate-only failure/error test-name set 为 0。
- 外部门与 classifier：{external_summary}
- 当前动作：{manifest['verdict']['owner_next_action']}

### 实际证明

1. canonical HANDOFF 覆盖 Owner 晚到决策、Python 3.12 前置条件、双 baseline provenance 与下一 Run Contract。
2. 30 个 bundle、424 个 manifests、前端 ZIP 与 Worker 哈希保持精确；CodexProject main 无旧 ADP 目录。
3. Worker 未改、未部署；public `build.json` 与锁定 Worker 自哈希一致；无 SMTP、scheduler、Release 或 restore 写动作。
4. real-backfill 的 PR heavy job 是证据化的预期 skip：实际 diff 无 runtime 路径，runtime 正向矩阵与 manual dispatch 均仍触发。

### 残余边界

- 历史 sealed old-control 只有合同 provenance，本次边界禁止恢复旧 CodexProject 源，因此不把它冒充 7fd replay。
- 剩余 2F/11E 是已知历史债，不是本迁移新增；完整名称集合见 `raw-results/full-suite-differential.json`。
- `developer_check PASS` 也不授权生产发布。

---

## 技术记录

- Verdict / ACTION：`{verdict}` / `{action}`
- Subject archive：`{SUBJECT_ARCHIVE_SHA256}`
- Environment：CPython 3.12.13 arm64；pip check clean。
- Taskpack：未提供；Owner Acceptance Contract 已映射为 7 个 acceptance rows。
- Results：{dict(status_counts)}
- Findings / waivers：0 / 0
- Traceability：{'PASS, 7/7 rows' if external_pass else 'BLOCKED at AC-ADP-007'}
- Evidence seal：finalize 后由 `EVIDENCE_INDEX.json`、`FINAL_DECISION.json`、in-toto attestation 与 `SHA256SUMS.txt` 提供。
"""

    test_rows = "\n".join(
        f"| {item['test_id']} | {item['gate']} | {'yes' if item['blocking'] else 'no'} | {item['expected']} | {item.get('actual') or item.get('reason')} | {item['status']} | {', '.join(item['evidence_paths'])} |"
        for item in results
    )
    test_md = f"""# TEST MATRIX — ADP_META_MIGRATION {SUBJECT_COMMIT[:12]}

- Decision scope：`developer_check`
- Subject identity：`{SUBJECT_ARCHIVE_SHA256}`
- Risk / profile：`high / deep`
- Traceability：7 Owner Acceptance rows；change-impact=2
- Baseline：historical sealed 923/3F/11E/62S 与 replayable 7fd 923/54F/50E/49S 分离。

| Test ID | Gate | Blocking | Expected | Actual / Reason | Status | Evidence |
|---|---|---:|---|---|---|---|
{test_rows}

## 适用性

- 功能、数据、集成、边界、兼容、安全、身份、证据：适用并已运行。
- 性能、并发、真人 UI、AI eval、staged/post-deploy：本 developer_check 不适用；无运行时或部署变更。
"""

    defect_md = f"""# 开发修复单 — ADP_META_MIGRATION {SUBJECT_COMMIT[:12]}

## 总览

- 当前 verdict：`{verdict}`。
- 产品缺陷：0；测试缺陷：0；环境缺陷：0；需求缺口：0。
- 本地 acceptance contract 已通过；历史 2F/11E 以 exact-name differential 记录，不归因为本迁移新增缺陷。
- 外部状态：{external_summary}

## 当前必须动作

{manifest['verdict']['owner_next_action']}

不得以恢复旧根 `HANDOFF/`、修改/跳过 full-suite tests、部署 Worker 或启用任何生产副作用来消除门禁。
"""

    modification_md = f"""ACTION: {action}

# MODIFICATION REPORT — ADP_META_MIGRATION {SUBJECT_COMMIT[:12]}

## ROI 优先级

1. {'无代码修补；接受 developer_check 结论' if external_pass else '只处理 policy/classifier/heavy-job 外部门并重新读取 merge tree'}。
2. 不扩展迁移契约，不顺带修历史 2F/11E。
3. 下一开发线按 canonical HANDOFF 另开 Google News retry/backoff Run Contract。

## 禁止本轮扩展

- 不改 ADP src/Worker，不部署，不改 cron，不引入付费 API。
- 不恢复 CodexProject 旧目录或根 `HANDOFF/`。
- 不修 `TASK_INDEX.csv.status` 死配置。
"""

    release_md = f"""# RELEASE ASSURANCE — ADP_META_MIGRATION {SUBJECT_COMMIT[:12]}

- Decision scope：`developer_check`
- Release intent / strategy：`none / not-applicable`
- Candidate source identity：`{SUBJECT_ARCHIVE_SHA256}`
- Source commit/tree：`{SUBJECT_COMMIT}` / `{SUBJECT_TREE}`
- Live identity仅作零变更核验：`adp-cloud / c2ccc1fd01ec`
- Taskpack：未提供；Owner Acceptance Contract 7/7 映射。
- Baseline differential：PASS。
- 发布、bake、rollback、post-deploy：NOT_APPLICABLE，因为没有发布授权或运行时变更。
- 外部门：{external_summary}

此报告不构成部署、SMTP、scheduler、Release、restore 或 DAILY_OPERATION 授权。
"""

    ai_md = """# AI EVAL MATRIX — ADP_META_MIGRATION

- Applicable：NO
- 原因：本次验收对象是仓库迁移与治理/兼容资产，不是 AI 模型、prompt、retrieval 或 agent 行为变更。
- Safety gate：NOT_APPLICABLE；仓库安全边界由 SEC-001 独立覆盖。
- Gate status：NOT_APPLICABLE
"""

    human_md = """# HUMAN JOURNEY — NOT_APPLICABLE

- 角色：仓库维护者与独立 verifier。
- 任务：验证 migration contract、immutable subject、测试 differential 和外部 merge gate。
- 真人 UI journey：NOT_APPLICABLE；本 subject 不含 UI 或用户交互变更。
- 替代 Oracle：确定性静态审计、Python 3.12 tests、GitHub API read-only world-state checks。
"""

    acceptance_request = {
        "schema_version": "2.1",
        "owner_input": {
            "repository": "LinzeColin/MetaDatabase PR #68",
            "target_project": {"name": "ADP_META_MIGRATION", "path": "/private/tmp/metadatabase-adp-verifier-e1af471c4d3d"},
            "expected_outcome": "Independently verify the immutable ADP MetaDatabase migration closure under the supplied Acceptance Contract.",
            "delivery_reference": SUBJECT_COMMIT,
            "source_documents": ["Owner Acceptance Contract", "arxiv-daily-push/docs/HANDOFF.md"],
            "environment_or_url": "isolated archive snapshot plus read-only GitHub/live build endpoints",
            "notes": "No live mutation, deploy, SMTP, scheduler, Release, restore, or subject modification authorized.",
        },
        "preferences": {
            "decision_scope": "developer_check", "profile": "deep", "language": "zh-CN",
            "release_intent": "none", "allow_safe_local_setup": True, "allow_network_read": True,
            "allow_third_party_write": False, "allow_production_write": False,
            "load_test_authorized": False, "active_security_scan_authorized": False,
            "fault_injection_authorized": False, "destructive_data_test_authorized": False,
        },
        "verifier_discovered": {
            "repository_root": "/private/tmp/metadatabase-adp-verifier-e1af471c4d3d",
            "repository_remote": "git@github.com:LinzeColin/MetaDatabase.git",
            "branch": "detached", "git_head": SUBJECT_COMMIT, "git_status": "clean",
            "source_snapshot_sha256": SUBJECT_ARCHIVE_SHA256,
            "target_project_path": "arxiv-daily-push",
            "project_type": "data-pipeline and governance migration",
            "acceptance_closure": manifest["scope"]["acceptance_closure"],
            "entrypoints": manifest["environment"]["entrypoints"],
            "risk_level": "high", "risk_triggers": manifest["run"]["risk_triggers"],
            "unknowns_requiring_owner": [] if external_pass else external_blockers,
            "traceability": {"status": manifest["traceability"]["status"], "mapped_acceptance_count": 7, "change_impact_count": 2},
        },
        "evidence": {"output_root": str(run_dir), "retention_days": 30},
    }

    writes = {
        "RUN_MANIFEST.yaml": json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        "TRACEABILITY_MATRIX.json": json.dumps(matrix, ensure_ascii=False, indent=2) + "\n",
        "VERDICT.md": verdict_md,
        "TEST_MATRIX.md": test_md,
        "DEFECT_REPORT.md": defect_md,
        "MODIFICATION_REPORT.md": modification_md,
        "RELEASE_ASSURANCE.md": release_md,
        "AI_EVAL_MATRIX.md": ai_md,
        "HUMAN_JOURNEY.md": human_md,
        "ACCEPTANCE_REQUEST.yaml": json.dumps(acceptance_request, ensure_ascii=False, indent=2) + "\n",
    }
    for name, content in writes.items():
        (run_dir / name).write_text(content, encoding="utf-8")
    print(json.dumps({"verdict": verdict, "action": action, "external_gate": args.external_gate}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
