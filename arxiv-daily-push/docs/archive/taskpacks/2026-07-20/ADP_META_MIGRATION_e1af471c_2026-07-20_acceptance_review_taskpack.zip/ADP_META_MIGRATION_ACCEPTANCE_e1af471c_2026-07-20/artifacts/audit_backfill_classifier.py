#!/usr/bin/env python3
"""Independently audit the mutable-data backfill classifier and fail diagnostics."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path

import yaml


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--git-repo", type=Path, required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite: {args.output}")

    workflow_path = args.snapshot / ".github/workflows/arxiv-daily-push-real-backfill.yml"
    workflow = workflow_path.read_text(encoding="utf-8")
    parsed_yaml = yaml.safe_load(workflow)
    if not isinstance(parsed_yaml, dict) or "jobs" not in parsed_yaml:
        raise AssertionError("workflow did not parse into a jobs mapping")

    match = re.search(r"runtime_regex='([^']+)'", workflow)
    if not match:
        raise AssertionError("runtime_regex was not found")
    runtime_regex = match.group(1)
    classifier = re.compile(runtime_regex)
    matrix = {
        "arxiv-daily-push/src/arxiv_daily_push/pipeline.py": True,
        "arxiv-daily-push/config/source_registry.yaml": True,
        "arxiv-daily-push/schemas/report.schema.json": True,
        "arxiv-daily-push/pyproject.toml": True,
        "arxiv-daily-push/VERSION": True,
        "arxiv-daily-push/.gitignore": True,
        "arxiv-daily-push/tests/test_stage1_real_replay.py": False,
        "arxiv-daily-push/docs/HANDOFF.md": False,
        "arxiv-daily-push/README.md": False,
        "tests/governance/test_adp_canonical_governance_oids.py": False,
        "governance/run_manifests/ADP-example.json": False,
        ".github/workflows/arxiv-daily-push-real-backfill.yml": False,
    }
    matrix_results = {
        path: {"expected": expected, "actual": bool(classifier.search(path))}
        for path, expected in matrix.items()
    }
    matrix_pass = all(item["actual"] == item["expected"] for item in matrix_results.values())

    completed = subprocess.run(
        ["git", "diff", "--name-only", args.base, args.head, "--"],
        cwd=args.git_repo,
        check=True,
        text=True,
        capture_output=True,
    )
    changed_paths = [line for line in completed.stdout.splitlines() if line]
    runtime_matches = [path for path in changed_paths if classifier.search(path)]

    src_unchanged = subprocess.run(
        ["git", "diff", "--quiet", args.base, args.head, "--", "arxiv-daily-push/src"],
        cwd=args.git_repo,
    ).returncode == 0
    quality_gate = (
        args.snapshot / "arxiv-daily-push/src/arxiv_daily_push/stage1_real_replay.py"
    ).read_text(encoding="utf-8")

    artifact_output = "printf 'artifact_dir=%s\\n' \"$artifact_dir\" >> \"$GITHUB_OUTPUT\""
    replay_command = "python3 -m arxiv_daily_push real-historical-arxiv-replay"
    checks = {
        "yaml_parses": True,
        "classifier_matrix_exact": matrix_pass,
        "actual_pr_diff_has_no_runtime_match": not runtime_matches,
        "all_six_runtime_surfaces_trigger": all(
            matrix_results[path]["actual"] for path in list(matrix)[:6]
        ),
        "tests_docs_governance_do_not_trigger": not any(
            matrix_results[path]["actual"] for path in list(matrix)[6:]
        ),
        "heavy_job_requires_classifier_true": "if: needs.runtime-change-scope.outputs.should_run == 'true'" in workflow,
        "manual_dispatch_still_triggers": 'reason="manual dispatch"' in workflow,
        "source_implementation_unchanged": src_unchanged,
        "queue_threshold_not_lowered": (
            'if int(report.get("content_ledger_queued_row_count") or 0) < required:' in quality_gate
            and 'content_ledger_queued_row_count must be at least required_replay_count' in quality_gate
        ),
        "artifact_outputs_exported_before_replay": (
            artifact_output in workflow
            and replay_command in workflow
            and workflow.index(artifact_output) < workflow.index(replay_command)
        ),
        "replay_exit_preserved": (
            "set +e" in workflow
            and "replay_exit=$?" in workflow
            and 'test "$replay_exit" -eq 0' in workflow
        ),
        "blocking_reasons_printed": 'print("blocking_reasons=", report.get("blocking_reasons"))' in workflow,
        "failure_artifact_always_uploaded": "if: always() && steps.replay.outputs.artifact_dir != ''" in workflow,
        "production_side_effect_flags_false": all(
            f'{name}: "false"' in workflow
            for name in (
                "ADP_PRODUCTION_ENABLED",
                "ADP_SCHEDULED_RUN_ENABLED",
                "ADP_ALLOW_SMTP_SEND",
                "ADP_ALLOW_RELEASE_UPLOAD",
            )
        ),
    }
    report = {
        "schema_version": "adp.verifier.backfill_classifier_audit.v1",
        "subject": {"commit": args.head},
        "base": args.base,
        "runtime_regex": runtime_regex,
        "changed_path_count": len(changed_paths),
        "runtime_matches_in_actual_diff": runtime_matches,
        "matrix": matrix_results,
        "checks": checks,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "judgment": (
            "Scoped skip is justified: mutable external-data replay is unchanged and remains strict; "
            "tests/docs/governance-only migration changes are classified without invoking the heavy GET, "
            "while every declared runtime surface and manual dispatch still trigger it."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks": checks}, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
