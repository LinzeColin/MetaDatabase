#!/usr/bin/env python3
"""Compare the public read-only build record with the locked Worker self-hash."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=Path, required=True)
    parser.add_argument("--live-json", type=Path, required=True)
    args = parser.parse_args()
    worker = args.worker.read_text(encoding="utf-8")
    live = json.loads(args.live_json.read_text(encoding="utf-8"))
    match = re.search(
        r"const BUILD = \{ build_id: '([0-9a-f]{12})', "
        r"source_sha256: '([0-9a-f]{64})', schema_version: '([^']+)', "
        r"built_at: '([^']+)' \};",
        worker,
    )
    if match is None:
        raise AssertionError("Worker BUILD identity constant not found")
    build_id, source_sha, schema, built_at = match.groups()
    normalized = worker.replace(source_sha, "0" * 64, 1).replace(build_id, "0" * 12, 1)
    reproduced = hashlib.sha256(normalized.encode("utf-8")).hexdigest()
    expected_live = {
        "build_id": build_id,
        "source_sha256": source_sha,
        "schema_version": schema,
        "built_at": built_at,
    }
    if reproduced != source_sha or not source_sha.startswith(build_id):
        raise AssertionError("locked Worker self-hash does not reproduce")
    if live != expected_live:
        raise AssertionError(f"public build identity mismatch: {live!r} != {expected_live!r}")
    print("PASS: public live build identity matches locked worker self-hash", build_id, source_sha)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
