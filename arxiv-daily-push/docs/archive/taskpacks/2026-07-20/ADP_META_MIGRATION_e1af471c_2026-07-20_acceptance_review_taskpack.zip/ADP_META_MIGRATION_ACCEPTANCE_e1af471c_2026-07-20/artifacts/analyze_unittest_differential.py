#!/usr/bin/env python3
"""Parse raw unittest logs and emit an exact candidate/base differential."""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path


ISSUE_HEADER = re.compile(r"^(ERROR|FAIL): (.+?) \((.+)\)$", re.MULTILINE)
SUMMARY = re.compile(
    r"Ran (?P<total>\d+) tests?.*?FAILED \(failures=(?P<failures>\d+), "
    r"errors=(?P<errors>\d+), skipped=(?P<skipped>\d+)\)",
    re.DOTALL,
)
MISSING_PATH = re.compile(
    r"FileNotFoundError: \[Errno 2\] No such file or directory: '([^']+)'"
)


def parse_log(path: Path) -> dict[str, object]:
    text = path.read_text(encoding="utf-8", errors="replace")
    summary_match = SUMMARY.search(text)
    if not summary_match:
        raise ValueError(f"could not parse unittest summary: {path}")

    headers = list(ISSUE_HEADER.finditer(text))
    issues = []
    for index, match in enumerate(headers):
        block_end = headers[index + 1].start() if index + 1 < len(headers) else len(text)
        block = text[match.start():block_end]
        missing_match = MISSING_PATH.search(block)
        kind = "ERROR" if match.group(1) == "ERROR" else "FAILURE"
        test_name = match.group(2)
        context = match.group(3)
        issues.append(
            {
                "key": f"{kind}|{context}|{test_name}",
                "kind": kind,
                "test_name": test_name,
                "context": context,
                "missing_path": missing_match.group(1) if missing_match else "",
            }
        )

    summary = {key: int(value) for key, value in summary_match.groupdict().items()}
    if summary["failures"] + summary["errors"] != len(issues):
        raise ValueError(
            f"summary/header mismatch for {path}: summary={summary}, headers={len(issues)}"
        )
    return {"summary": summary, "issues": issues}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--subject-commit", required=True)
    parser.add_argument("--subject-tree", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite: {args.output}")

    candidate = parse_log(args.candidate)
    base = parse_log(args.base)
    candidate_keys = {issue["key"] for issue in candidate["issues"]}
    base_keys = {issue["key"] for issue in base["issues"]}
    migration_added = sorted(candidate_keys - base_keys)
    resolved_relative_to_base = sorted(base_keys - candidate_keys)
    missing_path_counts = Counter(
        Path(issue["missing_path"]).name
        for issue in candidate["issues"]
        if issue["missing_path"]
    )

    sealed = {"total": 923, "failures": 3, "errors": 11, "skipped": 62}
    candidate_summary = candidate["summary"]
    report = {
        "schema_version": "adp.verifier.full_suite_differential.v2",
        "subject": {"commit": args.subject_commit, "tree": args.subject_tree},
        "historical_sealed_old_control": {
            **sealed,
            "provenance": "Acceptance Contract and canonical HANDOFF; not the 7fd replay",
            "replay_status": "NOT_RUN_BOUNDARY_EXCLUDES_RESTORING_OLD_CODEXPROJECT_SOURCE",
            "exact_name_set_status": "NOT_AVAILABLE_IN_IMMUTABLE_SUBJECT",
            "comparison_use": "count ceiling plus named historical-debt categories only",
        },
        "candidate_actual": candidate,
        "replayable_migration_base_actual": {
            "commit": "7fd0768002081f27c070561fa855a08713d1bc00",
            "is_historical_sealed_old_control": False,
            "provenance": "fresh exact-commit Python 3.12 replay by independent verifier",
            **base,
        },
        "differential": {
            "candidate_minus_historical_sealed_counts": {
                key: candidate_summary[key] - sealed[key]
                for key in ("total", "failures", "errors", "skipped")
            },
            "candidate_failure_error_set_is_subset_of_replayable_base": not migration_added,
            "migration_added_failure_error_keys_relative_to_replayable_base": migration_added,
            "resolved_failure_error_key_count_relative_to_replayable_base": len(
                resolved_relative_to_base
            ),
            "candidate_missing_file_error_basename_counts": dict(
                sorted(missing_path_counts.items())
            ),
            "candidate_exact_failure_error_allowlist": sorted(candidate_keys),
            "historical_sealed_exact_name_set_comparison": "NOT_RUN_NO_RAW_NAME_SET",
            "no_migration_added_failure_or_error": (
                candidate_summary["total"] == sealed["total"]
                and candidate_summary["failures"] <= sealed["failures"]
                and candidate_summary["errors"] <= sealed["errors"]
                and not migration_added
            ),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report["differential"], ensure_ascii=False, sort_keys=True))
    return 0 if report["differential"]["no_migration_added_failure_or_error"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
