#!/usr/bin/env python3
"""Fail-closed evaluator for PR #68, merge identity, and post-merge gates."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


SUBJECT_COMMIT = "e1af471c4d3dab0044aa47122647c16701d9d095"
SUBJECT_TREE = "de8cfcfbd5b9304409f29250a1e657aa27958dfc"
MERGE_COMMIT = "6d6819bff091e7a83974e92268c171da59625e85"

POLICY_CHECKS = {
    ("dual-plane", "Dual-Plane Governance"),
    ("classify-arxiv-runtime-change", "arXiv Daily Push Stage 1 bootstrap"),
    ("classify-arxiv-runtime-change", "arXiv Daily Push live all-arXiv cloud dry-run"),
    ("classify-arxiv-runtime-change", "arXiv Daily Push real 30-day backfill"),
}

SEMANTIC_CHECKS = {
    ("stage1-bootstrap", "arXiv Daily Push Stage 1 bootstrap"): "SUCCESS",
    ("live-all-arxiv-dry-run", "arXiv Daily Push live all-arXiv cloud dry-run"): "SUCCESS",
    ("real-arxiv-30-day-backfill", "arXiv Daily Push real 30-day backfill"): "SKIPPED",
}


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def run_summary(run: dict) -> dict:
    return {
        "workflow": run.get("workflowName"),
        "status": run.get("status"),
        "conclusion": run.get("conclusion"),
        "event": run.get("event"),
        "head_sha": run.get("headSha"),
        "url": run.get("url"),
        "jobs": [
            {
                "name": job.get("name"),
                "status": job.get("status"),
                "conclusion": job.get("conclusion"),
                "url": job.get("url"),
            }
            for job in run.get("jobs", [])
        ],
    }


def require_run(
    blockers: list[str], run: dict, *, workflow: str, event: str,
    head_sha: str, jobs: dict[str, str], label: str,
) -> None:
    if run.get("workflowName") != workflow:
        blockers.append(f"{label}_workflow_mismatch")
    if run.get("status") != "completed" or run.get("conclusion") != "success":
        blockers.append(f"{label}_run_not_success")
    if run.get("event") != event:
        blockers.append(f"{label}_event_mismatch")
    if run.get("headSha") != head_sha:
        blockers.append(f"{label}_head_mismatch")
    observed = {job.get("name"): job.get("conclusion") for job in run.get("jobs", [])}
    if observed != jobs:
        blockers.append(f"{label}_job_contract_mismatch")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pr-view", type=Path, required=True)
    parser.add_argument("--pr-checks", type=Path, required=True)
    parser.add_argument("--merge-tree", type=Path, required=True)
    parser.add_argument("--main-sha", type=Path, required=True)
    parser.add_argument("--pr-stage1-run", type=Path, required=True)
    parser.add_argument("--pr-live-run", type=Path, required=True)
    parser.add_argument("--pr-backfill-run", type=Path, required=True)
    parser.add_argument("--postmerge-dual-run", type=Path, required=True)
    parser.add_argument("--postmerge-stage1-run", type=Path, required=True)
    parser.add_argument("--classifier-audit", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite: {args.output}")

    pr = load(args.pr_view)
    checks = load(args.pr_checks)
    merge_tree = args.merge_tree.read_text(encoding="utf-8").strip()
    main_sha = args.main_sha.read_text(encoding="utf-8").strip()
    classifier = load(args.classifier_audit)
    pr_stage1 = load(args.pr_stage1_run)
    pr_live = load(args.pr_live_run)
    pr_backfill = load(args.pr_backfill_run)
    post_dual = load(args.postmerge_dual_run)
    post_stage1 = load(args.postmerge_stage1_run)
    blockers: list[str] = []

    if pr.get("state") != "MERGED" or not pr.get("mergedAt"):
        blockers.append("pr_not_merged")
    if pr.get("headRefOid") != SUBJECT_COMMIT:
        blockers.append("pr_head_not_locked_subject")
    if (pr.get("mergeCommit") or {}).get("oid") != MERGE_COMMIT:
        blockers.append("merge_commit_mismatch")
    if merge_tree != SUBJECT_TREE:
        blockers.append("merge_tree_not_subject_tree")
    if main_sha != MERGE_COMMIT:
        blockers.append("main_not_merge_commit")

    observed_checks = {(c.get("name"), c.get("workflow")): c for c in checks}
    if set(observed_checks) != POLICY_CHECKS | set(SEMANTIC_CHECKS):
        blockers.append("unexpected_or_missing_pr_checks")
    for key in sorted(POLICY_CHECKS):
        item = observed_checks.get(key)
        if not item or item.get("state") != "SUCCESS" or item.get("bucket") != "pass":
            blockers.append(f"policy_check_not_success:{key[0]}:{key[1]}")
    for key, expected in sorted(SEMANTIC_CHECKS.items()):
        item = observed_checks.get(key)
        if not item or item.get("state") != expected:
            blockers.append(f"semantic_check_unexpected:{key[0]}:{key[1]}")

    classifier_pass = (
        classifier.get("status") == "PASS"
        and classifier.get("runtime_matches_in_actual_diff") == []
        and classifier.get("checks", {}).get("actual_pr_diff_has_no_runtime_match") is True
        and classifier.get("checks", {}).get("manual_dispatch_still_triggers") is True
    )
    if not classifier_pass:
        blockers.append("classifier_audit_not_pass")

    require_run(
        blockers, pr_stage1,
        workflow="arXiv Daily Push Stage 1 bootstrap", event="pull_request",
        head_sha=SUBJECT_COMMIT,
        jobs={"classify-arxiv-runtime-change": "success", "stage1-bootstrap": "success"},
        label="pr_stage1",
    )
    require_run(
        blockers, pr_live,
        workflow="arXiv Daily Push live all-arXiv cloud dry-run", event="pull_request",
        head_sha=SUBJECT_COMMIT,
        jobs={"classify-arxiv-runtime-change": "success", "live-all-arxiv-dry-run": "success"},
        label="pr_live",
    )
    require_run(
        blockers, pr_backfill,
        workflow="arXiv Daily Push real 30-day backfill", event="pull_request",
        head_sha=SUBJECT_COMMIT,
        jobs={"classify-arxiv-runtime-change": "success", "real-arxiv-30-day-backfill": "skipped"},
        label="pr_backfill",
    )
    require_run(
        blockers, post_dual,
        workflow="Dual-Plane Governance", event="push", head_sha=MERGE_COMMIT,
        jobs={"dual-plane": "success"}, label="postmerge_dual",
    )
    require_run(
        blockers, post_stage1,
        workflow="arXiv Daily Push Stage 1 bootstrap", event="push", head_sha=MERGE_COMMIT,
        jobs={"classify-arxiv-runtime-change": "success", "stage1-bootstrap": "success"},
        label="postmerge_stage1",
    )

    report = {
        "schema_version": "adp.verifier.external_gate.v3",
        "status": "PASS" if not blockers else "BLOCKED",
        "action": "NONE" if not blockers else "ESCALATE",
        "blockers": blockers,
        "subject": {"commit": SUBJECT_COMMIT, "tree": SUBJECT_TREE},
        "merge": {
            "commit": MERGE_COMMIT,
            "tree": merge_tree,
            "main_sha": main_sha,
            "merged_at": pr.get("mergedAt"),
            "identity_closed": not any(
                item in blockers for item in (
                    "pr_not_merged", "pr_head_not_locked_subject", "merge_commit_mismatch",
                    "merge_tree_not_subject_tree", "main_not_merge_commit",
                )
            ),
        },
        "required_policy_checks": [observed_checks.get(key) for key in sorted(POLICY_CHECKS)],
        "semantic_jobs": [observed_checks.get(key) for key in sorted(SEMANTIC_CHECKS)],
        "expected_skip": {
            "job": "real-arxiv-30-day-backfill",
            "reason": "locked PR diff contains no configured ADP runtime path; workflow_dispatch remains an unconditional execution path",
            "classifier_audit_pass": classifier_pass,
            "runtime_matches": classifier.get("runtime_matches_in_actual_diff"),
        },
        "pr_runs": {
            "stage1": run_summary(pr_stage1),
            "live": run_summary(pr_live),
            "backfill": run_summary(pr_backfill),
        },
        "postmerge_runs": {
            "dual_plane": run_summary(post_dual),
            "stage1": run_summary(post_stage1),
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "blockers": blockers}, ensure_ascii=False))
    return 0 if not blockers else 2


if __name__ == "__main__":
    raise SystemExit(main())
