#!/usr/bin/env python3
"""Independent static audit for the locked ADP migration subject."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
from pathlib import Path


def tree_digest(root: Path, paths: list[Path]) -> tuple[int, str]:
    digest = hashlib.sha256()
    files = sorted(path for path in paths if path.is_file())
    for path in files:
        digest.update(path.relative_to(root).as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return len(files), digest.hexdigest()


def git_lines(repo: Path, *args: str) -> list[str]:
    completed = subprocess.run(
        ["git", *args], cwd=repo, text=True, capture_output=True, check=True
    )
    return [line for line in completed.stdout.splitlines() if line]


def scan_added_lines_for_secrets(repo: Path, base: str, head: str) -> dict[str, object]:
    rules = {
        "private_key_block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
        "github_token": re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"),
        "openai_key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}\b"),
        "aws_access_key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    }
    assigned_secret = re.compile(
        r"(?i)(ADP_SMTP_PASSWORD|CLOUDFLARE_API_TOKEN|OPENAI_API_KEY|"
        r"GITHUB_TOKEN|AWS_SECRET_ACCESS_KEY)[\"']?\s*[:=]\s*[\"']([^\"'\s,}]{8,})"
    )
    safe_fragments = (
        "unset", "false", "redact", "replace", "placeholder", "not_configured",
        "none", "null", "${", "{{", "***", "example", "dummy", "fixture",
    )
    process = subprocess.Popen(
        ["git", "diff", "--no-color", "--unified=0", base, head, "--"],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    assert process.stdout is not None
    current_path = ""
    added_line_count = 0
    findings: list[dict[str, str]] = []
    for raw_line in process.stdout:
        if raw_line.startswith("+++ b/"):
            current_path = raw_line[6:].rstrip("\n")
            continue
        if not raw_line.startswith("+") or raw_line.startswith("+++"):
            continue
        added_line_count += 1
        content = raw_line[1:]
        for rule_id, pattern in rules.items():
            if pattern.search(content):
                findings.append({"path": current_path, "rule": rule_id})
        assignment = assigned_secret.search(content)
        if assignment:
            value = assignment.group(2).lower()
            if not any(fragment in value for fragment in safe_fragments):
                findings.append({"path": current_path, "rule": "assigned_secret_value"})
    stderr = process.stderr.read() if process.stderr is not None else ""
    return_code = process.wait()
    if return_code != 0:
        raise RuntimeError(f"git diff secret scan failed: {stderr[-1000:]}")
    unique_findings = sorted({(item["path"], item["rule"]) for item in findings})
    return {
        "scope": f"added lines in {base}..{head}",
        "added_line_count": added_line_count,
        "high_confidence_findings": [
            {"path": path, "rule": rule} for path, rule in unique_findings
        ],
        "status": "PASS" if not unique_findings else "FAIL",
        "note": "Values are never emitted by this scanner.",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--git-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--tree", required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite: {args.output}")

    root = args.snapshot.resolve()
    repo = args.git_repo.resolve()
    handoff = (root / "arxiv-daily-push/docs/HANDOFF.md").read_text(encoding="utf-8")
    root_agents = (root / "AGENTS.md").read_text(encoding="utf-8")
    root_readme = (root / "README.md").read_text(encoding="utf-8")
    project_agents = (root / "arxiv-daily-push/AGENTS.md").read_text(encoding="utf-8")
    project_readme = (root / "arxiv-daily-push/README.md").read_text(encoding="utf-8")

    required_handoff_fragments = [
        "canonical 仓库是 `LinzeColin/MetaDatabase`",
        "CodexProject 中已删除的旧源目录不得恢复",
        "3 个 dormant Cloudflare 资源均删除",
        "`adp-mirror` legacy Worker、`adp-origin` DNS、`adp` Tunnel 均已删除并复核",
        "继续救援剩余来源",
        "science-advances | 走 PubMed 解析层",
        "stats-gov | 继续诊断",
        "Google News | 加重试/退避后评估回切",
        "OVH VPS / Coolify | 不迁",
        "`TASK_INDEX.csv.status` | 不修",
        "在不部署、不改 cron、不引入付费 API 的前提下",
        "有上限的 retry/backoff",
        "确定性夹具和负控",
        "不顺带做 stats-gov 或 PubMed adapter",
        "Python 3.12 运行",
        "macOS 系统 Python 3.9 无法运行当前 ADP 验收入口",
        "迁移线程封存的历史旧控制口径",
        "可重放的 MetaDatabase 迁移前 base",
        "`54 failures + 50 errors + 49 skips`",
        "完整测试\n   名称集合",
    ]
    handoff_missing = [item for item in required_handoff_fragments if item not in handoff]
    root_contract_checks = {
        "root_agents_canonical_route": "canonical 交接入口是 `arxiv-daily-push/docs/HANDOFF.md`" in root_agents,
        "root_agents_no_restore": "禁止从历史、\n  备份或任务包恢复" in root_agents,
        "root_readme_migrated": "| ADP | ✅ 已迁入 | canonical 路径 `arxiv-daily-push/`" in root_readme,
        "project_agents_handoff_priority": "`docs/HANDOFF.md` 是迁入 MetaDatabase 后唯一的当前交接入口" in project_agents,
        "project_agents_no_live_change": "禁止修改或部署 live\nWorker" in project_agents,
        "project_readme_python312": "macOS 系统 Python 3.9 无法运行当前 ADP 验收入口" in project_readme,
        "project_readme_expected_bundle_exit": 'echo "EXPECTED_BUNDLE_EXIT=$ec"; test "$ec" -eq 2' in project_readme,
    }

    bundle_count, bundle_digest = tree_digest(
        root, list((root / "FINAL_ACCEPTANCE_BUNDLE").rglob("*"))
    )
    manifest_paths = list((root / "governance/run_manifests").glob("ADP-*"))
    manifest_count, manifest_digest = tree_digest(root, manifest_paths)
    frontend_archive = root / "arxiv-daily-push/docs/design/前端呈现基线_v1/_原始存档/ADP主题动效v1.1.zip"
    frontend_sha = hashlib.sha256(frontend_archive.read_bytes()).hexdigest()
    worker = root / "arxiv-daily-push/deploy/cloudflare/worker_cloud.js"
    worker_sha = hashlib.sha256(worker.read_bytes()).hexdigest()

    task_index = root / "arxiv-daily-push/docs/pursuing_goal/v0_1/TASK_INDEX.csv"
    with task_index.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    task_status_counts: dict[str, int] = {}
    for row in rows:
        status = row.get("status", "<missing>")
        task_status_counts[status] = task_status_counts.get(status, 0) + 1

    changed_names = git_lines(repo, "diff", "--name-only", args.base, args.head, "--")
    changed_source_paths = [path for path in changed_names if path.startswith("arxiv-daily-push/src/")]
    changed_worker_paths = [path for path in changed_names if path == "arxiv-daily-push/deploy/cloudflare/worker_cloud.js"]
    changed_task_index_paths = [path for path in changed_names if path == "arxiv-daily-push/docs/pursuing_goal/v0_1/TASK_INDEX.csv"]
    prohibited_paths = [
        ".github/workflows/project-governance.yml",
        "governance/repository_hygiene_policy.json",
        "scripts/generate_governance_dashboard.py",
        "scripts/validate_project_governance.py",
        "HANDOFF",
    ]
    prohibited_present = [path for path in prohibited_paths if (root / path).exists()]
    required_root_tools = [
        "tools/validate_task_pack.py",
        "tools/verify_acceptance_bundle.py",
        "tools/verify_daily_operation_readiness.py",
        "tools/verify_daily_operation_enablement_preflight.py",
    ]
    missing_root_tools = [path for path in required_root_tools if not (root / path).is_file()]
    missing_three_base = [
        path for path in ("功能清单.md", "开发记录.md", "模型参数文件.md")
        if not (root / "arxiv-daily-push" / path).exists()
    ]
    secret_scan = scan_added_lines_for_secrets(repo, args.base, args.head)

    checks = {
        "canonical_handoff_complete": not handoff_missing,
        "root_contracts_coherent": all(root_contract_checks.values()),
        "bundle_count_and_digest": bundle_count == 30 and bundle_digest == "fba1d24b53d877c3f0dace82b67f017b70154eb11ff4b88193a2a4537e53d776",
        "manifest_count_and_digest": manifest_count == 424 and manifest_digest == "b268aedd2d9e712bd89fcd6abf7b7609b787d31738dd4d8e70c3611ba2cab64d",
        "frontend_archive_identity": frontend_archive.stat().st_size == 6106 and frontend_sha == "253f7bf6881bd2df377d6a286670f1441b3c093b94de34c7b01f1406dfda91a7",
        "root_compatibility_scope_present": not missing_root_tools,
        "retired_governance_not_restored": not prohibited_present,
        "old_project_source_not_changed_by_closure_commit": not changed_source_paths,
        "worker_not_changed_by_closure_commit": not changed_worker_paths,
        "task_index_not_changed_by_closure_commit": not changed_task_index_paths,
        "task_index_dead_status_shape_preserved": len(rows) == 90 and task_status_counts == {"NOT_STARTED": 90},
        "historical_three_base_absence_confirmed": set(missing_three_base) == {"功能清单.md", "开发记录.md", "模型参数文件.md"},
        "no_high_confidence_secret_in_added_lines": secret_scan["status"] == "PASS",
    }
    report = {
        "schema_version": "adp.verifier.static_contract_audit.v2",
        "subject": {"commit": args.head, "tree": args.tree},
        "base": args.base,
        "checks": checks,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "details": {
            "handoff_missing_fragments": handoff_missing,
            "root_contract_checks": root_contract_checks,
            "bundle": {"count": bundle_count, "tree_digest_sha256": bundle_digest},
            "run_manifests": {"count": manifest_count, "tree_digest_sha256": manifest_digest},
            "frontend_archive": {"size": frontend_archive.stat().st_size, "sha256": frontend_sha},
            "worker_sha256": worker_sha,
            "changed_file_count": len(changed_names),
            "changed_source_paths": changed_source_paths,
            "changed_worker_paths": changed_worker_paths,
            "changed_task_index_paths": changed_task_index_paths,
            "missing_root_tools": missing_root_tools,
            "prohibited_present": prohibited_present,
            "missing_three_base": missing_three_base,
            "task_index_status_counts": task_status_counts,
            "secret_scan": secret_scan,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "checks": checks}, ensure_ascii=False, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
