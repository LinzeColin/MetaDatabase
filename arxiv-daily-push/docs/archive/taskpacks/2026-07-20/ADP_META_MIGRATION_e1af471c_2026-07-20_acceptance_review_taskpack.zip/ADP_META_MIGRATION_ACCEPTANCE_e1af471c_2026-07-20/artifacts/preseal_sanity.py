#!/usr/bin/env python3
"""Independent pre-seal consistency checks for the rendered verifier run."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


FORMAL_FILES = (
    "RUN_MANIFEST.yaml",
    "TRACEABILITY_MATRIX.json",
    "VERDICT.md",
    "TEST_MATRIX.md",
    "DEFECT_REPORT.md",
    "MODIFICATION_REPORT.md",
    "RELEASE_ASSURANCE.md",
    "AI_EVAL_MATRIX.md",
    "HUMAN_JOURNEY.md",
    "ACCEPTANCE_REQUEST.yaml",
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("run_dir", type=Path)
    args = parser.parse_args()
    root = args.run_dir.resolve()
    manifest = json.loads((root / "RUN_MANIFEST.yaml").read_text(encoding="utf-8"))
    matrix = json.loads((root / "TRACEABILITY_MATRIX.json").read_text(encoding="utf-8"))
    request = json.loads((root / "ACCEPTANCE_REQUEST.yaml").read_text(encoding="utf-8"))
    external = json.loads((root / "raw-results/external-gate-final-v2.json").read_text(encoding="utf-8"))

    assert manifest["schema_version"] == "2.1"
    assert manifest["run"]["id"] == "e1af471c_2026-07-20"
    assert manifest["verdict"]["value"] == "PASS"
    assert manifest["verdict"]["action"] == "NONE"
    assert manifest["subject"]["git_head"] == "e1af471c4d3dab0044aa47122647c16701d9d095"
    assert manifest["subject"]["source_snapshot_sha256"] == "5673abfe6ed5bbe02cbc2694294444258bb45212c09cc09549c997ec8d5b219f"
    assert external["status"] == "PASS" and external["blockers"] == []
    assert len(matrix["rows"]) == 7 and all(row["status"] == "PASS" for row in matrix["rows"])
    assert len(matrix["change_impact"]) == 2
    assert request["preferences"]["allow_third_party_write"] is False
    assert request["preferences"]["allow_production_write"] is False

    statuses = {item["test_id"]: item["status"] for item in manifest["results"]}
    assert statuses["BSH-001"] == "NOT_APPLICABLE"
    assert all(status in {"PASS", "NOT_APPLICABLE"} for status in statuses.values())
    assert statuses["CLS-001"] == "PASS" and statuses["EXT-001"] == "PASS"

    referenced: set[str] = set()
    for item in manifest["results"]:
        referenced.update(item.get("evidence_paths", []))
    for row in matrix["rows"]:
        referenced.update(row.get("evidence_paths", []))
    for impact in matrix["change_impact"]:
        referenced.update(impact.get("evidence_paths", []))
    missing = sorted(path for path in referenced if not (root / path).is_file())
    assert missing == [], missing

    placeholder_hits = []
    for name in FORMAL_FILES:
        text = (root / name).read_text(encoding="utf-8")
        for token in ("<fill", "TBD", "TODO", "placeholder"):
            if token.lower() in text.lower():
                placeholder_hits.append(f"{name}:{token}")
    assert placeholder_hits == [], placeholder_hits
    assert (root / "VERDICT.md").read_text(encoding="utf-8").startswith("ACTION: NONE\n")
    assert not list(root.rglob("__pycache__"))
    assert not list(root.rglob("*.pyc"))
    print(
        "PASS: formal run is internally consistent;",
        len(manifest["results"]), "results;", len(matrix["rows"]),
        "trace rows;", len(referenced), "referenced evidence paths",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
