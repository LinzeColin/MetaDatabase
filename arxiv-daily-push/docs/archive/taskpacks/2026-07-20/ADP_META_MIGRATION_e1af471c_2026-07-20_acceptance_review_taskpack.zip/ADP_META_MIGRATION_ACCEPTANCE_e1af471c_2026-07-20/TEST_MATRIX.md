# TEST MATRIX — ADP_META_MIGRATION e1af471c4d3d

- Decision scope：`developer_check`
- Subject identity：`5673abfe6ed5bbe02cbc2694294444258bb45212c09cc09549c997ec8d5b219f`
- Risk / profile：`high / deep`
- Traceability：7 Owner Acceptance rows；change-impact=2
- Baseline：historical sealed 923/3F/11E/62S 与 replayable 7fd 923/54F/50E/49S 分离。

| Test ID | Gate | Blocking | Expected | Actual / Reason | Status | Evidence |
|---|---|---:|---|---|---|---|
| SID-001 | subject_identity | yes | detached clean commit/tree 与 git archive SHA-256 被独立锁定 | commit=e1af471c4d3dab0044aa47122647c16701d9d095; tree=de8cfcfbd5b9304409f29250a1e657aa27958dfc; archive_sha256=5673abfe6ed5bbe02cbc2694294444258bb45212c09cc09549c997ec8d5b219f | PASS | logs/I-001-subject-oids.stdout.log, logs/I-002-subject-status.stdout.log, logs/I-009-subject-archive.command.json, logs/I-010-archive-sha256.stdout.log |
| BSH-001 | build_start_health | yes | developer_check 对治理迁移不要求构建或启动新 runtime | 本 subject 不含 ADP src/Worker 变更且无部署意图；runtime 身份另由 WKR-001 只读核验。 | NOT_APPLICABLE | logs/I-008-no-src-worker-diff.command.json |
| CORE-001 | core_journey | yes | canonical 路由、Owner 决策、下一 Run Contract 与兼容治理合同自洽 | 静态合同审计 PASS；Python 3.12、双 baseline provenance 与 exact test-name-set 比较已锁定 | PASS | raw-results/static-contract-audit.json, raw-results/backfill-classifier-audit.json, logs/G-001-adp-governance-65.command.json, logs/G-001-adp-governance-65.stderr.log, logs/I-006-delta-patch.stdout.log |
| CLS-001 | runtime_change_classifier | yes | 运行时路径与非运行时路径分类精确，manual dispatch 仍强制执行，预期 skip 不放宽 replay/queue/safety 合同 | 472 个实际变更路径 runtime matches=0；6/6 runtime 正向与 6/6 非 runtime 负向矩阵精确；5 个 focused replay tests 通过；real-backfill PR heavy job 为预期 SKIPPED | PASS | raw-results/backfill-classifier-audit.json, logs/C-001-backfill-classifier-audit.command.json, logs/C-002-focused-real-replay-5.command.json, logs/C-002-focused-real-replay-5.stderr.log, raw-results/external-gate-final-v2.json |
| DATA-001 | data_or_output | yes | 30 bundles、424 manifests、前端 ZIP 与 Worker 内容身份不漂移 | 30/424 数量和树摘要匹配；前端 ZIP 6106 bytes 且摘要匹配；Worker SHA-256 匹配 | PASS | raw-results/static-contract-audit.json |
| REG-001 | changed_scope_regression | yes | Python 3.12 full suite 相对历史封存计数与可重放 7fd base 不新增 failure/error | candidate=923/2F/11E/49S; 7fd replay=923/54F/50E/49S; candidate-only exact F/E set=0 | PASS | logs/R-001-full-suite.command.json, logs/R-001-full-suite.stderr.log, logs/R-005-base-full-suite.command.json, logs/R-005-base-full-suite.stderr.log, raw-results/full-suite-differential.json |
| SEC-001 | safety_security | yes | 安全边界、secret scan 与零生产副作用合同通过 | security 14/14；59410 added lines 高置信 secret findings=0；三条生产门保持 fail closed | PASS | logs/G-002-security-boundary.command.json, logs/G-002-security-boundary.stderr.log, raw-results/static-contract-audit.json, logs/G-008-preflight-expected-exit.stdout.log |
| COD-001 | codexproject_absence | yes | CodexProject main 不重新出现 arxiv-daily-push，候选不恢复旧 src | GitHub Contents API=404，local main ls-tree 为空，base→subject src diff 为空 | PASS | logs/E-001-codexproject-main-sha.stdout.log, logs/E-002-codexproject-path-absence.command.json, logs/E-002-codexproject-path-absence.stdout.log, logs/E-006-codexproject-absence-oracle.stdout.log, logs/I-008-no-src-worker-diff.command.json |
| WKR-001 | worker_identity | yes | Worker source 零差异且 public live build.json 与锁定 Worker 自哈希一致 | base→subject Worker diff 为空；live build c2ccc1fd01ec 与 self-excluding SHA-256 一致 | PASS | logs/I-008-no-src-worker-diff.command.json, logs/E-008-live-build-readonly.stdout.log, logs/E-009c-live-build-oracle.stdout.log |
| ENV-001 | environment | yes | 精确 Python 3.12 环境可复现且依赖健康 | CPython 3.12.13 arm64；pip check clean；环境包清单已封存；系统 Python 3.9 不兼容事实已复现 | PASS | logs/X-001-python312-version.stdout.log, logs/X-002-pip-check.stdout.log, logs/X-003-pip-list.stdout.log, logs/X-004-system-python39-version.stdout.log, logs/X-005-system-python39-incompatible.stdout.log |
| NEG-001 | fail_closed_negative_controls | yes | final-bundle、readiness、preflight 三个历史兼容入口均按合同内部 exit=2，shell assertion exit=0 | EXPECTED_BUNDLE_EXIT=2; EXPECTED_READINESS_EXIT=2; EXPECTED_PREFLIGHT_EXIT=2 | PASS | logs/G-006-acceptance-bundle-expected-exit.command.json, logs/G-006-acceptance-bundle-expected-exit.stdout.log, logs/G-007-readiness-expected-exit.command.json, logs/G-007-readiness-expected-exit.stdout.log, logs/G-008-preflight-expected-exit.command.json, logs/G-008-preflight-expected-exit.stdout.log |
| EXT-001 | external_pr_gate | yes | 四个 policy checks 全 SUCCESS；两个适用 heavy jobs SUCCESS；real-backfill heavy job 仅在 runtime diff/manual dispatch 时运行且本次为预期 SKIPPED；PR merged，merge tree/main 身份闭合 | 四个 policy checks（dual-plane + 三个 runtime classifier）全部 SUCCESS；Stage1/live heavy jobs SUCCESS；real-backfill heavy job 因锁定 diff 无 runtime 路径而按合同 SKIPPED；PR 已合并且 merge tree/main 身份闭合。 | PASS | raw-results/external-gate-final-v2.json |

## 适用性

- 功能、数据、集成、边界、兼容、安全、身份、证据：适用并已运行。
- 性能、并发、真人 UI、AI eval、staged/post-deploy：本 developer_check 不适用；无运行时或部署变更。
