ACTION: NONE

# MODIFICATION REPORT — ADP_META_MIGRATION e1af471c4d3d

## ROI 优先级

1. 无代码修补；接受 developer_check 结论。
2. 不扩展迁移契约，不顺带修历史 2F/11E。
3. 下一开发线按 canonical HANDOFF 另开 Google News retry/backoff Run Contract。

## 禁止本轮扩展

- 不改 ADP src/Worker，不部署，不改 cron，不引入付费 API。
- 不恢复 CodexProject 旧目录或根 `HANDOFF/`。
- 不修 `TASK_INDEX.csv.status` 死配置。
