#!/usr/bin/env python3
"""把已冻结 Skill 原样集成到 AgentDatabase；默认只读预检，--apply 才写入。"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

BASELINE_HEAD = "dd338e19ce2e470863e14783c068f194f64c71c4"
TARGET_REL = Path("CodexSkills/registry/codex/equity-event-atlas")
SYNC_REL = Path("CodexSkills/sync_skills.py")
README_REL = Path("CodexSkills/README.md")
INDEX_REL = Path("CodexSkills/index.json")
SLUG = "equity-event-atlas"
ALLOWED_BRANCH = "main"
sys.dont_write_bytecode = True
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")


def run(command: Sequence[str], cwd: Path, *, check: bool = True) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False, env=env)
    if check and result.returncode != 0:
        raise RuntimeError(
            "命令失败：" + " ".join(command) + "\nSTDOUT:\n" + result.stdout + "\nSTDERR:\n" + result.stderr
        )
    return result


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(root: Path) -> str:
    digest = hashlib.sha256()
    if not root.exists():
        return "ABSENT"
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if path.is_symlink():
            raise RuntimeError(f"拒绝符号链接：{path}")
        rel = path.relative_to(root).as_posix()
        digest.update(rel.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def package_root() -> Path:
    return Path(__file__).resolve().parents[3]


def payload_root() -> Path:
    return package_root() / "payload" / TARGET_REL


def git_root(repo: Path) -> Path:
    result = run(["git", "rev-parse", "--show-toplevel"], repo)
    return Path(result.stdout.strip()).resolve()


def inspect_repo(repo: Path) -> Dict[str, Any]:
    root = git_root(repo)
    branch = run(["git", "branch", "--show-current"], root).stdout.strip()
    head = run(["git", "rev-parse", "HEAD"], root).stdout.strip()
    dirty = run(["git", "status", "--porcelain=v1"], root).stdout.splitlines()
    required = [root / "AGENTS.md", root / SYNC_REL, root / "CodexSkills" / "registry" / "codex"]
    missing = [str(path.relative_to(root)) for path in required if not path.exists()]
    agents = (root / "AGENTS.md").read_text(encoding="utf-8") if (root / "AGENTS.md").is_file() else ""
    contract_ok = all(fragment in agents for fragment in ("canonical branch is `main`", "Do not create a temporary remote", "CodexSkills/"))
    return {
        "root": str(root),
        "branch": branch,
        "head": head,
        "baseline_head": BASELINE_HEAD,
        "head_matches_observed_baseline": head == BASELINE_HEAD,
        "dirty": dirty,
        "missing": missing,
        "agent_contract_compatible": contract_ok,
    }


def ensure_preflight(info: Dict[str, Any]) -> None:
    if info["branch"] != ALLOWED_BRANCH:
        raise RuntimeError(f"必须位于 {ALLOWED_BRANCH} 分支，当前为 {info['branch'] or 'DETACHED'}")
    if info["dirty"]:
        raise RuntimeError("工作树不是干净状态；为避免覆盖并行修改，已停止")
    if info["missing"]:
        raise RuntimeError("目标仓库缺少必要路径：" + ", ".join(info["missing"]))
    if not info["agent_contract_compatible"]:
        raise RuntimeError("AGENTS.md 与冻结的安全集成合同不兼容，已停止")


def patch_category(text: str) -> str:
    pattern = re.compile(r'(?P<head>^[ \t]*"业务流程"\s*:\s*\[)(?P<body>[^\]]*)(?P<tail>\])', re.M | re.S)
    matches = list(pattern.finditer(text))
    if len(matches) != 1:
        raise RuntimeError(f"业务流程分类匹配数量不是 1：{len(matches)}；拒绝猜测修改")
    match = matches[0]
    body = match.group("body")
    if f'"{SLUG}"' in body:
        return text
    anchor = '"serenity-skill"'
    if body.count(anchor) != 1:
        raise RuntimeError("业务流程分类结构已漂移，serenity-skill 锚点数量不是 1")
    position = body.index(anchor) + len(anchor)
    new_body = body[:position] + f', "{SLUG}"' + body[position:]
    return text[:match.start("body")] + new_body + text[match.end("body"):]


def validate_payload(source: Path) -> None:
    if not source.is_dir() or source.is_symlink():
        raise RuntimeError("任务包 payload 不存在或不是实际目录")
    required = ["SKILL.md", "VERSION", "MANIFEST.json", "scripts/equity_event_atlas.py"]
    missing = [name for name in required if not (source / name).is_file()]
    if missing:
        raise RuntimeError("payload 缺少文件：" + ", ".join(missing))
    for path in source.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"payload 含符号链接：{path}")
    manifest = json.loads((source / "MANIFEST.json").read_text(encoding="utf-8"))
    rows = manifest.get("files")
    if not isinstance(rows, list):
        raise RuntimeError("payload manifest files 无效")
    declared = set()
    for row in rows:
        relative = Path(row.get("path", ""))
        if relative.is_absolute() or not relative.parts or ".." in relative.parts:
            raise RuntimeError(f"payload manifest 路径不安全：{row.get('path')}")
        normalized = relative.as_posix()
        if normalized in declared:
            raise RuntimeError(f"payload manifest 路径重复：{normalized}")
        declared.add(normalized)
        target = source / relative
        if not target.is_file():
            raise RuntimeError(f"payload manifest 路径不存在：{normalized}")
        if target.stat().st_size != row["bytes"] or sha256_file(target) != row["sha256"]:
            raise RuntimeError(f"payload manifest 不匹配：{normalized}")
    actual = {
        path.relative_to(source).as_posix()
        for path in source.rglob("*")
        if path.is_file() and path.relative_to(source).as_posix() not in {"MANIFEST.json", "SHA256SUMS.txt"}
    }
    if declared != actual:
        raise RuntimeError(f"payload manifest 文件集合不一致：missing={sorted(actual-declared)} extra={sorted(declared-actual)}")
    sums_path = source / "SHA256SUMS.txt"
    if not sums_path.is_file():
        raise RuntimeError("payload 缺少 SHA256SUMS.txt")
    sums = {}
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        digest, separator, relative = line.partition("  ")
        if not separator or relative in sums:
            raise RuntimeError("payload SHA256SUMS.txt 格式或路径重复")
        sums[relative] = digest
    expected_sums = {
        path.relative_to(source).as_posix()
        for path in source.rglob("*")
        if path.is_file() and path.name != "SHA256SUMS.txt"
    }
    if set(sums) != expected_sums:
        raise RuntimeError("payload SHA256SUMS.txt 文件集合不一致")
    for relative, digest in sums.items():
        if sha256_file(source / relative) != digest:
            raise RuntimeError(f"payload SHA256SUMS.txt 不匹配：{relative}")


def create_backup(root: Path, backup_dir: Path) -> Dict[str, Any]:
    backup_dir = backup_dir.resolve()
    if root == backup_dir or root in backup_dir.parents:
        raise RuntimeError("备份目录不得位于目标仓库内部")
    backup_dir.mkdir(parents=True, exist_ok=False)
    records: List[Dict[str, Any]] = []
    for rel in (SYNC_REL, README_REL, INDEX_REL):
        source = root / rel
        record = {"repo_path": rel.as_posix(), "existed": source.exists()}
        if source.exists():
            destination = backup_dir / "files" / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            record.update({"backup_path": destination.relative_to(backup_dir).as_posix(), "sha256": sha256_file(source)})
        records.append(record)
    target = root / TARGET_REL
    target_existed = target.exists()
    if target_existed:
        shutil.copytree(target, backup_dir / "target")
    manifest = {
        "schema": "equity-event-atlas/repo-backup-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "repo_root": str(root),
        "repo_head": run(["git", "rev-parse", "HEAD"], root).stdout.strip(),
        "target_rel": TARGET_REL.as_posix(),
        "target_existed": target_existed,
        "target_tree_sha256": tree_hash(target),
        "files": records,
    }
    (backup_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return manifest


def restore_snapshot(root: Path, snapshots: Dict[Path, Optional[bytes]], target_existed: bool, target_backup: Optional[Path]) -> None:
    target = root / TARGET_REL
    if target.exists():
        shutil.rmtree(target)
    if target_existed and target_backup and target_backup.is_dir():
        shutil.copytree(target_backup, target)
    for rel, content in snapshots.items():
        path = root / rel
        if content is None:
            if path.exists():
                path.unlink()
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)


def load_sync_module(sync_path: Path, root: Path):
    module_name = "equity_event_atlas_repo_sync"
    spec = importlib.util.spec_from_file_location(module_name, sync_path)
    if not spec or not spec.loader:
        raise RuntimeError("无法加载 sync_skills.py")
    module = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(root))
    try:
        spec.loader.exec_module(module)
    finally:
        if sys.path and sys.path[0] == str(root):
            sys.path.pop(0)
    return module


def rebuild_generated_indexes(root: Path) -> Dict[str, Any]:
    module = load_sync_module(root / SYNC_REL, root)
    registry = root / "CodexSkills" / "registry"
    catalog = root / "CodexSkills"
    hits = module.credential_gate(str(registry), expected_aliases=module.EXPECTED_SOURCE_ALIASES)
    if hits:
        raise RuntimeError("仓库凭据门命中，已停止：" + json.dumps(hits[:10], ensure_ascii=False))
    count, unique, orphan = module.build_index(str(registry), str(catalog))
    if SLUG in orphan:
        raise RuntimeError("新 Skill 仍处于未归类状态")
    return {"skill_instances": count, "unique_slugs": unique, "orphan_count": len(orphan)}


def run_skill_checks(root: Path) -> Dict[str, Any]:
    skill = root / TARGET_REL
    script = skill / "scripts" / "equity_event_atlas.py"
    ast.parse(script.read_text(encoding="utf-8"), filename=str(script))
    test_result = run([
        sys.executable, "-B", "-m", "unittest", "discover", "-s", str(skill / "tests"), "-p", "test_*.py", "-v"
    ], root)
    self_result = run([
        sys.executable, "-B", str(script), "self-test", "--fixtures", str(skill / "fixtures"), "--repeat", "3"
    ], root)
    return {
        "syntax": "PASS",
        "unit_tests": test_result.returncode,
        "self_test": json.loads(self_result.stdout),
    }


def catalog_check(root: Path) -> Dict[str, Any]:
    tool = root / "CodexSkills" / "governance" / "tools" / "build_bound_reference_resolver.py"
    if not tool.is_file():
        return {"status": "NOT_AVAILABLE", "blocking": False}
    result = run([sys.executable, "-B", str(tool), "--check"], root, check=False)
    return {
        "status": "PASS" if result.returncode == 0 else "NOT_PROVEN",
        "blocking": False,
        "returncode": result.returncode,
        "stdout_tail": result.stdout[-2000:],
        "stderr_tail": result.stderr[-2000:],
        "note": "现有 _catalog 为仓库治理派生面；本任务不手工伪造目录身份或信任记录。",
    }


def apply_integration(root: Path, backup_dir: Path) -> Dict[str, Any]:
    source = payload_root()
    validate_payload(source)
    target = root / TARGET_REL
    if target.exists() and tree_hash(target) != tree_hash(source):
        raise RuntimeError("目标 Skill 已存在且内容不同；本版本拒绝静默替换")
    backup_manifest = create_backup(root, backup_dir)
    snapshots = {
        rel: (root / rel).read_bytes() if (root / rel).exists() else None
        for rel in (SYNC_REL, README_REL, INDEX_REL)
    }
    target_existed = target.exists()
    target_backup = backup_dir / "target" if target_existed else None
    try:
        sync_path = root / SYNC_REL
        patched = patch_category(sync_path.read_text(encoding="utf-8"))
        sync_path.write_text(patched, encoding="utf-8", newline="\n")
        ast.parse(patched, filename=str(sync_path))
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            temporary = target.parent / f".{SLUG}.install-{os.getpid()}"
            if temporary.exists():
                shutil.rmtree(temporary)
            shutil.copytree(source, temporary)
            os.replace(temporary, target)
        index_result = rebuild_generated_indexes(root)
        checks = run_skill_checks(root)
        diff_check = run(["git", "diff", "--check"], root)
        changed = run(["git", "status", "--short"], root).stdout.splitlines()
        catalog = catalog_check(root)
        return {
            "status": "PASS",
            "repo": str(root),
            "backup_dir": str(backup_dir),
            "backup_manifest": backup_manifest,
            "index": index_result,
            "checks": checks,
            "git_diff_check": diff_check.returncode,
            "changed": changed,
            "catalog_check": catalog,
            "commit_or_push_performed": False,
        }
    except Exception:
        restore_snapshot(root, snapshots, target_existed, target_backup)
        raise


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="股票事件航图目标仓库集成器")
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--apply", action="store_true", help="通过预检后执行原子写入；默认只读")
    parser.add_argument("--backup-dir", type=Path, help="仓库外备份目录；不提供时自动创建在仓库父目录")
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        info = inspect_repo(args.repo.resolve())
        ensure_preflight(info)
        source = payload_root()
        validate_payload(source)
        root = Path(info["root"])
        target = root / TARGET_REL
        plan = {
            "status": "READY",
            "mode": "APPLY" if args.apply else "DRY_RUN",
            "preflight": info,
            "payload_tree_sha256": tree_hash(source),
            "target_tree_sha256": tree_hash(target),
            "target": TARGET_REL.as_posix(),
            "planned_repo_paths": [
                TARGET_REL.as_posix(), SYNC_REL.as_posix(), README_REL.as_posix(), INDEX_REL.as_posix()
            ],
            "catalog_write_planned": False,
            "commit_or_push_planned_by_script": False,
        }
        if not args.apply:
            print(json.dumps(plan, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        backup = args.backup_dir or (root.parent / f"equity-event-atlas-backup-{timestamp}")
        result = apply_integration(root, backup)
        result["preflight"] = info
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
