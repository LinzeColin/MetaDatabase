#!/usr/bin/env python3
"""验证目标仓库中的股票事件航图已按冻结合同集成。"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

TARGET = Path("CodexSkills/registry/codex/equity-event-atlas")
ALLOWED_CHANGED_PREFIXES = (
    "CodexSkills/registry/codex/equity-event-atlas/",
    "CodexSkills/sync_skills.py",
    "CodexSkills/README.md",
    "CodexSkills/index.json",
)
sys.dont_write_bytecode = True
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")


def run(command: Sequence[str], cwd: Path, check: bool = True) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False, env=env)
    if check and result.returncode != 0:
        raise RuntimeError("命令失败：" + " ".join(command) + "\n" + result.stdout + "\n" + result.stderr)
    return result


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify(repo: Path) -> Dict[str, Any]:
    root = Path(run(["git", "rev-parse", "--show-toplevel"], repo).stdout.strip()).resolve()
    skill = root / TARGET
    errors: List[str] = []
    if not skill.is_dir() or skill.is_symlink():
        errors.append("目标 Skill 目录不存在或为符号链接")
        return {"status": "FAIL", "errors": errors}
    manifest_path = skill / "MANIFEST.json"
    if not manifest_path.is_file():
        errors.append("缺少 MANIFEST.json")
    else:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        rows = manifest.get("files")
        if not isinstance(rows, list):
            errors.append("Manifest files 无效")
            rows = []
        declared = set()
        for row in rows:
            relative = Path(row.get("path", ""))
            if relative.is_absolute() or not relative.parts or ".." in relative.parts:
                errors.append(f"Manifest 路径不安全：{row.get('path')}")
                continue
            normalized = relative.as_posix()
            if normalized in declared:
                errors.append(f"Manifest 路径重复：{normalized}")
                continue
            declared.add(normalized)
            path = skill / relative
            if not path.is_file():
                errors.append(f"Manifest 路径不存在：{normalized}")
            elif path.stat().st_size != row["bytes"] or sha256_file(path) != row["sha256"]:
                errors.append(f"Manifest 不匹配：{normalized}")
        actual = {
            path.relative_to(skill).as_posix()
            for path in skill.rglob("*")
            if path.is_file() and path.relative_to(skill).as_posix() not in {"MANIFEST.json", "SHA256SUMS.txt"}
        }
        if declared != actual:
            errors.append("Manifest 文件集合不一致")
    sync_text = (root / "CodexSkills" / "sync_skills.py").read_text(encoding="utf-8")
    if '"equity-event-atlas"' not in sync_text:
        errors.append("sync_skills.py 未登记分类")
    index = json.loads((root / "CodexSkills" / "index.json").read_text(encoding="utf-8"))
    rows = [row for row in index.get("skills", []) if row.get("source") == "codex" and row.get("slug") == "equity-event-atlas"]
    if len(rows) != 1:
        errors.append(f"index.json 目标条目数量不是 1：{len(rows)}")
    elif rows[0].get("category") != "业务流程":
        errors.append("index.json 分类不是业务流程")
    readme = (root / "CodexSkills" / "README.md").read_text(encoding="utf-8")
    if "equity-event-atlas" not in readme or "股票事件航图" not in readme:
        errors.append("README.md 未生成目标索引内容")
    changed = run(["git", "status", "--short"], root).stdout.splitlines()
    unauthorized = []
    for line in changed:
        path = line[3:] if len(line) >= 4 else line
        if not any(path == prefix or path.startswith(prefix) for prefix in ALLOWED_CHANGED_PREFIXES):
            unauthorized.append(path)
    if unauthorized:
        errors.append("存在任务范围外修改：" + ", ".join(unauthorized))
    if any("CodexSkills/_catalog/" in line for line in changed):
        errors.append("检测到未经授权的 _catalog 手工修改")
    script = skill / "scripts" / "equity_event_atlas.py"
    try:
        ast.parse(script.read_text(encoding="utf-8"), filename=str(script))
    except SyntaxError as exc:
        errors.append("Skill 脚本语法失败：" + str(exc))
    if not errors:
        run([sys.executable, "-B", "-m", "unittest", "discover", "-s", str(skill / "tests"), "-p", "test_*.py", "-v"], root)
        run([sys.executable, "-B", str(script), "self-test", "--fixtures", str(skill / "fixtures"), "--repeat", "3"], root)
        run(["git", "diff", "--check"], root)
    return {
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "changed": changed,
        "target": TARGET.as_posix(),
        "commit_or_push_performed": False,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="验证股票事件航图仓库集成")
    parser.add_argument("--repo", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        result = verify(args.repo.resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0 if result["status"] == "PASS" else 1
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
