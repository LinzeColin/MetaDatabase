#!/usr/bin/env python3
"""在提交前使用外部备份恢复集成前状态；提交后应使用普通 git revert。"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional, Sequence


def run(command, cwd: Path):
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, check=False)
    if result.returncode != 0:
        raise RuntimeError("命令失败：" + " ".join(command) + "\n" + result.stdout + "\n" + result.stderr)
    return result


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return digest


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="回滚股票事件航图未提交集成")
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--backup-dir", required=True, type=Path)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args(argv)
    try:
        root = Path(run(["git", "rev-parse", "--show-toplevel"], args.repo.resolve()).stdout.strip()).resolve()
        backup = args.backup_dir.resolve()
        manifest_path = backup / "manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if Path(manifest["repo_root"]).resolve() != root:
            raise RuntimeError("备份不属于当前目标仓库")
        plan = {
            "status": "READY",
            "mode": "APPLY" if args.apply else "DRY_RUN",
            "repo": str(root),
            "backup": str(backup),
            "target": manifest["target_rel"],
        }
        if not args.apply:
            print(json.dumps(plan, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        target = root / manifest["target_rel"]
        if target.exists():
            shutil.rmtree(target)
        if manifest.get("target_existed"):
            shutil.copytree(backup / "target", target)
        for row in manifest.get("files", []):
            destination = root / row["repo_path"]
            if row.get("existed"):
                source = backup / row["backup_path"]
                if sha256_file(source) != row["sha256"]:
                    raise RuntimeError(f"备份哈希不匹配：{row['repo_path']}")
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
            elif destination.exists():
                destination.unlink()
        run(["git", "diff", "--check"], root)
        print(json.dumps({**plan, "status": "PASS"}, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
