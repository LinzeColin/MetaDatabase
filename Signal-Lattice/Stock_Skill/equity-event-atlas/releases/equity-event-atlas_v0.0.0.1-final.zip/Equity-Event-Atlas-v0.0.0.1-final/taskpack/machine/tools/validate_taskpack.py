#!/usr/bin/env python3
"""验证股票事件航图最终任务包的 DAG、追踪、语法、安全与 Manifest。"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple


class CheckFailure(Exception):
    pass


def package_root() -> Path:
    return Path(__file__).resolve().parents[3]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CheckFailure(f"JSON 无效：{path}: {exc}") from exc


def iter_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise CheckFailure(f"任务包包含符号链接：{path.relative_to(root)}")
        if path.is_file():
            yield path


def check_no_junk(root: Path) -> None:
    forbidden_names = {"__pycache__", ".pytest_cache", ".mypy_cache", ".DS_Store", "Thumbs.db", "node_modules", ".venv"}
    forbidden_suffixes = {".pyc", ".pyo", ".swp", ".tmp"}
    for path in root.rglob("*"):
        if path.name in forbidden_names or path.suffix in forbidden_suffixes:
            raise CheckFailure(f"任务包含缓存或构建垃圾：{path.relative_to(root)}")


def check_text_hygiene(root: Path) -> None:
    markers = ["TO" + "DO", "T" + "BD", "FIX" + "ME"]
    fake_domains = ["example" + ".com", "." + "example", "invalid" + ".local"]
    secret_patterns = [
        re.compile(rb"sk-[A-Za-z0-9]{20,}"),
        re.compile(rb"sk-ant-[A-Za-z0-9_-]{20,}"),
        re.compile(rb"\b(?:ghp|gho|ghu|ghs)_[A-Za-z0-9]{20,}"),
        re.compile(rb"\bgithub_pat_[A-Za-z0-9_]{20,}"),
        re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
        re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    ]
    text_suffixes = {".md", ".txt", ".json", ".py", ".yaml", ".yml", ".sql", ".sh", ".mmd", ".svg"}
    for path in iter_files(root):
        data = path.read_bytes()
        for pattern in secret_patterns:
            if pattern.search(data):
                raise CheckFailure(f"检测到疑似真实凭据：{path.relative_to(root)}")
        if path.suffix.lower() not in text_suffixes and path.name not in {"VERSION", "SHA256SUMS.txt"}:
            continue
        text = data.decode("utf-8", errors="strict")
        for marker in markers:
            if re.search(rf"\b{re.escape(marker)}\b", text):
                raise CheckFailure(f"检测到未完成标记 {marker}：{path.relative_to(root)}")
        lowered = text.lower()
        for domain in fake_domains:
            if domain in lowered:
                raise CheckFailure(f"检测到非真实域名：{path.relative_to(root)}")
        conflict_markers = ["<" * 7, ">" * 7, "=" * 7]
        if any(marker in text for marker in conflict_markers):
            raise CheckFailure(f"检测到未解决合并冲突：{path.relative_to(root)}")


def check_syntax(root: Path) -> Dict[str, int]:
    counts = {"python": 0, "json": 0, "shell": 0, "skill_frontmatter": 0}
    for path in iter_files(root):
        if path.suffix == ".py":
            try:
                ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            except SyntaxError as exc:
                raise CheckFailure(f"Python 语法错误：{path.relative_to(root)}: {exc}") from exc
            counts["python"] += 1
        elif path.suffix == ".json":
            load_json(path)
            counts["json"] += 1
        elif path.suffix == ".sh":
            result = subprocess.run(["bash", "-n", str(path)], text=True, capture_output=True, check=False)
            if result.returncode != 0:
                raise CheckFailure(f"Shell 语法错误：{path.relative_to(root)}: {result.stderr}")
            counts["shell"] += 1
    skill = root / "payload" / "CodexSkills" / "registry" / "codex" / "equity-event-atlas" / "SKILL.md"
    text = skill.read_text(encoding="utf-8")
    if not text.startswith("---\n") or "\n---\n" not in text[4:]:
        raise CheckFailure("SKILL.md 缺少有效 frontmatter")
    frontmatter = text.split("\n---\n", 1)[0]
    for key in ("name:", "description:", "compatibility:", "display_name_zh:", "version:"):
        if key not in frontmatter:
            raise CheckFailure(f"SKILL.md frontmatter 缺少 {key}")
    counts["skill_frontmatter"] = 1
    return counts


def check_dag(root: Path) -> Dict[str, Any]:
    value = load_json(root / "taskpack" / "machine" / "task_dag.json")
    tasks = value.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        raise CheckFailure("Task DAG 为空")
    by_id: Dict[str, Mapping[str, Any]] = {}
    for task in tasks:
        task_id = task.get("id")
        if not isinstance(task_id, str) or not task_id:
            raise CheckFailure("Task ID 无效")
        if task_id in by_id:
            raise CheckFailure(f"Task ID 重复：{task_id}")
        by_id[task_id] = task
        if task.get("category") not in {"research", "implementation", "test", "remediation", "review", "release"}:
            raise CheckFailure(f"Task category 无效：{task_id}")
        if len(task.get("steps", [])) > 5:
            raise CheckFailure(f"Task 步骤超过五项：{task_id}")
    indegree = {task_id: 0 for task_id in by_id}
    edges = {task_id: [] for task_id in by_id}
    for task_id, task in by_id.items():
        dependencies = task.get("depends_on", [])
        if task_id != "RS-01" and not dependencies:
            raise CheckFailure(f"存在孤立关键 Task：{task_id}")
        for dep in dependencies:
            if dep not in by_id:
                raise CheckFailure(f"Task {task_id} 缺少依赖 {dep}")
            indegree[task_id] += 1
            edges[dep].append(task_id)
    queue = sorted(task_id for task_id, degree in indegree.items() if degree == 0)
    visited: List[str] = []
    while queue:
        current = queue.pop(0)
        visited.append(current)
        for target in edges[current]:
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
                queue.sort()
    if len(visited) != len(by_id):
        raise CheckFailure("Task DAG 存在循环")
    if value.get("real_time_wait_nodes") != 0 or value.get("dynamic_approval_nodes") != 0:
        raise CheckFailure("Task DAG 含真实时间等待或重复审批节点")
    categories = {task["category"] for task in tasks}
    required_categories = {"research", "implementation", "test", "remediation", "review", "release"}
    if categories != required_categories:
        raise CheckFailure("Task DAG 未覆盖六类任务")
    return {"task_count": len(tasks), "topological_order": visited, "categories": sorted(categories)}


def check_traceability(root: Path, task_ids: Set[str]) -> Dict[str, Any]:
    acceptance = load_json(root / "taskpack" / "machine" / "acceptance_contract.json")
    if acceptance.get("frozen") is not True:
        raise CheckFailure("Acceptance Contract 未冻结")
    requirements = acceptance.get("requirements", [])
    requirement_ids = [row.get("id") for row in requirements]
    if len(requirement_ids) != len(set(requirement_ids)) or len(requirement_ids) != 20:
        raise CheckFailure("验收要求必须唯一且为 20 条")
    trace = load_json(root / "taskpack" / "machine" / "traceability_matrix.json")
    rows = trace.get("rows", [])
    trace_ids = [row.get("requirement_id") for row in rows]
    if set(trace_ids) != set(requirement_ids) or len(trace_ids) != len(requirement_ids):
        raise CheckFailure("追踪矩阵没有精确覆盖所有验收要求")
    checked_paths = 0
    for row in rows:
        if not row.get("task_ids") or any(task_id not in task_ids for task_id in row["task_ids"]):
            raise CheckFailure(f"追踪矩阵 Task 引用无效：{row.get('requirement_id')}")
        if not row.get("oracle"):
            raise CheckFailure(f"追踪矩阵缺少 Oracle：{row.get('requirement_id')}")
        for group in ("tests", "evidence", "artifacts"):
            values = row.get(group)
            if not isinstance(values, list) or not values:
                raise CheckFailure(f"追踪矩阵缺少 {group}：{row.get('requirement_id')}")
            for relative in values:
                path = root / relative
                if not path.exists():
                    raise CheckFailure(f"追踪路径不存在：{relative}")
                checked_paths += 1
    return {"requirements": len(requirements), "rows": len(rows), "paths_checked": checked_paths}


def check_manifest(root: Path, manifest_path: Path, base: Path, exclusions: Set[str]) -> Dict[str, Any]:
    manifest = load_json(manifest_path)
    rows = manifest.get("files")
    if not isinstance(rows, list):
        raise CheckFailure(f"Manifest files 无效：{manifest_path.relative_to(root)}")
    paths = [row.get("path") for row in rows]
    if len(paths) != len(set(paths)):
        raise CheckFailure(f"Manifest 路径重复：{manifest_path.relative_to(root)}")
    expected = {
        path.relative_to(base).as_posix()
        for path in iter_files(base)
        if path.relative_to(base).as_posix() not in exclusions
    }
    if set(paths) != expected:
        missing = sorted(expected - set(paths))
        extra = sorted(set(paths) - expected)
        raise CheckFailure(f"Manifest 文件集合不一致：missing={missing[:10]} extra={extra[:10]}")
    for row in rows:
        path = base / row["path"]
        if path.stat().st_size != row.get("bytes") or sha256_file(path) != row.get("sha256"):
            raise CheckFailure(f"Manifest 大小或哈希不匹配：{path.relative_to(root)}")
    return {"file_count": len(rows), "manifest": manifest_path.relative_to(root).as_posix()}


def check_sums(root: Path, sums_path: Path, exclusions: Set[str]) -> Dict[str, Any]:
    rows: Dict[str, str] = {}
    for line in sums_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, separator, relative = line.partition("  ")
        if not separator or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise CheckFailure(f"SHA256SUMS 行无效：{line}")
        if relative in rows:
            raise CheckFailure(f"SHA256SUMS 路径重复：{relative}")
        rows[relative] = digest
    base = sums_path.parent
    expected = {
        path.relative_to(base).as_posix()
        for path in iter_files(base)
        if path.relative_to(base).as_posix() not in exclusions
    }
    if set(rows) != expected:
        raise CheckFailure(f"SHA256SUMS 文件集合不一致：{sums_path.relative_to(root)}")
    for relative, digest in rows.items():
        if sha256_file(base / relative) != digest:
            raise CheckFailure(f"SHA256SUMS 不匹配：{relative}")
    return {"file_count": len(rows), "sums": sums_path.relative_to(root).as_posix()}


def run_frozen_tests(root: Path) -> Dict[str, Any]:
    skill = root / "payload" / "CodexSkills" / "registry" / "codex" / "equity-event-atlas"
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    unit = subprocess.run(
        [sys.executable, "-B", "-m", "unittest", "discover", "-s", str(skill / "tests"), "-p", "test_*.py", "-v"],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    if unit.returncode != 0:
        raise CheckFailure("冻结单元测试失败：\n" + unit.stdout + "\n" + unit.stderr)
    self_test = subprocess.run(
        [sys.executable, "-B", str(skill / "scripts" / "equity_event_atlas.py"), "self-test", "--fixtures", str(skill / "fixtures"), "--repeat", "3"],
        cwd=root, env=env, text=True, capture_output=True, check=False,
    )
    if self_test.returncode != 0:
        raise CheckFailure("Skill self-test 失败：\n" + self_test.stdout + "\n" + self_test.stderr)
    payload = json.loads(self_test.stdout)
    if payload.get("status") != "PASS":
        raise CheckFailure("Skill self-test 未返回 PASS")
    return {"unit_tests": "PASS", "self_test": payload}


def validate(root: Path) -> Dict[str, Any]:
    check_no_junk(root)
    check_text_hygiene(root)
    syntax = check_syntax(root)
    dag_result = check_dag(root)
    task_ids = set(dag_result["topological_order"])
    trace = check_traceability(root, task_ids)
    canonical = load_json(root / "taskpack" / "machine" / "canonical_facts.json")
    if canonical.get("scope_frozen") is not True or canonical.get("acceptance_frozen") is not True:
        raise CheckFailure("Canonical Facts 未冻结 Scope 或 Acceptance")
    estimate = load_json(root / "taskpack" / "machine" / "estimate.json")
    if estimate.get("acceptance_set") != "FROZEN":
        raise CheckFailure("成本估算未绑定冻结验收集")
    review = load_json(root / "taskpack" / "machine" / "review_record.json")
    if review.get("independent_reviewer_count") != 0 or review.get("formal_independent_2x6") != "NOT_PROVEN_NON_BLOCKING":
        raise CheckFailure("Reviewer 独立性状态不诚实")
    tests = run_frozen_tests(root)
    manifests = []
    skill = root / "payload" / "CodexSkills" / "registry" / "codex" / "equity-event-atlas"
    if (skill / "MANIFEST.json").exists():
        manifests.append(check_manifest(root, skill / "MANIFEST.json", skill, {"MANIFEST.json", "SHA256SUMS.txt"}))
    if (skill / "SHA256SUMS.txt").exists():
        manifests.append(check_sums(root, skill / "SHA256SUMS.txt", {"SHA256SUMS.txt"}))
    if (root / "DELIVERY_MANIFEST.json").exists():
        manifests.append(check_manifest(root, root / "DELIVERY_MANIFEST.json", root, {"DELIVERY_MANIFEST.json", "SHA256SUMS.txt"}))
    if (root / "SHA256SUMS.txt").exists():
        manifests.append(check_sums(root, root / "SHA256SUMS.txt", {"SHA256SUMS.txt"}))
    return {
        "status": "PASS",
        "root": str(root),
        "syntax": syntax,
        "dag": dag_result,
        "traceability": trace,
        "tests": tests,
        "manifests": manifests,
        "blocking_findings": 0,
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="验证股票事件航图最终任务包")
    parser.add_argument("--root", type=Path, default=package_root())
    args = parser.parse_args(argv)
    try:
        result = validate(args.root.resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (CheckFailure, OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
