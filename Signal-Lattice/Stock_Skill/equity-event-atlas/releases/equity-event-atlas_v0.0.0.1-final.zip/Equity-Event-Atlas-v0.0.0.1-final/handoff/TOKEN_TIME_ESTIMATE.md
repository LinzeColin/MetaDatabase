# Token 与墙钟估算

验收集：`FROZEN`。

| 情景 | P50 tokens / 时间 | P80 | P95 | 说明 |
|---|---:|---:|---:|---|
| Bounded | 9k / 18m | 18k / 32m | 30k / 50m | 预检、原样集成、验证、commit/push |
| Frozen Full Acceptance | 18k / 35m | 36k / 65m | 62k / 105m | 加一次整改和完整仓库复核 |
| Pursuing Goal | 无有限上界 | 无有限上界 | 无有限上界 | 动态追求全球最优属于 OPEN_ENDED |

时间为目标环境顺利时的估算，不是承诺。active/wait、重试系数、Stage 明细、五大成本驱动和超过 30% 的变化触发条件见 `taskpack/machine/estimate.json`。
