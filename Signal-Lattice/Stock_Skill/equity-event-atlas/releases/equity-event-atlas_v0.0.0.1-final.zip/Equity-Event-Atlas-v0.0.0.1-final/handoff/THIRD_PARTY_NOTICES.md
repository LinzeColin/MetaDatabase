# 第三方与官方来源采用说明

## 运行代码

本 Skill 的可执行代码只使用 Python 标准库；没有打包或复制第三方库。

## 研究对象

| 对象 | 观察版本/引用 | 许可/条款 | 使用方式 |
|---|---|---|---|
| SEC EDGAR APIs | 官方实时接口，访问日 2026-07-26 | 官方数据条款 | 美国 T0 来源政策 |
| ASX / ASIC | 官方页面，访问日 2026-07-26 | 官方站点条款 | ASX T0 来源政策 |
| EdgarTools | 5.43.0 | MIT | 未来可选 SEC 解析 Adapter；未引入 |
| Stock Pilot | 0.2.2 | MIT | 借鉴只读、新鲜度与三情景；未复制 |
| OpenBB | 4.7.0 / dddc3b3 | AGPL-3.0-only | 只借鉴 Provider 分层；拒绝依赖 |
| exchange_calendars | 4.13.2 / dbe38b1 | Apache-2.0 | 宿主未来可选日历 Adapter |
| vectorbt | v1.1.0 / 259d2d8 | Apache-2.0 with Commons Clause | 只借鉴事件研究思想；拒绝依赖 |

准确 URL、采用范围和拒绝理由以 `taskpack/machine/research_adoption.json` 为准。
