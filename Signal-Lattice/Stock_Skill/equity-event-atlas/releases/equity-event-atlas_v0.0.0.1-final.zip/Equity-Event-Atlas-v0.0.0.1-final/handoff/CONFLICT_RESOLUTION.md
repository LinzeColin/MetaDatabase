# 冲突解决

唯一顺序：

1. 用户当前线程最新明确要求；
2. 用户指定基础设施和数据治理事实；
3. 目标仓库适用 AGENTS、贡献、部署和安全规则；
4. 本任务包 Canonical Facts 与 Acceptance Contract；
5. 官方文档；
6. 锁定版本/Tag/commit 的第三方项目；
7. 旧任务包、旧 handover 和历史讨论；
8. Agent 推断。

低优先级不得覆盖高优先级。独立软件、全球默认同深度等旧方案已标记 `SUPERSEDED`。
