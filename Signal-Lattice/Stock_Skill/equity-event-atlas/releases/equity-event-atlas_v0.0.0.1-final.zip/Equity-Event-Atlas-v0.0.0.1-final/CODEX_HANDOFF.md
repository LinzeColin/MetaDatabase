# Codex 原样落库手册

## 你的唯一职责

将 ChatGPT 已准备并验证的文件原样落入 `LinzeColin/AgentDatabase`，执行冻结测试，普通 commit、fast-forward-safe push，并返回真实事实。不得重新研究、重写产品、增加功能、创建临时远端分支或 PR。

## 0. 冲突顺序

严格读取 `taskpack/machine/canonical_facts.json` 的顺序。目标仓库当前 `AGENTS.md` 高于任务包普通实施说明；如两者出现实质冲突，停止并只报告最小冲突证据。

## 1. 把 ZIP 解压到目标仓库外

以下变量仅示意本地路径，替换为实际解压位置和 checkout：

```bash
export EEA_PACKAGE="/absolute/path/Equity-Event-Atlas-v0.0.0.1-final"
export AGENT_DB="/absolute/path/AgentDatabase"
```

## 2. 先验证任务包

```bash
python3 "$EEA_PACKAGE/verify_delivery.py"
python3 "$EEA_PACKAGE/taskpack/machine/tools/validate_taskpack.py"
```

两者必须为 `PASS`。失败时不得落库。

## 3. 只读目标仓库预检

```bash
python3 "$EEA_PACKAGE/taskpack/machine/tools/integrate_into_repo.py" \
  --repo "$AGENT_DB" \
  | tee "$EEA_PACKAGE/codex-preflight.json"
```

验收：

- branch=`main`；
- working tree clean；
- AGENTS 合同兼容；
- planned paths 仅为：
  - `CodexSkills/registry/codex/equity-event-atlas/`
  - `CodexSkills/sync_skills.py`
  - `CodexSkills/README.md`
  - `CodexSkills/index.json`
- 不计划写 `CodexSkills/_catalog/`；
- 脚本不 commit、不 push。

## 4. 原子集成

```bash
python3 "$EEA_PACKAGE/taskpack/machine/tools/integrate_into_repo.py" \
  --repo "$AGENT_DB" \
  --apply \
  | tee "$EEA_PACKAGE/codex-apply.json"
```

集成器会：

1. 在仓库外生成受影响文件备份；
2. 原样复制 payload；
3. 只在 `业务流程` 分类中登记 `equity-event-atlas`；
4. 调用当前仓库的 `credential_gate()` 与 `build_index()` 重建派生 README/index；
5. 运行 Skill 测试、自检和 `git diff --check`；
6. 失败时恢复集成前状态。

它不会运行 `sync_skills.py` 主流程，因此不会触发本机全量镜像、删除传播或人物资产缩减。

## 5. 仓库验收

```bash
python3 "$EEA_PACKAGE/taskpack/machine/tools/verify_repo_integration.py" \
  --repo "$AGENT_DB" \
  | tee "$EEA_PACKAGE/codex-repo-verify.json"

git -C "$AGENT_DB" diff --check
git -C "$AGENT_DB" status --short
git -C "$AGENT_DB" diff -- \
  CodexSkills/registry/codex/equity-event-atlas \
  CodexSkills/sync_skills.py \
  CodexSkills/README.md \
  CodexSkills/index.json
```

只允许上述四类路径发生变化。`_catalog` 的现有检查若返回 `NOT_PROVEN`，记录事实但不要手工制造 UID、digest 或信任记录。

## 6. 普通 main 提交和 push

```bash
git -C "$AGENT_DB" add \
  CodexSkills/registry/codex/equity-event-atlas \
  CodexSkills/sync_skills.py \
  CodexSkills/README.md \
  CodexSkills/index.json

git -C "$AGENT_DB" commit \
  -m "feat(codex-skills): add equity event atlas v0.0.0.1"

git -C "$AGENT_DB" push origin main
```

禁止：`reset`、`rebase`、`merge`、force push、历史重写、临时远端分支和 PR。

## 7. 回滚

### 提交前

从 `codex-apply.json` 读取 `backup_dir`：

```bash
python3 "$EEA_PACKAGE/taskpack/machine/tools/rollback_repo_integration.py" \
  --repo "$AGENT_DB" \
  --backup-dir "/absolute/path/from/codex-apply.json"

python3 "$EEA_PACKAGE/taskpack/machine/tools/rollback_repo_integration.py" \
  --repo "$AGENT_DB" \
  --backup-dir "/absolute/path/from/codex-apply.json" \
  --apply
```

### 提交后

使用普通 `git revert <commit-sha>`，验证后 push；不得 reset 或改写历史。

## 8. 最终只返回

```text
package_validation: PASS | FAIL
repo_validation: PASS | FAIL
repo_head_before: <sha>
commit: <sha or NOT_CREATED>
push: PASS | FAIL
changed_paths: <实际路径>
backup_dir: <路径>
catalog_check: PASS | NOT_PROVEN | NOT_AVAILABLE
remaining_risk: <最多三项真实风险>
```

部署或认证异常只记录日志与事实，不自行改写任务包设计。
