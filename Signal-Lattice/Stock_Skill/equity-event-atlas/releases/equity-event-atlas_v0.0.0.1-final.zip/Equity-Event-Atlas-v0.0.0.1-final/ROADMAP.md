# 股票事件航图 v0.0.0.1 当前版本 Roadmap

## Pursuing Goal

将股票事件航图作为无状态、只读、全球能力门控的 Codex Skill 原样接入 AgentDatabase，通过官方证据、时点正确性、概率路径、条件动作与确定性可视化验收。

## Stage–Phase–Task

| Stage | Phase | Task | Owner | 状态 | 验收 |
|---|---|---|---|---|---|
| S0 研究冻结 | P0.1 基线 | 仓库、边界、冲突顺序 | ChatGPT | COMPLETE | Canonical Facts 完整 |
|  | P0.2 复用 | 官方来源、至少五个同行、许可 | ChatGPT | COMPLETE | 无第三方代码复制 |
| S1 Skill 实现 | P1.1 合同 | 请求、市场、事件、四层真相 | ChatGPT | COMPLETE | Schema 与入口完整 |
|  | P1.2 核心 | 校验、能力门、报告和图表 | ChatGPT | COMPLETE | 标准库、失败关闭 |
|  | P1.3 接入 | 原子集成、索引、备份、回滚 | ChatGPT | COMPLETE | 不运行全量同步 |
| S2 验证整改 | P2.1 测试 | 16 项单元/负向/确定性测试 | ChatGPT | COMPLETE | 16/16 PASS |
|  | P2.2 整改 | 合并 Finding 并重跑冻结集 | ChatGPT | COMPLETE | 阻断 Finding=0 |
| S3 复审 | P3.1 审查 | 三遍方法合同 + 2×6 视角 | ChatGPT | COMPLETE | 独立性未伪报 |
| S4 打包 | P4.1 制品 | Manifest、哈希、单一 ZIP | ChatGPT | COMPLETE | Delivery PASS |
| S5 入库 | P5.1 预检 | ZIP 与仓库只读检查 | Codex | READY | READY / clean main |
|  | P5.2 集成 | 原样落库与即时验收 | Codex | READY | Repo validation PASS |
|  | P5.3 发布 | commit、push、事实回报 | Codex | READY | main commit 与 push |

## 当前 Definition of Done

- Skill 原样存在于冻结目标路径；
- 生成 README/index，无 `_catalog` 手工污染；
- 单元、自检、Manifest、凭据和 diff 检查通过；
- 普通 main commit 与 fast-forward-safe push；
- 返回真实 commit、push、备份和剩余风险。

机器级细节以 `taskpack/machine/task_dag.json` 为唯一事实源。
