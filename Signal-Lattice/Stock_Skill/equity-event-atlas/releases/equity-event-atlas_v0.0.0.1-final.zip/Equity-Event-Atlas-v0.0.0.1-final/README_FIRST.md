# 股票事件航图 v0.0.0.1 最终任务包

## 结论

这是一个可直接交给 Codex 的**单一最终任务包**。目标不是开发独立软件，而是把“股票事件航图”作为只读、无状态、可插拔的 Codex Skill 接入：

```text
https://github.com/LinzeColin/AgentDatabase
└── CodexSkills/registry/codex/equity-event-atlas/
```

默认范围：

- 美国与 ASX：深度市场策略；
- 全球其他市场：统一事件合同与动态能力门；
- 输出：中文 Markdown、JSON、Mermaid、SVG；
- 禁止：独立前端、数据库、常驻服务、券商连接、订单执行与收益保证。

## 状态

| 项目 | 结果 |
|---|---|
| 版本 | `0.0.0.1` |
| Scope / Acceptance | `FROZEN` |
| 包内 Python 单元测试 | `16/16 PASS` |
| 负向 Fixture | `6/6 按冻结错误码拒绝` |
| 重复渲染 | `PASS` |
| DAG / 追踪 / Manifest / 凭据扫描 | `PASS`，以最终验证报告为准 |
| 目标仓库真实落库 | `READY_FOR_CODEX`，尚未伪报已完成 |
| 独立多模型 2×6 | `NOT_PROVEN`；当前为 12 个同模型隔离视角 |

## 你只需要做什么

1. 把整个 ZIP 原样交给 Codex。
2. 告诉 Codex：先读 `CODEX_HANDOFF.md`，不得重新设计或扩展范围。
3. 把 `Pursuing_Goal.txt` 的唯一一行粘贴为开发线程目标。
4. Codex 完成后，只核对：包级验证 PASS、目标仓库验证 PASS、commit SHA、push 结果。

不要把 ZIP 内 `payload/` 单独抽出来给 Codex；仓库集成器、回滚和验收契约都在完整任务包中。
