#!/usr/bin/env python3
"""最终交付入口：验证解压目录，也可验证并试解压外部 ZIP。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Optional, Sequence


def root() -> Path:
    return Path(__file__).resolve().parent


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate_directory(directory: Path) -> dict:
    validator = directory / "taskpack" / "machine" / "tools" / "validate_taskpack.py"
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    result = subprocess.run(
        [sys.executable, "-B", str(validator), "--root", str(directory)],
        cwd=directory, env=env, text=True, capture_output=True, check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("任务包验证失败：\n" + result.stdout + "\n" + result.stderr)
    return json.loads(result.stdout)


def verify_zip(zip_path: Path) -> dict:
    if not zipfile.is_zipfile(zip_path):
        raise RuntimeError("不是有效 ZIP")
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if not names:
            raise RuntimeError("ZIP 为空")
        top_levels = {name.split("/", 1)[0] for name in names if name}
        if top_levels != {"Equity-Event-Atlas-v0.0.0.1-final"}:
            raise RuntimeError("ZIP 顶层目录不唯一或名称错误")
        for info in archive.infolist():
            path = Path(info.filename)
            if path.is_absolute() or ".." in path.parts:
                raise RuntimeError(f"ZIP 路径不安全：{info.filename}")
            mode = info.external_attr >> 16
            if mode and (mode & 0o170000) == 0o120000:
                raise RuntimeError(f"ZIP 含符号链接：{info.filename}")
        with tempfile.TemporaryDirectory(prefix="eea-delivery-") as temp:
            archive.extractall(temp)
            extracted = Path(temp) / "Equity-Event-Atlas-v0.0.0.1-final"
            result = validate_directory(extracted)
    return {
        "status": "PASS",
        "zip": str(zip_path),
        "zip_bytes": zip_path.stat().st_size,
        "zip_sha256": sha256_file(zip_path),
        "entries": len(names),
        "extracted_validation": result["status"],
    }


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="验证股票事件航图最终交付")
    parser.add_argument("--zip", type=Path)
    args = parser.parse_args(argv)
    try:
        directory_result = validate_directory(root())
        result = {"status": "PASS", "directory_validation": directory_result}
        if args.zip:
            result["zip_validation"] = verify_zip(args.zip.resolve())
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2, sort_keys=True), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
