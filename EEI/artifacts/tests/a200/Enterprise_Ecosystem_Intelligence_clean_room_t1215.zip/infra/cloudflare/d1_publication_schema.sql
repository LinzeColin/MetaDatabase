-- EEI cloud publication layer (Cloudflare D1 / SQLite dialect).
-- S7PDT04: one-way local -> cloud channel. Contains ONLY the publication
-- surface: owner-signed published facts, their endpoint entities, the
-- evidence index (excerpt + official link), and snapshot metadata.
-- Raw texts, candidates, review queues, scoring internals stay local.

CREATE TABLE IF NOT EXISTS publication_meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS entities (
  id TEXT PRIMARY KEY,
  canonical_name TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  status TEXT NOT NULL
);

-- evidence_tier says HOW the edge earned its place on the graph
-- (scripts/relationship_publication_gate.py):
--   single_official  one official first-hand source (SEC EDGAR, GLEIF ...) with an
--                    openable original document; the UI labels it 单一官方来源
--   multi_source     >= 2 independent sources (the original non-official rule)
-- WITHOUT ROWID on purpose: D1's free tier meters every index row it writes, and a
-- rowid table + TEXT primary key costs one extra row per insert. Edges are ~20k,
-- so this is what lets the whole graph fit inside one day's write allowance.
CREATE TABLE IF NOT EXISTS relationships (
  id TEXT PRIMARY KEY,
  subject_entity_id TEXT NOT NULL REFERENCES entities(id),
  object_entity_id TEXT NOT NULL REFERENCES entities(id),
  relationship_type TEXT NOT NULL,
  relationship_family TEXT NOT NULL,
  status TEXT NOT NULL,
  confidence REAL,
  observed_at TEXT,
  published_at TEXT,
  qualifiers_json TEXT,
  evidence_tier TEXT
) WITHOUT ROWID;

CREATE INDEX IF NOT EXISTS idx_relationships_subject
  ON relationships(subject_entity_id);
CREATE INDEX IF NOT EXISTS idx_relationships_object
  ON relationships(object_entity_id);

CREATE TABLE IF NOT EXISTS relationship_evidence (
  relationship_id TEXT NOT NULL REFERENCES relationships(id),
  source_document_id TEXT NOT NULL,
  role TEXT NOT NULL,
  locator TEXT,
  support_excerpt TEXT,
  source_url TEXT,
  source_title TEXT,
  publisher TEXT,
  document_date TEXT,
  PRIMARY KEY (relationship_id, source_document_id, role)
) WITHOUT ROWID;

-- Capital River / vertical timeline: first-hand published EVENTS (SEC filings
-- etc., derivation_rule = authoritative_first_hand_ingestion). Same one-way
-- publication surface: title/type/timing/amount + participant identity +
-- evidence index only. Raw filing texts stay local / in R2.
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  announced_at TEXT,
  effective_at TEXT,
  period_start TEXT,
  period_end TEXT,
  observed_at TEXT NOT NULL,
  amount REAL,
  currency TEXT,
  amount_kind TEXT,
  description TEXT,
  qualifiers_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_events_observed ON events(observed_at);
CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);

-- Participant entity_name is denormalized at publish time so the worker serves
-- the capital river without a join (mirrors how evidence carries source_*).
CREATE TABLE IF NOT EXISTS event_participants (
  event_id TEXT NOT NULL REFERENCES events(id),
  entity_id TEXT NOT NULL,
  entity_name TEXT,
  role TEXT NOT NULL,
  direction TEXT,
  PRIMARY KEY (event_id, entity_id, role)
);

CREATE INDEX IF NOT EXISTS idx_event_participants_entity
  ON event_participants(entity_id);

CREATE TABLE IF NOT EXISTS event_evidence (
  event_id TEXT NOT NULL REFERENCES events(id),
  source_document_id TEXT NOT NULL,
  role TEXT NOT NULL,
  locator TEXT,
  support_excerpt TEXT,
  source_url TEXT,
  source_title TEXT,
  publisher TEXT,
  document_date TEXT,
  PRIMARY KEY (event_id, source_document_id, role)
);

CREATE INDEX IF NOT EXISTS idx_event_evidence_event
  ON event_evidence(event_id);

CREATE TABLE IF NOT EXISTS snapshot_meta (
  snapshot_key TEXT PRIMARY KEY,
  scope TEXT NOT NULL,
  record_mode TEXT NOT NULL,
  status TEXT NOT NULL,
  as_of TEXT,
  activated_at TEXT
);

-- S12PB: per-year official filing depth for the vertical timeline
-- (aggregate counts only; publication-surface boundary applies).
CREATE TABLE IF NOT EXISTS filing_year_counts (
  year INTEGER PRIMARY KEY,
  filings INTEGER NOT NULL
);

-- EEI-F01: static 16-stage supply-chain reference rail so the cloud
-- /v1/supply-chain/overview mirrors the local module surface.
CREATE TABLE IF NOT EXISTS supply_chain_stages (
  stage_id TEXT PRIMARY KEY,
  stage_order INTEGER NOT NULL,
  slug TEXT NOT NULL,
  name_zh TEXT NOT NULL,
  name_en TEXT NOT NULL,
  default_direction TEXT NOT NULL,
  examples TEXT
);

-- EEI-PULSE: the data pulse surface. Answers "did anything actually arrive,
-- and how much" without opening a database. Aggregate counts only.
CREATE TABLE IF NOT EXISTS pulse_daily (
  day TEXT PRIMARY KEY,
  entities INTEGER NOT NULL DEFAULT 0,
  relationships INTEGER NOT NULL DEFAULT 0,
  events INTEGER NOT NULL DEFAULT 0,
  entities_added INTEGER NOT NULL DEFAULT 0,
  relationships_added INTEGER NOT NULL DEFAULT 0,
  events_added INTEGER NOT NULL DEFAULT 0
);

-- Composition buckets (event_type / source / filing decade). bucket_kind keeps
-- several independent breakdowns in one small table.
CREATE TABLE IF NOT EXISTS pulse_composition (
  bucket_kind TEXT NOT NULL,
  bucket TEXT NOT NULL,
  label TEXT,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (bucket_kind, bucket)
);

-- Live single-row signals: collector heartbeat, last publish, totals.
-- Written by the minute-cadence watcher as well as the full publisher, so a
-- stalled collector is visible within one minute.
CREATE TABLE IF NOT EXISTS pulse_now (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TEXT
);
