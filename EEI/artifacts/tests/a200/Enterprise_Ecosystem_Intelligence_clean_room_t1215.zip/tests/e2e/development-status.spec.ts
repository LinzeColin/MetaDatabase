import { expect, test } from "@playwright/test";

test("shows development status navigation with separated state classes", async ({ page }) => {
  // P0-1 导航收敛：开发状态不再占一级导航（归属「数据与来源」），
  // 路由保留可直达（P2 才做收编重定向）。
  await page.goto("/development-status");

  await expect(page).toHaveURL(/\/development-status$/);
  await expect(page.getByTestId("development-status-screen")).toBeVisible();
  await expect(page.getByTestId("main-nav-data_center")).toHaveAttribute(
    "aria-current",
    "page"
  );
  await expect(page.getByTestId("development-status-screen")).toHaveAttribute(
    "data-active-model-version",
    "business-empire-model-v2"
  );

  for (const lane of [
    "resolved",
    "prototyped",
    "specified",
    "not-started",
    "blocked",
    "out-of-scope"
  ]) {
    await expect(page.getByTestId(`status-lane-${lane}`)).toBeVisible();
  }

  await expect(page.getByTestId("status-current-gate")).toContainText("G4 / IN PROGRESS");
  await expect(page.getByTestId("status-task-count")).toHaveText("130");
  await expect(page.getByTestId("status-acceptance-done")).not.toHaveText("0");
  await expect(page.getByTestId("status-open-risks")).not.toHaveText("0");
});

test("links tasks risks controls and acceptance evidence from the status screen", async ({
  page
}) => {
  await page.goto("/development-status");

  await expect(page.getByTestId("status-linked-evidence")).toContainText("tasks");
  await expect(page.getByTestId("status-linked-evidence")).toContainText("risks");
  await expect(page.getByTestId("status-linked-evidence")).toContainText("controls");
  await expect(page.getByTestId("status-linked-evidence")).toContainText("acceptance evidence");
  await expect(page.getByTestId("status-link-tasks")).toHaveAttribute("href", /task_backlog\.csv/);
  await expect(page.getByTestId("status-link-risks")).toHaveAttribute("href", /risk_register\.csv/);
  await expect(page.getByTestId("status-link-controls")).toHaveAttribute(
    "href",
    /risk_control_traceability\.csv/
  );
  await expect(page.getByTestId("status-link-acceptance")).toHaveAttribute(
    "href",
    /acceptance_traceability\.csv/
  );

  await expect(page.getByTestId("status-ledger-panel")).toContainText("FUN-EXP-01");
  await expect(page.getByTestId("status-ledger-panel")).toContainText("LOCAL_E2E_VALIDATED");
  await expect(page.getByTestId("status-task-T1302")).toContainText(
    "Complete production API"
  );
  await expect(page.getByTestId("status-task-T1302")).toContainText("DONE");
  await expect(page.getByTestId("status-acceptance-panel")).toContainText("DONE");
  await expect(page.getByTestId("status-risk-control-panel")).toContainText("R001");
  await expect(page.getByTestId("status-risk-control-panel")).toContainText("critical");
});
