#!/usr/bin/env bash
# S10PAT02: build the static cloud frontend (legacy path: stage it as the
# codex-eei Worker's asset directory).
#
# 现行生产路径不再用本脚本：旧版图谱前端由宇宙容器自托管，前端在镜像构建时生成
# （EEI/apps/universe/deploy/Dockerfile 第 1 阶段，同样的 next build 参数）。本脚本只服务于
# 「回滚到 Cloudflare Worker」这条退路。接口基址默认 same-origin：产物运行时取页面自己的
# origin 去请求 /v1/*，不写死任何域名（也不再写 workers.dev / 自定义域名）。
# 需要指向别处（例如本机 API）时用 EEI_CLOUD_API_BASE 覆盖。
#
# EEI-F07: the build is stamped with the git commit (clean tree required) so
# production can be provably mapped to a revision. The same SHA goes into the
# frontend bundle (NEXT_PUBLIC_EEI_BUILD_SHA), a dist/build.json manifest, and
# scripts/deploy_cloud.sh passes it to the Worker as EEI_BUILD_SHA.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
API_BASE="${EEI_CLOUD_API_BASE:-same-origin}"
WEB_DIR="$REPO_ROOT/apps/web"
DIST_DIR="$REPO_ROOT/apps/cloudflare-public/dist"

BUILD_SHA="$(git -C "$REPO_ROOT" rev-parse HEAD)"
# 「脏」的口径必须和 deploy_cloud.sh 完全一致，否则两个戳永远对不上：
# 这里给 SHA 加 -dirty，而 deploy_cloud.sh 的 BUILD_SHA 不加 —— header 来自本脚本
# 写的 _headers、/v1/meta/build 来自 deploy 绑的 var，验收那一步就必然红。
# apps/web/next-env.d.ts 是 Next 生成的（next build 与 typegen 各写一个值），
# 本脚本自己就会翻它，所以两边一起豁免它。
if [ -n "$(git -C "$REPO_ROOT" status --porcelain -- "$REPO_ROOT" 2>/dev/null | grep -v '/apps/web/next-env\.d\.ts$' || true)" ]; then
  BUILD_SHA="${BUILD_SHA}-dirty"
fi
BUILD_TIME="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

echo "[cloud-frontend] exporting apps/web against $API_BASE (build $BUILD_SHA)"
cd "$WEB_DIR"
rm -rf .next out
EEI_CLOUD_EXPORT=1 \
  NEXT_PUBLIC_EEI_API_BASE_URL="$API_BASE" \
  NEXT_PUBLIC_EEI_BUILD_SHA="$BUILD_SHA" \
  NEXT_PUBLIC_EEI_SURFACE="cloud-publication" \
  npx next build

echo "[cloud-frontend] staging export into apps/cloudflare-public/dist"
rm -rf "$DIST_DIR"
cp -R "$WEB_DIR/out" "$DIST_DIR"

cat > "$DIST_DIR/build.json" <<MANIFEST
{
  "repo": "LinzeColin/MetaDatabase",
  "commit": "$BUILD_SHA",
  "built_at": "$BUILD_TIME",
  "api_base": "$API_BASE"
}
MANIFEST

# EEI-F08: static assets bypass the Worker (run_worker_first covers /v1/* and
# /health only), so the security baseline for HTML/chunks rides the Workers
# Assets _headers file. Keep in lockstep with SECURITY_HEADERS in worker.mjs.
cat > "$DIST_DIR/_headers" <<HEADERS
/*
  Strict-Transport-Security: max-age=31536000; includeSubDomains
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://static.cloudflareinsights.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self' https://cloudflareinsights.com https://static.cloudflareinsights.com; frame-ancestors 'none'; base-uri 'self'; form-action 'self'
  X-EEI-Build: $BUILD_SHA
HEADERS

echo "[cloud-frontend] done: $(find "$DIST_DIR" -type f | wc -l | tr -d ' ') files, build $BUILD_SHA"
